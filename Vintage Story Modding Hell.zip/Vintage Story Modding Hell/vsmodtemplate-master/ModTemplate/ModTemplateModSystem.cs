﻿using boricalchemy;
using BoricAlchemy;
using BoricAlchemy.blocks;
using HarmonyLib;
using System;
using System.Collections.Generic;
using System.Xml;
using Vintagestory.API.Client;
using Vintagestory.API.Common;
using Vintagestory.API.Common.Entities;
using Vintagestory.API.Config;
using Vintagestory.API.Datastructures;
using Vintagestory.API.MathTools;
using Vintagestory.API.Server;
using Vintagestory.GameContent;
using Vintagestory.ServerMods;


namespace ModTemplate
{
    public class ModTemplateModSystem : ModSystem
    {
        // Called on server and client
        public static MineConfigData Config;
        private ICoreServerAPI sapi;

        public override void Start(ICoreAPI api)
        {
            //Try to load the config - pleeeease!
            Harmony harmony = new Harmony("boricalchemy");
            harmony.PatchAll();


            Mod.Logger.Notification("Boric Alchemy is installed :D - " + Lang.Get("mymodid"));

            api.RegisterBlockClass("Beartrap", typeof(Beartrap));
            api.RegisterBlockClass("Mine", typeof(Mine));
            api.RegisterBlockClass("MineUpgraded", typeof(MineUpgraded));
            api.RegisterBlockClass("MineUpgraded", typeof(MineUpgraded));


            



            api.RegisterBlockClass("WindUpLightStart", typeof(WindUpLightStart));
            api.RegisterBlockClass("BCustomDecay", typeof(BCustomDecay));
            api.RegisterBlockClass("BCFakePlantVent", typeof(BlockCustomDistiller));
            api.RegisterBlockClass("BCFakePlantVentNoReplace", typeof(BCFakePlantVentNoReplace));
            api.RegisterBlockClass("BCustomItemConvert", typeof(BCustomItemConvert));
            api.RegisterBlockClass("BCustomHarvest", typeof(BCustomHarvest));
            api.RegisterBlockClass("BCustomHarvestPicky", typeof(BCustomHarvestPicky));
            api.RegisterBlockClass("BCustomItemConvertTable", typeof(BCustomItemConvertTable));
            api.RegisterBlockClass("BCustomEmptyableBlock", typeof(BCustomEmptyableBlock));
            api.RegisterBlockClass("BCustomFractionalDistiller", typeof(BCustomFractionalDistiller));
            api.RegisterBlockClass("BCustomFractionalDistillerALT", typeof(BCustomFractionalDistiller2));
            api.RegisterBlockClass("MyCustomCookingContainer", typeof(MyCustomCookingContainer));
            api.RegisterBlockClass("BlockIgnitableTransform", typeof(BlockIgnitableTransform));
            api.RegisterBlockClass("CustomBlockBarrel", typeof(CustomBlockBarrel));

            api.RegisterBlockEntityClass("BECustomDecay", typeof(BECustomDecay));
            api.RegisterBlockEntityClass("BECustomDecayBi", typeof(BECustomDecayBi));
            api.RegisterBlockEntityClass("BECustomAOEDamage", typeof(BECustomAOEDamage));
            api.RegisterBlockEntityClass("BECustomAOEDecay", typeof(BECustomAOEDecay));
            api.RegisterBlockEntityClass("BECustomTimedTransform", typeof(BECustomTimedTransform));
            api.RegisterBlockEntityClass("BECustomTimeMorph", typeof(BECustomTimeMorph));

            

            api.RegisterBlockEntityClass("BEBonfire", typeof(BEBonfire));
            api.RegisterEntity("EntityExplosiveProjectileFuse_Mid", typeof(EntityExplosiveProjectileFuseMid));
            api.RegisterEntity("EntityExplosiveProjectile", typeof(EntityExplosiveProjectile));
            api.RegisterEntity("EntityMolotov", typeof(EntityMolotov));

            

            api.RegisterCollectibleBehaviorClass("EntityBehaviorExplodeInWater", typeof(EntityBehaviorExplodeInWater));
            api.RegisterCollectibleBehaviorClass("EntityBehaviorExplodeOnImpact", typeof(EntityBehaviorExplodeOnImpact));

            api.RegisterItemClass("ItemFlamethrower", typeof(ItemFlamethrower));
            api.RegisterItemClass("ItemFlamethrowerEmpty", typeof(ItemFlamethrowerEmpty));
            api.RegisterItemClass("ItemChemGun", typeof(ItemChemGun));
            api.RegisterItemClass("SpeedItem", typeof(SpeedItem));
            api.RegisterItemClass("ItemCapacitorSpear", typeof(ItemCapacitorSpear));
            api.RegisterItemClass("AntiDrifterDrugs", typeof(ItemStabilizingFood));



            


            api.RegisterEntityBehaviorClass("helmetcheck", typeof(EntityBehaviorHelmetCheck));

            
            // Making dropped items explode
            api.Event.OnEntitySpawn += (entity) =>
            {
                //Item is a dropped item
                if (entity is EntityItem entityItem)
                {
                    var attributes = entityItem.Itemstack?.Collectible?.Attributes;

                    // Water Logic
                    if (attributes != null && attributes["explodesInWater"].Exists && attributes["explodesInWater"].AsBool(false))
                    {
                        entity.AddBehavior(new EntityBehaviorExplodeInWater(entity));
                        if (entity.FeetInLiquid)
                        {
                            TriggerInstantExplosion(entity);
                        }
                    }

                    // Impact Logic
                    if (attributes != null && attributes["explodesOnDrop"].Exists && attributes["explodesOnDrop"].AsBool(false))
                    {
                        entity.AddBehavior(new EntityBehaviorExplodeOnImpact(entity));
                    }

                }

                if (entity is EntityPlayer)
                {
                    entity.AddBehavior(new EntityBehaviorHelmetCheck(entity));


                }
            };
        }



            private void TriggerInstantExplosion(Entity entity)
            {
                if (entity.Api.Side != EnumAppSide.Server) return;
                var sapi = entity.Api as ICoreServerAPI;
                if (sapi == null) return;
                BlockPos pos = entity.Pos.AsBlockPos;
                float explosionRadius = 3f;
                sapi.World.CreateExplosion(
                    pos,
                    EnumBlastType.RockBlast,
                    explosionRadius,
                    explosionRadius
                );
                entity.Die();
            }

        private void OnPlayerJoin(IServerPlayer player)
        {
            EntityPlayer entityPlayer = player.Entity;

            entityPlayer.WatchedAttributes.SetBool(
                "boricAlchemy_speedActive",
                false
            );
        }


        public override void StartServerSide(ICoreServerAPI api)
        {
            sapi = api;

            RuntimeEnv.DebugOutOfRangeBlockAccess = true;
            api.Event.PlayerJoin += OnPlayerJoin;


            Mod.Logger.Notification("Boric alchemy - server side - marco!");

            try
            {
                Config = api.LoadModConfig<MineConfigData>("boricalchemy.json");

                if (Config == null)
                {
                    Config = new MineConfigData();
                }

                // creates a file if it doesnt exist,
                api.StoreModConfig(Config, "boricalchemy.json");
            }
            catch (Exception e)
            {
                Mod.Logger.Error("Could not load BoricAlchemy config.");
                Mod.Logger.Error(e);

                Config = new MineConfigData();
            }
        }



    }

    }

/*
 *  this shit is a recipe :D 
 * 
 *         public override void StartClientSide(ICoreClientAPI api)
        {
            Mod.Logger.Notification("Boric alchemy - client side - polo!");

            GridRecipe fakeRecipe = new GridRecipe()
            {
                Name = new AssetLocation("boricalchemy:fakerecipe-target"),
                Output = new CraftingRecipeIngredient()
                {
                    Type = EnumItemClass.Item,
                    Code = new AssetLocation("boricalchemy:formicacid")
                },
                Ingredients = new Dictionary<string, CraftingRecipeIngredient>()
        {
            {
                "A", new CraftingRecipeIngredient() { Type = EnumItemClass.Block, Code = new AssetLocation("game:rock-granite") }
            }
        },
                IngredientPattern = "A",
                Width = 1,
                Height = 1
            };

            // Resolve using the client API's world instance
            if (fakeRecipe.Resolve(api.World, "boricalchemy"))
            {
                api.World.GridRecipes.Add(fakeRecipe);
            }
            else
            {
                Mod.Logger.Error("BoricAlchemy: Failed to resolve fake recipe for handbook!");
            }
        }

*/