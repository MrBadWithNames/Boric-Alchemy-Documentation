﻿using ModTemplate;
using Vintagestory.API.Common;
using Vintagestory.API.Common.Entities;
using Vintagestory.API.Datastructures;
using Vintagestory.API.Server;

namespace BoricAlchemy.blocks
{
    public class SpeedItem : Item
    {
        private const string SpeedActiveKey = "boricAlchemy_speedActive";


        public override void OnHeldUseStart(
            ItemSlot slot,
            EntityAgent byEntity,
            BlockSelection blockSel,
            EntitySelection entitySel,
            EnumHandInteract useType,
            bool firstEvent,
            ref EnumHandHandling handling)
        {
            if (byEntity.World.Side == EnumAppSide.Server && byEntity is EntityPlayer entityPlayer)
            {
                bool speedActive = entityPlayer.WatchedAttributes.GetBool(
                    SpeedActiveKey,
                    false
                );


                if (speedActive)
                {
                    handling = EnumHandHandling.PreventDefault;
                    return;
                }


                float speedMultiplier = ModTemplateModSystem.Config.speedBuffMultiplier;

                entityPlayer.Stats.Set(
                    "walkspeed",
                    "mySpeedBoost",
                    speedMultiplier,
                    false
                );


                entityPlayer.WatchedAttributes.SetBool(
                    SpeedActiveKey,
                    true
                );

                IServerPlayer player = entityPlayer.Player as IServerPlayer;
                if (player != null)
                {
                    double currentStability = entityPlayer.WatchedAttributes.GetDouble("temporalStability", 1.0);

                    double newStability = System.Math.Min(1.5, currentStability - 0.10);

                    entityPlayer.WatchedAttributes.SetDouble("temporalStability", newStability);
                    entityPlayer.WatchedAttributes.MarkPathDirty("temporalStability");

                        ITreeAttribute tirednessTree = entityPlayer.WatchedAttributes.GetTreeAttribute("tiredness");

                        if (tirednessTree != null)
                        {
                            tirednessTree.SetFloat("tiredness", 0f);

                            entityPlayer.WatchedAttributes.MarkPathDirty("tiredness");
                        }
                }

                slot.TakeOut(1);
                slot.MarkDirty();


                CheckAndExpire(entityPlayer);
            }

            handling = EnumHandHandling.PreventDefault;
        }


        private void CheckAndExpire(EntityPlayer entityPlayer)
        {
            entityPlayer.World.RegisterCallback((dt) =>
            {
                if (entityPlayer.Player == null)
                {
                    return;
                }


                entityPlayer.Stats.Remove(
                    "walkspeed",
                    "mySpeedBoost"
                );


                entityPlayer.WatchedAttributes.SetBool(
                    SpeedActiveKey,
                    false
                );

            }, (int)ModTemplateModSystem.Config.SpeedDuration);
        }
    }
}