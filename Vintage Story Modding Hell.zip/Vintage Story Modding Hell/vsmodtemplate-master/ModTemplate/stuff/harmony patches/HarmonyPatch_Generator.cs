﻿using HarmonyLib;
using Vintagestory.API.Common;
using System.Collections.Generic;

namespace BoricAlchemy.stuff
{
    public class BoriAlchemySystem : ModSystem
    {
        public static ICoreAPI Api { get; private set; }

        private Harmony harmony;

        public override void Start(ICoreAPI api)
        {
            Api = api;

            harmony = new Harmony(Mod.Info.ModID);
            harmony.PatchAll();
        }

        public override void Dispose()
        {
            harmony?.UnpatchAll(Mod.Info.ModID);
        }
    }


    [HarmonyPatch(
        typeof(CollectibleObject),
        nameof(CollectibleObject.ConsumeCraftingIngredients)
    )]
    public static class CraftingDurabilityPatch
    {
        private static readonly Dictionary<string, string> Replacements =
            new()
            {
                {
                    "boricalchemy:combustiongenerator",
                    "boricalchemy:combustiongeneratordry"
                },

                {
                    "boricalchemy:battery",
                    "boricalchemy:batteryempty"
                },

                {
                    "boricalchemy:advancedbattery-silverchloride_zinc_ammoniumchloride-charged",
                    "boricalchemy:advancedbattery-silverchloride_zinc_ammoniumchloride-dead"
                },
                {
                    "boricalchemy:advancedbattery-copper_zinc_sulfuricacid-charged",
                    "boricalchemy:advancedbattery-copper_zinc_sulfuricacid-dead"
                },
                {
                    "boricalchemy:advancedbattery-leaddioxide_lead_sulfuricacid-charged",
                    "boricalchemy:advancedbattery-leaddioxide_lead_sulfuricacid-dead"
                },

                {
                    "boricalchemy:batterylead",
                    "boricalchemy:batteryempty"
                }
            };


        public static void Prefix(
            ItemSlot[] slots,
            ItemSlot outputSlot,
            IRecipeBase matchingRecipe
        )
        {
            foreach (ItemSlot slot in slots)
            {
                if (slot?.Itemstack == null)
                    continue;

                ItemStack stack = slot.Itemstack;

                string code = stack.Collectible?.Code?.ToString();

                if (code == null)
                    continue;

                if (!Replacements.TryGetValue(code, out string replacementCode))
                    continue;

                int remaining =
                    stack.Collectible.GetRemainingDurability(stack);

                if (remaining > 1)
                    continue;

                Item replacementItem = BoriAlchemySystem.Api.World.GetItem(
                    new AssetLocation(replacementCode)
                );

                if (replacementItem == null)
                    continue;

                int quantity = stack.StackSize;

                slot.Itemstack = new ItemStack(
                    replacementItem,
                    quantity
                );

                slot.MarkDirty();
            }
        }
    }
}