﻿using ModTemplate;
using System;
using Vintagestory.API.Client;
using Vintagestory.API.Common;
using Vintagestory.API.Common.Entities;
using Vintagestory.API.Config;
using Vintagestory.API.Datastructures;
using Vintagestory.API.MathTools;
using Vintagestory.API.Server;
using Vintagestory.API.Util;
using Vintagestory.GameContent;

namespace BoricAlchemy.blocks
{
    public class BEBonfire : BlockEntity
    {
        //storing the default tick in case i fuck up
        int ticksLeft;
        private long tickListenerId;
        AssetLocation decayBlockCode;
        private Random random = new Random();
        private bool crackedRock = false;

        public override void Initialize(ICoreAPI api)
        {
            base.Initialize(api);

            decayBlockCode = new AssetLocation("game:air");

            if (api.Side != EnumAppSide.Server)
            {
                return;
            }

            if (ModTemplateModSystem.Config == null)
            {
                Api.Logger.Error("BoricAlchemy: Bonfire config was not initialized!");
                return;
            }

            ticksLeft = ModTemplateModSystem.Config.BonfireDuration;
            tickListenerId = RegisterGameTickListener(OnTick, 100);
        }


        //block transfomraiton function
        private void TransformBlock(IWorldAccessor world, Block block, BlockPos pos, string fromCode, string toCode)
        {

            if (block.Code.Path.Contains(fromCode))
            {
                Block replacement = world.GetBlock(new AssetLocation("game:" + toCode));

                if (replacement != null)
                {
                    
                    world.BlockAccessor.SetBlock(replacement.Id, pos);

                    world.BlockAccessor.TriggerNeighbourBlockUpdate(pos);
                }

                crackedRock = true;
            }

        }

        private void TransformBlockAlt(IWorldAccessor world, Block block, BlockPos pos, string fromCode, string toCode)
        {

            if (block.Code.Path.Contains(fromCode))
            {
                Block replacement = world.GetBlock(new AssetLocation("boricalchemy:" + toCode));

                if (replacement != null)
                {

                    world.BlockAccessor.SetBlock(replacement.Id, pos);

                    world.BlockAccessor.TriggerNeighbourBlockUpdate(pos);
                }

                crackedRock = true;
            }

        }
        private void TransformBlockOre(IWorldAccessor world, Block block, BlockPos pos)
        {
            if (block.Code.Domain == "game" && block.Code.Path.StartsWith("ore-"))
            {
                string crackedPath = block.Code.Path.Replace("ore-", "orecracked-");

                Block replacement = world.GetBlock(new AssetLocation("boricalchemy", crackedPath));

                if (replacement != null && replacement.Id != 0)
                {
                    world.BlockAccessor.SetBlock(replacement.Id, pos);

                }
            }
        }

        private void SpawnSolidItem(IWorldAccessor world, Vec3d pos, string itemCode, int amount)
        {
            AssetLocation assetLoc = new AssetLocation(itemCode);
            ItemStack itemStack = null;

            Item item = world.GetItem(assetLoc);
            if (item != null)
            {
                itemStack = new ItemStack(item, amount);
            }
            else
            {
                Block block = world.GetBlock(assetLoc);
                if (block != null)
                {
                    itemStack = new ItemStack(block, amount);
                }
            }

            if (itemStack != null)
            {
                world.SpawnItemEntity(itemStack, pos);
            }
        }
        private void OnTick(float dt)
        {
            if (Api.Side != EnumAppSide.Server)
            {
                return;
            }

            Block water = Api.World.BlockAccessor.GetBlock(Pos, BlockLayersAccess.Fluid);

            if (water != null && water.Code != null && water.Code.Path.StartsWith("water"))
            {
                UnregisterGameTickListener(tickListenerId);
                Api.World.BlockAccessor.SetBlock(0, Pos); // Air
                return;
            }

            Vec3d center = Pos.ToVec3d().Add(0.5, 0.5, 0.5);

            float radius = ModTemplateModSystem.Config.BonfireRadius;

            Entity[] entities = Api.World.GetEntitiesAround(
                center,
                radius,
                radius,
                (e) => true
            );

            foreach (var entity in entities)
            {
                entity.ReceiveDamage(new DamageSource()
                {
                    Source = EnumDamageSource.Block,
                    SourceBlock = Block,
                    SourcePos = center,
                    Type = EnumDamageType.Fire
                }, ModTemplateModSystem.Config.BonfireDamage);

                if (ModTemplateModSystem.Config.BonfireIgniteEntities == true) { 
                entity.Ignite();
                }
            }

            int hrange = ModTemplateModSystem.Config.BonfireEffectHorizontalRange;
            int vrange = ModTemplateModSystem.Config.BonfireEffectVerticalRange;


            for (int i = 0; i < 10; i++)
            {
                int x = random.Next(-hrange, hrange + 1);
                int y = random.Next(-vrange, vrange + 1);
                int z = random.Next(-hrange, hrange + 1);

                BlockPos targetPos = Pos.AddCopy(x, y, z);
                Block block = Api.World.BlockAccessor.GetBlock(targetPos);

  

                if (random.NextDouble() <= 0.025)
                {
                    TransformBlock(Api.World,block,targetPos,"rock-granite","crackedrock-granite");
                    TransformBlock(Api.World, block, targetPos, "rock-andesite", "crackedrock-andesite");
                    TransformBlock(Api.World, block, targetPos, "rock-shale", "crackedrock-shale");
                    TransformBlock(Api.World, block, targetPos, "rock-chalk", "crackedrock-chalk");
                    TransformBlock(Api.World, block, targetPos, "rock-chert", "crackedrock-chert");
                    TransformBlock(Api.World, block, targetPos, "rock-conglomerate", "crackedrock-conglomerate");
                    TransformBlock(Api.World, block, targetPos, "rock-limestone", "crackedrock-limestone");
                    TransformBlock(Api.World, block, targetPos, "rock-claystone", "crackedrock-claystone");
                    TransformBlock(Api.World, block, targetPos, "rock-sandstone", "crackedrock-sandstone");
                    TransformBlock(Api.World, block, targetPos, "rock-basalt", "crackedrock-basalt");
                    TransformBlock(Api.World, block, targetPos, "rock-peridotite", "crackedrock-peridotite");
                    TransformBlock(Api.World, block, targetPos, "rock-phyllite", "crackedrock-phyllite");
                    TransformBlock(Api.World, block, targetPos, "rock-slate", "crackedrock-slate");
                    TransformBlock(Api.World, block, targetPos, "rock-kimberlite", "crackedrock-kimberlite");
                    TransformBlock(Api.World, block, targetPos, "rock-bauxite", "crackedrock-bauxite");
                    TransformBlock(Api.World, block, targetPos, "rock-halite", "crackedrock-halite");
                    TransformBlock(Api.World, block, targetPos, "rock-suevite", "crackedrock-suevite");
                    TransformBlock(Api.World, block, targetPos, "rock-obsidian", "crackedrock-obsidian");
                    TransformBlock(Api.World, block, targetPos, "rock-tuff", "crackedrock-tuff");
                    TransformBlock(Api.World, block, targetPos, "rock-scoria", "crackedrock-scoria");
                    TransformBlock(Api.World, block, targetPos, "rock-travertine", "crackedrock-travertine");
                    TransformBlock(Api.World, block, targetPos, "rock-redmarble", "crackedrock-redmarble");
                    TransformBlock(Api.World, block, targetPos, "rock-greenmarble", "crackedrock-greenmarble");
                    TransformBlock(Api.World, block, targetPos, "rock-whitemarble", "crackedrock-whitemarble");
                    TransformBlock(Api.World, block, targetPos, "snowlayer", "air");

                    TransformBlockAlt(Api.World, block, targetPos, "celestitelimestone", "celestitelimestonecracked");
                    TransformBlockAlt(Api.World, block, targetPos, "pyrolusitelimestone", "pyrolusitelimestonecracked");
                    TransformBlockAlt(Api.World, block, targetPos, "pyrolusitesandstone", "pyrolusitesandstonecracked");
                    TransformBlockAlt(Api.World, block, targetPos, "scheelitegranite", "scheelitegranitecracked");
                    TransformBlockAlt(Api.World, block, targetPos, "vanadinitelimestone", "vanadinitelimestonecracked");

                    TransformBlock(Api.World, block, targetPos, "lakeice", "water-still-7");
                    TransformBlockAlt(Api.World, block, targetPos, "meteorite-iron", "meteoritecracked-iron");

                    TransformBlockOre(Api.World, block, targetPos);
                }
            }

            bool eternal = ModTemplateModSystem.Config.eternalBonfire;
            if (eternal != null)
            {
                if (!eternal)
                {
                    ticksLeft--;
                }
            }
            

            if (ticksLeft <= 0)
            {
                UnregisterGameTickListener(tickListenerId);

                Block next = Api.World.GetBlock(decayBlockCode);
                Api.World.BlockAccessor.SetBlock(next.BlockId, Pos);
            }
        }
    }
    }
