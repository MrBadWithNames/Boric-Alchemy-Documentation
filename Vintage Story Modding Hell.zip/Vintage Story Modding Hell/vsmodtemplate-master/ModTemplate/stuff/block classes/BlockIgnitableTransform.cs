﻿using Vintagestory.API.Common;
using Vintagestory.API.MathTools;

public class BlockIgnitableTransform : Block
{
    public string TransformToBlockCode = "boricalchemy:litbonfire";

    private const float IgniteTime = 2f; // seconds

    public override bool OnBlockInteractStart(
        IWorldAccessor world,
        IPlayer byPlayer,
        BlockSelection blockSel)
    {
        ItemStack heldItem = byPlayer.InventoryManager.ActiveHotbarSlot.Itemstack;

        if (heldItem != null && heldItem.Collectible.Code.Path.Contains("torch"))
        {
            // Returning true tells VS that we are handling this interaction
            return true;
        }

        return base.OnBlockInteractStart(world, byPlayer, blockSel);
    }

    public override bool OnBlockInteractStep(
       float secondsUsed,
       IWorldAccessor world,
       IPlayer byPlayer,
       BlockSelection blockSel)
    {
        if (secondsUsed >= IgniteTime)
        {
            Block targetBlock = world.GetBlock(
                new AssetLocation(TransformToBlockCode)
            );

            if (targetBlock != null)
            {
                world.BlockAccessor.SetBlock(
                    targetBlock.BlockId,
                    blockSel.Position
                );
            }

            return false;
        }

        return true;
    }


    public override void OnBlockInteractStop(
        float secondsUsed,
        IWorldAccessor world,
        IPlayer byPlayer,
        BlockSelection blockSel)
    {
        // Player let go before ignition completed
    }
}