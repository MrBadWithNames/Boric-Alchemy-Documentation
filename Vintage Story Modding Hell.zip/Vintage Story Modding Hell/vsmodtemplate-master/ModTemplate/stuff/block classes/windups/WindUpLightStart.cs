﻿using Vintagestory.API.Common;
using Vintagestory.API.MathTools;

namespace BoricAlchemy
{
    public class WindUpLightStart : Block
    {
        public override bool OnBlockInteractStart(
            IWorldAccessor world,
            IPlayer byPlayer,
            BlockSelection blockSel)
        {
            if (world.Side == EnumAppSide.Client)
                return true;

            // Get the COMPLETE code of the block being clicked.
            string currentCode = Code.ToString();

            world.Logger.Notification(
                $"BlockTransformer: clicked {currentCode}"
            );

            string targetCode = null;

            // NORMAL
            if (currentCode == "boricalchemy:winduplight_off-north")
            {
                targetCode = "boricalchemy:winduplight_on-north";
            }
            else if (currentCode == "boricalchemy:winduplight_off-south")
            {
                targetCode = "boricalchemy:winduplight_on-south";
            }
            else if (currentCode == "boricalchemy:winduplight_off-east")
            {
                targetCode = "boricalchemy:winduplight_on-east";
            }
            else if (currentCode == "boricalchemy:winduplight_off-west")
            {
                targetCode = "boricalchemy:winduplight_on-west";
            }

            // HYDROGEN
            else if (currentCode == "boricalchemy:winduplight_h_off-north")
            {
                targetCode = "boricalchemy:winduplight_h_on-north";
            }
            else if (currentCode == "boricalchemy:winduplight_h_off-south")
            {
                targetCode = "boricalchemy:winduplight_h_on-south";
            }
            else if (currentCode == "boricalchemy:winduplight_h_off-east")
            {
                targetCode = "boricalchemy:winduplight_h_on-east";
            }
            else if (currentCode == "boricalchemy:winduplight_h_off-west")
            {
                targetCode = "boricalchemy:winduplight_h_on-west";
            }

            // SODIUM
            else if (currentCode == "boricalchemy:winduplight_s_off-north")
            {
                targetCode = "boricalchemy:winduplight_s_on-north";
            }
            else if (currentCode == "boricalchemy:winduplight_s_off-south")
            {
                targetCode = "boricalchemy:winduplight_s_on-south";
            }
            else if (currentCode == "boricalchemy:winduplight_s_off-east")
            {
                targetCode = "boricalchemy:winduplight_s_on-east";
            }
            else if (currentCode == "boricalchemy:winduplight_s_off-west")
            {
                targetCode = "boricalchemy:winduplight_s_on-west";
            }

            // XENON
            else if (currentCode == "boricalchemy:winduplight_x_off-north")
            {
                targetCode = "boricalchemy:winduplight_x_on-north";
            }
            else if (currentCode == "boricalchemy:winduplight_x_off-south")
            {
                targetCode = "boricalchemy:winduplight_x_on-south";
            }
            else if (currentCode == "boricalchemy:winduplight_x_off-east")
            {
                targetCode = "boricalchemy:winduplight_x_on-east";
            }
            else if (currentCode == "boricalchemy:winduplight_x_off-west")
            {
                targetCode = "boricalchemy:winduplight_x_on-west";
            }

            // NEON
            else if (currentCode == "boricalchemy:winduplight_n_off-north")
            {
                targetCode = "boricalchemy:winduplight_n_on-north";
            }
            else if (currentCode == "boricalchemy:winduplight_n_off-south")
            {
                targetCode = "boricalchemy:winduplight_n_on-south";
            }
            else if (currentCode == "boricalchemy:winduplight_n_off-east")
            {
                targetCode = "boricalchemy:winduplight_n_on-east";
            }
            else if (currentCode == "boricalchemy:winduplight_n_off-west")
            {
                targetCode = "boricalchemy:winduplight_n_on-west";
            }

            // KRYPTON
            else if (currentCode == "boricalchemy:winduplight_kr_off-north")
            {
                targetCode = "boricalchemy:winduplight_kr_on-north";
            }
            else if (currentCode == "boricalchemy:winduplight_kr_off-south")
            {
                targetCode = "boricalchemy:winduplight_kr_on-south";
            }
            else if (currentCode == "boricalchemy:winduplight_kr_off-east")
            {
                targetCode = "boricalchemy:winduplight_kr_on-east";
            }
            else if (currentCode == "boricalchemy:winduplight_kr_off-west")
            {
                targetCode = "boricalchemy:winduplight_kr_on-west";
            }

            // Co2
            else if (currentCode == "boricalchemy:winduplight_coo_off-north")
            {
                targetCode = "boricalchemy:winduplight_coo_on-north";
            }
            else if (currentCode == "boricalchemy:winduplight_coo_off-south")
            {
                targetCode = "boricalchemy:winduplight_coo_on-south";
            }
            else if (currentCode == "boricalchemy:winduplight_coo_off-east")
            {
                targetCode = "boricalchemy:winduplight_coo_on-east";
            }
            else if (currentCode == "boricalchemy:winduplight_coo_off-west")
            {
                targetCode = "boricalchemy:winduplight_coo_on-west";
            }

            if (targetCode == null)
            {
                world.Logger.Notification(
                    $"BlockTransformer: no transformation for {currentCode}"
                );

                return false;
            }

            AssetLocation fireSound =
                new AssetLocation(
                    "boricalchemy",
                    "sounds/clicky"
                );

            world.PlaySoundAt(
                fireSound,
                byPlayer,
                null,
                true,
                16,
                1f + (float)world.Rand.NextDouble() * 0.1f
            );

            world.Logger.Notification(
                $"BlockTransformer: {currentCode} -> {targetCode}"
            );

            Block targetBlock = world.GetBlock(
                new AssetLocation(targetCode)
            );

            if (targetBlock == null)
            {
                world.Logger.Error(
                    $"BlockTransformer: TARGET DOES NOT EXIST: {targetCode}"
                );

                return true;
            }

            world.BlockAccessor.SetBlock(
                targetBlock.Id,
                blockSel.Position
            );

            world.BlockAccessor.TriggerNeighbourBlockUpdate(
                blockSel.Position
            );

            return true;
        }
    }
}