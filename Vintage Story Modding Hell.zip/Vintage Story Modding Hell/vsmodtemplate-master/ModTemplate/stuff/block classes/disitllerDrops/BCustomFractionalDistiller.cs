﻿using System;
using Vintagestory.API.Common;
using Vintagestory.API.MathTools;
using Vintagestory.API.Datastructures;

namespace BoricAlchemy.blocks
{
    public class BCustomFractionalDistiller : Block
    {

        Random random = new Random();
        public override bool OnBlockInteractStart(IWorldAccessor world, IPlayer byPlayer, BlockSelection blockSel)
        {
            if (world.Side == EnumAppSide.Client) return true;

            if (blockSel == null) return base.OnBlockInteractStart(world, byPlayer, blockSel);

            Vec3d dropPosition = blockSel.Position.ToVec3d().Add(0.5, 0.5, 0.5);
            string currentPath = Code.Path;

            if (currentPath.Contains("fractionaldistillergasoline"))
            {
                SpawnLiquidBeaker(world, dropPosition, "boricalchemy:beaker-blue-fired", "boricalchemy:gasoline", 300);
                SpawnLiquidBeaker(world, dropPosition, "boricalchemy:beaker-blue-fired", "boricalchemy:naphtha", 200);
                SpawnLiquidBeaker(world, dropPosition, "boricalchemy:beaker-blue-fired", "boricalchemy:diesel", 300);
                SpawnLiquidBeaker(world, dropPosition, "boricalchemy:beaker-blue-fired", "boricalchemy:carbolicoil", 200);
                SpawnLiquidBeaker(world, dropPosition, "boricalchemy:beaker-blue-fired", "boricalchemy:mineraloil", 100);
                SpawnSolidItem(world, dropPosition, "boricalchemy:paraffinwax", 3);

                TransitionBlock(world, blockSel.Position, "boricalchemy:fractional_distiller_base-0");
                return true;
            }
            else
            if (currentPath.Contains("fractionaldistillerbenzene"))
            {
                SpawnLiquidBeaker(world, dropPosition, "boricalchemy:beaker-blue-fired", "boricalchemy:cresols", 300);
                SpawnLiquidBeaker(world, dropPosition, "boricalchemy:beaker-blue-fired", "boricalchemy:benzene", 300);
                SpawnLiquidBeaker(world, dropPosition, "boricalchemy:beaker-blue-fired", "boricalchemy:anthraceneoil", 300);
                SpawnLiquidBeaker(world, dropPosition, "boricalchemy:beaker-blue-fired", "boricalchemy:toluene", 300);
                SpawnSolidItem(world, dropPosition, "boricalchemy:phenol", 6);

                TransitionBlock(world, blockSel.Position, "boricalchemy:fractional_distiller_base-0");
                return true;
            }
            else
            if (currentPath.Contains("fractionaldistiller_firewooddone"))
            {
                SpawnLiquidBeaker(world, dropPosition, "boricalchemy:beaker-blue-fired", "boricalchemy:acetone", 100);
                SpawnLiquidBeaker(world, dropPosition, "boricalchemy:beaker-blue-fired", "boricalchemy:methanol", 200);
                SpawnSolidItem(world, dropPosition, "boricalchemy:charcoal", 3);

                // Transition the block state afterward
                TransitionBlock(world, blockSel.Position, "boricalchemy:fractional_distiller_base-0");
                return true;
            }
            else
            if (currentPath.Contains("fractionaldistiller_acetic_and_formic_acid")) // make carboxyl acids - oxygen
            {
                            SpawnLiquidBeaker(world, dropPosition, "boricalchemy:beaker-blue-fired", "boricalchemy:formicacid", 300);
                            SpawnLiquidBeaker(world, dropPosition, "boricalchemy:beaker-blue-fired", "boricalchemy:butyricacid", 150);
                            SpawnLiquidBeaker(world, dropPosition, "boricalchemy:beaker-blue-fired", "boricalchemy:propionicacid", 200);
                            SpawnLiquidBeaker(world, dropPosition, "boricalchemy:beaker-blue-fired", "boricalchemy:valericacid", 100);
                            SpawnLiquidBeaker(world, dropPosition, "boricalchemy:beaker-blue-fired", "game:vinegarportion", 250);
                            SpawnSolidItem(world, dropPosition, "boricalchemy:vanadiumpentoxide", 2);
                            TransitionBlock(world, blockSel.Position, "boricalchemy:fractional_distiller_base-0");
                            return true;
            }
            else
            if (currentPath.Contains("fractionaldistiller_naphtha_cooked")) // make alcohols - hydrogen
                            {
                SpawnLiquidBeaker(world, dropPosition, "boricalchemy:beaker-blue-fired", "boricalchemy:methanol", 250);
                SpawnLiquidBeaker(world, dropPosition, "boricalchemy:beaker-blue-fired", "boricalchemy:butanol", 200);
                SpawnLiquidBeaker(world, dropPosition, "boricalchemy:beaker-blue-fired", "boricalchemy:isopropanol", 200);
                SpawnLiquidBeaker(world, dropPosition, "boricalchemy:beaker-blue-fired", "boricalchemy:cyclohexanol", 100);
                SpawnLiquidBeaker(world, dropPosition, "boricalchemy:beaker-blue-fired", "game:alcoholportion", 250);
                SpawnSolidItem(world, dropPosition, "boricalchemy:vanadiumpentoxide", 2);
                TransitionBlock(world, blockSel.Position, "boricalchemy:fractional_distiller_base-0");
                return true;
            }
            else
            if (currentPath.Contains("fractionaldistiller_fuseloils"))
            {
                SpawnLiquidBeaker(world, dropPosition, "boricalchemy:beaker-blue-fired", "boricalchemy:isoamylalcohol", 150);
                SpawnLiquidBeaker(world, dropPosition, "boricalchemy:beaker-blue-fired", "game:alcoholportion", 300);

                // Transition the block state afterward
                TransitionBlock(world, blockSel.Position, "boricalchemy:fractional_distiller_base-0");
                return true;
            }
            else
            if (currentPath.Contains("fractionaldistillerphelons"))
            {
                SpawnLiquidBeaker(world, dropPosition, "boricalchemy:beaker-blue-fired", "boricalchemy:cresols", 300);

                SpawnSolidItem(world, dropPosition, "boricalchemy:beaker-blue-fired", 1);
                SpawnSolidItem(world, dropPosition, "boricalchemy:naphthalene", 3);


                // Transition the block state afterward
                TransitionBlock(world, blockSel.Position, "boricalchemy:fractional_distiller_base-0");
                return true;
            }
            else
            if (currentPath.Contains("clausvesselcrackedmercury_bucket"))
            {
                SpawnLiquidBeaker(world, dropPosition, "game:woodbucket", "boricalchemy:mercury", 500);

                TransitionBlock(world, blockSel.Position, "boricalchemy:clausvessel");
                return true;
            }
            else
            if (currentPath.Contains("clausvesselcrackedshaleoil_bucket"))
            {
                SpawnLiquidBeaker(world, dropPosition, "game:woodbucket", "boricalchemy:shaleoil", 1000);

                TransitionBlock(world, blockSel.Position, "boricalchemy:clausvessel");
                return true;
            }
            else
            if (currentPath.Contains("clausvesselcracked_leadacetate_bucket"))
            {
                SpawnLiquidBeaker(world, dropPosition, "game:woodbucket", "boricalchemy:acetone", 500);

                TransitionBlock(world, blockSel.Position, "boricalchemy:clausvessel");
                return true;
            }
            else
            if (currentPath.Contains("clausvesselcrackedactivatedcharcoal"))
            {
                SpawnSolidItem(world, dropPosition, "boricalchemy:activatedcharcoal", 8);

                TransitionBlock(world, blockSel.Position, "boricalchemy:clausvessel");
                return true;
            }
            else
            if (currentPath.Contains("clausvesselcrackedphospheruswhite"))
            {
                SpawnSolidItem(world, dropPosition, "boricalchemy:whitephosphorus", 14);

                TransitionBlock(world, blockSel.Position, "boricalchemy:clausvessel");
                return true;
            }
            else
            if (currentPath.Contains("clausvesselcrackedredphospherus"))
            {
                SpawnSolidItem(world, dropPosition, "boricalchemy:phospherus", 12);

                TransitionBlock(world, blockSel.Position, "boricalchemy:clausvessel");
                return true;
            }
            else
            if (currentPath.Contains("clausvesselcrackedsodiumcarbonate"))
            {
                SpawnSolidItem(world, dropPosition, "boricalchemy:sodiumcarbonate", 8);

                TransitionBlock(world, blockSel.Position, "boricalchemy:clausvessel");
                return true;
            }
            else
            if (currentPath.Contains("clausvesselcrackedsulfur"))
            {
                SpawnSolidItem(world, dropPosition, "game:powder-sulfur", 4+ random.Next(2));
                SpawnSolidItem(world, dropPosition, "game:coke", 3+ random.Next(2));
                SpawnSolidItem(world, dropPosition, "boricalchemy:retortcarbon", 2+random.Next(1));


                TransitionBlock(world, blockSel.Position, "boricalchemy:clausvessel");
                return true;
            }
            else
            if (currentPath.Contains("retortdoneformaldehyde"))
            {
                SpawnSolidItem(world, dropPosition, "game:metalchain-silver", 1);
                SpawnLiquidBeaker(world, dropPosition, "game:woodbucket", "boricalchemy:formaldehyde", 1000);

                TransitionBlock(world, blockSel.Position, "boricalchemy:clausvessel");
                return true;
            }
            else
            {
                world.Logger.Warning($"[BoricAlchemy] Interacted with unhandled retort path: {currentPath}");
                return base.OnBlockInteractStart(world, byPlayer, blockSel);
            }
        }

        
        private void SpawnLiquidBeaker(IWorldAccessor world, Vec3d pos, string containerCode, string liquidCode, int amount)
        {
            AssetLocation containerAsset = new AssetLocation(containerCode);
            ItemStack beakerStack = null;

            Item containerItem = world.GetItem(containerAsset);
            if (containerItem != null)
            {
                beakerStack = new ItemStack(containerItem, 1);
            }
            else
            {
                Block containerBlock = world.GetBlock(containerAsset);
                if (containerBlock != null)
                {
                    beakerStack = new ItemStack(containerBlock, 1);
                }
            }

            if (beakerStack == null)
            {
                world.Logger.Error($"[BoricAlchemy] Container asset not found as Item or Block: {containerCode}");
                return;
            }

            ITreeAttribute contentsTree = new TreeAttribute();
            ItemStack liquidStack = null;
            AssetLocation liquidAsset = new AssetLocation(liquidCode);

            Item liquidItem = world.GetItem(liquidAsset);
            if (liquidItem != null)
            {
                liquidStack = new ItemStack(liquidItem, amount);
            }
            else
            {
                Block liquidBlock = world.GetBlock(liquidAsset);
                if (liquidBlock != null)
                {
                    liquidStack = new ItemStack(liquidBlock, amount);
                }
            }

            if (liquidStack != null)
            {
                contentsTree.SetItemstack("0", liquidStack);
                beakerStack.Attributes["contents"] = contentsTree;
            }
            else
            {
                world.Logger.Error($"[BoricAlchemy] Liquid asset not found as Item or Block: {liquidCode}");
            }

            world.SpawnItemEntity(beakerStack, pos);
        }

        private void SpawnSolidItem(IWorldAccessor world, Vec3d pos, string itemCode, int amount)
        {
            AssetLocation assetLoc = new AssetLocation(itemCode);
            ItemStack itemStack = null;

            Item item = world.GetItem(assetLoc);
            if (item != null)
            {
                itemStack = new ItemStack(item, amount);
            }
            else
            {
                Block block = world.GetBlock(assetLoc);
                if (block != null)
                {
                    itemStack = new ItemStack(block, amount);
                }
            }

            if (itemStack != null)
            {
                world.SpawnItemEntity(itemStack, pos);
            }
            else
            {
                world.Logger.Error($"[BoricAlchemy] Solid asset not found as Item or Block: {itemCode}");
            }
        }


        private void TransitionBlock(IWorldAccessor world, BlockPos pos, string nextBlockCode)
        {
            Block nextBlock = world.GetBlock(new AssetLocation(nextBlockCode));
            if (nextBlock != null)
            {
                world.BlockAccessor.SetBlock(nextBlock.Id, pos);
                world.BlockAccessor.TriggerNeighbourBlockUpdate(pos);
            }
            else
            {
                world.Logger.Error($"[BoricAlchemy] Transition target block not found: {nextBlockCode}");
            }
        }
    }
}