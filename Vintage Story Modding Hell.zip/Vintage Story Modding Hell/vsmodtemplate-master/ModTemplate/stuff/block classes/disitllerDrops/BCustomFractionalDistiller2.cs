﻿using System;
using Vintagestory.API.Common;
using Vintagestory.API.MathTools;
using Vintagestory.API.Datastructures;
using System.ComponentModel.Design;

namespace BoricAlchemy.blocks
{
    public class BCustomFractionalDistiller2 : Block
    {

        public string helperFunct(string currentPath)
        {
            string colour = "blue";
            if (currentPath.EndsWith("blue")) { colour = "blue"; }
            if (currentPath.EndsWith("fire")) { colour = "fire"; }
            if (currentPath.EndsWith("black")) { colour = "black"; }
            if (currentPath.EndsWith("brown")) { colour = "brown"; }
            if (currentPath.EndsWith("cream")) { colour = "cream"; }
            if (currentPath.EndsWith("earthyorange")) { colour = "earthyorange"; }
            if (currentPath.EndsWith("gray")) { colour = "gray"; }
            if (currentPath.EndsWith("orange")) { colour = "orange"; }
            if (currentPath.EndsWith("red")) { colour = "red"; }
            if (currentPath.EndsWith("tan")) { colour = "tan"; }
            return (colour);
        }



        Random random = new Random();
        public override bool OnBlockInteractStart(IWorldAccessor world, IPlayer byPlayer, BlockSelection blockSel)
        {
            if (world.Side == EnumAppSide.Client) return true;

            if (blockSel == null) return base.OnBlockInteractStart(world, byPlayer, blockSel);

            Vec3d dropPosition = blockSel.Position.ToVec3d().Add(0.5, 0.5, 0.5);
            string currentPath = Code.Path;

            if (currentPath.Contains("air_distiller_finished-air"))
            {
                string colour = helperFunct(currentPath);

                SpawnSolidItem(world, dropPosition, "boricalchemy:gascontainer-oxygen", 1);
                SpawnSolidItem(world, dropPosition, "boricalchemy:gascontainer-nitrogen", 1);
                SpawnSolidItem(world, dropPosition, "boricalchemy:gascontainer-argon_dilute", 1);
                SpawnSolidItem(world, dropPosition, "boricalchemy:gascontainer-neon_dilute", 1);
                SpawnSolidItem(world, dropPosition, "boricalchemy:gascontainer-xenon_dilute", 1);
                SpawnSolidItem(world, dropPosition, "boricalchemy:gascontainer-krypton_dilute", 1);

                TransitionBlock(world, blockSel.Position, "boricalchemy:fractional_distiller_base-0");
                return true;
            }
            else
            if (currentPath.Contains("airliquifier_finished"))
            {
                string colour = helperFunct(currentPath);
                SpawnSolidItem(world, dropPosition, "boricalchemy:compressor", 1);
                SpawnSolidItem(world, dropPosition, "boricalchemy:cooler", 1);
                SpawnSolidItem(world, dropPosition, "boricalchemy:decompressor", 1);
                SpawnSolidItem(world, dropPosition, "boricalchemy:combustiongeneratordry", 1);
                SpawnLiquidBeaker(world, dropPosition, "boricalchemy:beaker-" + colour + "-fired", "boricalchemy:liquidair", 300);

                TransitionBlock(world, blockSel.Position, "game:air");
                return true;
            }
            else
            if (currentPath.Contains("fractional_distiller_fired-petroleum"))
            {
                string colour = helperFunct(currentPath);

                SpawnLiquidBeaker(world, dropPosition, "boricalchemy:beaker-"+colour+"-fired", "boricalchemy:gasoline", 300);
                SpawnLiquidBeaker(world, dropPosition, "boricalchemy:beaker-"+colour+"-fired", "boricalchemy:naphtha", 200);
                SpawnLiquidBeaker(world, dropPosition, "boricalchemy:beaker-"+colour+"-fired", "boricalchemy:diesel", 300);
                SpawnLiquidBeaker(world, dropPosition, "boricalchemy:beaker-"+colour+"-fired", "boricalchemy:carbolicoil", 200);
                SpawnLiquidBeaker(world, dropPosition, "boricalchemy:beaker-"+colour+"-fired", "boricalchemy:mineraloil", 100);
                SpawnSolidItem(world, dropPosition, "boricalchemy:paraffinwax", 3);

                TransitionBlock(world, blockSel.Position, "boricalchemy:fractional_distiller_base-0");
                return true;
            }
            else
            if (currentPath.Contains("fractional_distiller_fired-blackcoal"))
            {
                string colour = helperFunct(currentPath);

                SpawnLiquidBeaker(world, dropPosition, "boricalchemy:beaker-"+colour+"-fired", "boricalchemy:cresols", 300);
                SpawnLiquidBeaker(world, dropPosition, "boricalchemy:beaker-"+colour+"-fired", "boricalchemy:benzene", 300);
                SpawnLiquidBeaker(world, dropPosition, "boricalchemy:beaker-"+colour+"-fired", "boricalchemy:anthraceneoil", 300);
                SpawnLiquidBeaker(world, dropPosition, "boricalchemy:beaker-"+colour+"-fired", "boricalchemy:toluene", 300);
                SpawnSolidItem(world, dropPosition, "boricalchemy:phenol", 6);

                TransitionBlock(world, blockSel.Position, "boricalchemy:fractional_distiller_base-0");
                return true;
            }
            else
            if (currentPath.Contains("fractional_distiller_fired-firewood"))
            {
                string colour = helperFunct(currentPath);

                SpawnLiquidBeaker(world, dropPosition, "boricalchemy:beaker-"+colour+"-fired", "boricalchemy:acetone", 100);
                SpawnLiquidBeaker(world, dropPosition, "boricalchemy:beaker-"+colour+"-fired", "boricalchemy:methanol", 200);
                SpawnSolidItem(world, dropPosition, "boricalchemy:charcoal", 3);

                // Transition the block state afterward
                TransitionBlock(world, blockSel.Position, "boricalchemy:fractional_distiller_base-0");
                return true;
            }
            else
            if (currentPath.Contains("fractional_distiller_fired-naphtha_acids")) // make carboxyl acids - oxygen
            {
                            string colour = helperFunct(currentPath);

                            SpawnLiquidBeaker(world, dropPosition, "boricalchemy:beaker-"+colour+"-fired", "boricalchemy:formicacid", 300);
                            SpawnLiquidBeaker(world, dropPosition, "boricalchemy:beaker-"+colour+"-fired", "boricalchemy:butyricacid", 150);
                            SpawnLiquidBeaker(world, dropPosition, "boricalchemy:beaker-"+colour+"-fired", "boricalchemy:propionicacid", 200);
                            SpawnLiquidBeaker(world, dropPosition, "boricalchemy:beaker-"+colour+"-fired", "boricalchemy:valericacid", 100);
                            SpawnLiquidBeaker(world, dropPosition, "boricalchemy:beaker-"+colour+"-fired", "game:vinegarportion", 250);
                            SpawnSolidItem(world, dropPosition, "boricalchemy:vanadiumpentoxide", 2);
                            TransitionBlock(world, blockSel.Position, "boricalchemy:fractional_distiller_base-0");
                            return true;
            }
            else
            if (currentPath.Contains("fractional_distiller_fired-naphtha_alcohols")) // make alcohols - hydrogen
                            {
                string colour = helperFunct(currentPath);

                SpawnLiquidBeaker(world, dropPosition, "boricalchemy:beaker-"+colour+"-fired", "boricalchemy:methanol", 250);
                SpawnLiquidBeaker(world, dropPosition, "boricalchemy:beaker-"+colour+"-fired", "boricalchemy:butanol", 200);
                SpawnLiquidBeaker(world, dropPosition, "boricalchemy:beaker-"+colour+"-fired", "boricalchemy:isopropanol", 200);
                SpawnLiquidBeaker(world, dropPosition, "boricalchemy:beaker-"+colour+"-fired", "boricalchemy:cyclohexanol", 100);
                SpawnLiquidBeaker(world, dropPosition, "boricalchemy:beaker-"+colour+"-fired", "game:alcoholportion", 250);
                SpawnSolidItem(world, dropPosition, "boricalchemy:vanadiumpentoxide", 2);
                TransitionBlock(world, blockSel.Position, "boricalchemy:fractional_distiller_base-0");
                return true;
            }
            else
            if (currentPath.Contains("fractional_distiller_fired-ale"))
            {
                string colour = helperFunct(currentPath);

                SpawnLiquidBeaker(world, dropPosition, "boricalchemy:beaker-"+colour+"-fired", "boricalchemy:isoamylalcohol", 150);
                SpawnLiquidBeaker(world, dropPosition, "boricalchemy:beaker-"+colour+"-fired", "game:alcoholportion", 300);

                // Transition the block state afterward
                TransitionBlock(world, blockSel.Position, "boricalchemy:fractional_distiller_base-0");
                return true;
            }
            else
            if (currentPath.Contains("fractional_distiller_fired-carbolicoil"))
            {
                string colour = helperFunct(currentPath);

                SpawnLiquidBeaker(world, dropPosition, "boricalchemy:beaker-"+colour+"-fired", "boricalchemy:cresols", 300);

                SpawnSolidItem(world, dropPosition, "boricalchemy:beaker-"+colour+"-fired", 1);
                SpawnSolidItem(world, dropPosition, "boricalchemy:naphthalene", 3);


                // Transition the block state afterward
                TransitionBlock(world, blockSel.Position, "boricalchemy:fractional_distiller_base-0");
                return true;
            }
            else
            {
                world.Logger.Warning($"[BoricAlchemy] Interacted with unhandled retort path: {currentPath}");
                return base.OnBlockInteractStart(world, byPlayer, blockSel);
            }
        }

        
        private void SpawnLiquidBeaker(IWorldAccessor world, Vec3d pos, string containerCode, string liquidCode, int amount)
        {
            AssetLocation containerAsset = new AssetLocation(containerCode);
            ItemStack beakerStack = null;

            Item containerItem = world.GetItem(containerAsset);
            if (containerItem != null)
            {
                beakerStack = new ItemStack(containerItem, 1);
            }
            else
            {
                Block containerBlock = world.GetBlock(containerAsset);
                if (containerBlock != null)
                {
                    beakerStack = new ItemStack(containerBlock, 1);
                }
            }

            if (beakerStack == null)
            {
                world.Logger.Error($"[BoricAlchemy] Container asset not found as Item or Block: {containerCode}");
                return;
            }

            ITreeAttribute contentsTree = new TreeAttribute();
            ItemStack liquidStack = null;
            AssetLocation liquidAsset = new AssetLocation(liquidCode);

            Item liquidItem = world.GetItem(liquidAsset);
            if (liquidItem != null)
            {
                liquidStack = new ItemStack(liquidItem, amount);
            }
            else
            {
                Block liquidBlock = world.GetBlock(liquidAsset);
                if (liquidBlock != null)
                {
                    liquidStack = new ItemStack(liquidBlock, amount);
                }
            }

            if (liquidStack != null)
            {
                contentsTree.SetItemstack("0", liquidStack);
                beakerStack.Attributes["contents"] = contentsTree;
            }
            else
            {
                world.Logger.Error($"[BoricAlchemy] Liquid asset not found as Item or Block: {liquidCode}");
            }

            world.SpawnItemEntity(beakerStack, pos);
        }

        private void SpawnSolidItem(IWorldAccessor world, Vec3d pos, string itemCode, int amount)
        {
            AssetLocation assetLoc = new AssetLocation(itemCode);
            ItemStack itemStack = null;

            Item item = world.GetItem(assetLoc);
            if (item != null)
            {
                itemStack = new ItemStack(item, amount);
            }
            else
            {
                Block block = world.GetBlock(assetLoc);
                if (block != null)
                {
                    itemStack = new ItemStack(block, amount);
                }
            }

            if (itemStack != null)
            {
                world.SpawnItemEntity(itemStack, pos);
            }
            else
            {
                world.Logger.Error($"[BoricAlchemy] Solid asset not found as Item or Block: {itemCode}");
            }
        }


        private void TransitionBlock(IWorldAccessor world, BlockPos pos, string nextBlockCode)
        {
            Block nextBlock = world.GetBlock(new AssetLocation(nextBlockCode));
            if (nextBlock != null)
            {
                world.BlockAccessor.SetBlock(nextBlock.Id, pos);
                world.BlockAccessor.TriggerNeighbourBlockUpdate(pos);
            }
            else
            {
                world.Logger.Error($"[BoricAlchemy] Transition target block not found: {nextBlockCode}");
            }
        }
    }
}