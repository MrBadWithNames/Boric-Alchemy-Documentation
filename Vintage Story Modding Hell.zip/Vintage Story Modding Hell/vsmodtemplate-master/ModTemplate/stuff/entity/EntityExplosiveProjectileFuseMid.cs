﻿using System;
using System.IO;
using Vintagestory.API.Common;
using Vintagestory.API.Common.Entities;
using Vintagestory.API.Datastructures;
using Vintagestory.API.MathTools;
using Vintagestory.API.Server;

namespace BoricAlchemy.blocks
{
    public class EntityExplosiveProjectileFuseMid : Entity, IProjectile
    {
        protected bool beforeCollided;
        protected long msLaunch;
        protected Vec3d motionBeforeCollide = new Vec3d();
        private bool hasHitEntity = false;
        protected CollisionTester collTester = new CollisionTester();

        public Entity? FiredBy;
        public float Damage;
        public int DamageTier = 0;
        public ItemStack? ProjectileStack;
        public EnumDamageType DamageType = EnumDamageType.BluntAttack;
        public bool IgnoreInvFrames = true;


        public float ThrowYaw { get; set; }

        private float explosionRadius = 4.0f;
        private int injuryRadius = 5;
        private float explosionDamage = 35.0f;

        private bool hasExploded = false;
        private float fuseTimer = 2.5f;

        // Bounce tuning
        private float horizontalBounce = 0.02f;
        private float verticalBounce = 0.05f;

        // Spark Particle Properties
        private SimpleParticleProperties? fuseSparks;

        public override bool IsInteractable
        {
            get { return false; }
        }

        #region IProjectile

        Entity? IProjectile.FiredBy
        {
            get => FiredBy;
            set => FiredBy = value;
        }

        float IProjectile.Damage
        {
            get => Damage;
            set => Damage = value;
        }

        int IProjectile.DamageTier
        {
            get => DamageTier;
            set => DamageTier = value;
        }

        EnumDamageType IProjectile.DamageType
        {
            get => DamageType;
            set => DamageType = value;
        }

        bool IProjectile.IgnoreInvFrames
        {
            get => IgnoreInvFrames;
            set => IgnoreInvFrames = value;
        }

        ItemStack? IProjectile.ProjectileStack
        {
            get => ProjectileStack;
            set => ProjectileStack = value;
        }

        ItemStack? IProjectile.WeaponStack
        {
            get;
            set;
        }

        float IProjectile.DropOnImpactChance
        {
            get;
            set;
        }

        bool IProjectile.DamageStackOnImpact
        {
            get;
            set;
        }

        bool IProjectile.Collectible
        {
            get => false;
            set { }
        }

        bool IProjectile.EntityHit
        {
            get;
        }

        float IProjectile.Weight
        {
            get => Properties.Weight;
            set => Properties.Weight = value;
        }

        bool IProjectile.Stuck
        {
            get => false;
            set { }
        }

        void IProjectile.PreInitialize()
        {
        }

        void IProjectile.SetFromConfig(IProjectileJsonConfig config)
        {
            Damage = config.Damage;
            DamageTier = config.DamageTier;
        }

        #endregion

        // ============================================================
        // INITIALIZE
        // ============================================================

        public override void Initialize(
            EntityProperties properties,
            ICoreAPI api,
            long InChunkIndex3d
        )
        {
            base.Initialize(
                properties,
                api,
                InChunkIndex3d
            );

            

            if (ProjectileStack?.Collectible != null)
            {
                ProjectileStack.ResolveBlockOrItem(World);

                JsonObject attr = ProjectileStack.Collectible.Attributes;
                if (attr != null)
                {
                    if (attr["projectileDamage"].Exists)
                    {
                        Damage = attr["projectileDamage"].AsFloat(Damage);
                    }
                    if (attr["explosionRadius"].Exists)
                    {
                        explosionRadius = attr["explosionRadius"].AsFloat(explosionRadius);
                    }
                    if (attr["injuryRadius"].Exists)
                    {
                        injuryRadius = attr["injuryRadius"].AsInt(injuryRadius);
                    }
                    if (attr["explosionDamage"].Exists)
                    {
                        explosionDamage = attr["explosionDamage"].AsFloat(explosionDamage);
                    }
                    if (attr["fuseDuration"].Exists)
                    {
                        fuseTimer = attr["fuseDuration"].AsFloat(fuseTimer);
                    }
                }
            }

            if (Api.Side == EnumAppSide.Server)
            {
                if (FiredBy != null)
                {
                    WatchedAttributes.SetLong(
                        "firedBy",
                        FiredBy.EntityId
                    );
                }

                WatchedAttributes.SetFloat("damage", Damage);
                WatchedAttributes.SetFloat("explosionRadius", explosionRadius);
                WatchedAttributes.SetInt("injuryRadius", injuryRadius);
                WatchedAttributes.SetFloat("explosionDamage", explosionDamage);
                WatchedAttributes.SetFloat("fuseTimer", fuseTimer);
            }

            if (Api.Side == EnumAppSide.Client)
            {
                FiredBy =
                    Api.World.GetEntityById(
                        WatchedAttributes.GetLong("firedBy")
                    );

                Damage = WatchedAttributes.GetFloat("damage", Damage);
                explosionRadius = WatchedAttributes.GetFloat("explosionRadius", explosionRadius);
                injuryRadius = WatchedAttributes.GetInt("injuryRadius", injuryRadius);
                explosionDamage = WatchedAttributes.GetFloat("explosionDamage", explosionDamage);
                fuseTimer = WatchedAttributes.GetFloat("fuseTimer", fuseTimer);

                // Setup the visual characteristics of the sparks
                InitializeParticles();
            }

            msLaunch =
                World.ElapsedMilliseconds;

            var physics =
                GetBehavior<EntityBehaviorPassivePhysics>();

            ArgumentNullException.ThrowIfNull(physics);

            physics.CollisionYExtra = 0f;
        }

        private void InitializeParticles()
        {
            fuseSparks = new SimpleParticleProperties
            {
                MinQuantity = 1,
                AddQuantity = 2,
                Color = ColorUtil.ToRgba(255, 255, 180, 50), // Bright yellow/orange spark
                MinSize = 0.05f,
                MaxSize = 0.15f,
                SizeEvolve = EvolvingNatFloat.create(EnumTransformFunction.LINEAR, -0.1f), // Shrink over time
                MinVelocity = new Vec3f(-1.5f, 2f, -1.5f),
                AddVelocity = new Vec3f(3f, 3.5f, 3f), // Shoot upward and outward
                GravityEffect = 0.8f, // Fall down slightly
                LifeLength = 0.15f,
                addLifeLength = 0.2f,
                ParticleModel = EnumParticleModel.Quad,
                VertexFlags = 128 // Glow in the dark
            };
        }

        // ============================================================
        // GAME TICK
        // ============================================================

        public override void OnGameTick(float dt)
        {
            base.OnGameTick(dt);

            if (ShouldDespawn || hasExploded)
            {
                return;
            }

            // Spawn sparks on the client side
            if (Api.Side == EnumAppSide.Client && fuseSparks != null)
            {
                // Emit particles relative to the center of the entity's position
                fuseSparks.MinPos = Pos.XYZ.Clone().Add(0, (SelectionBox.Y2)+0.5, 0);
                World.SpawnParticles(fuseSparks);

                Entity entity = this;
                IWorldAccessor world = entity.World;
                if ((float)world.Rand.NextDouble() < 0.2)
                {
                        AssetLocation fireSound = new AssetLocation("boricalchemy", "sounds/littlehiss");

                    world.PlaySoundAt(
                        fireSound,
                        entity,
                        null,
                        true,
                        32,
                        2f + (float)world.Rand.NextDouble() * 0.1f
                        
                    );
                }
            }

            EntityPos pos = Pos;

            // --------------------------------------------------------
            // Single Entity Impact Check
            // --------------------------------------------------------

            if (!hasHitEntity)
            {
                Entity nearEntity = World.GetNearestEntity(pos.XYZ, 5f, 5f, (e) => {
                    if (e.EntityId == this.EntityId || !e.Alive || !e.IsInteractable)
                    {
                        return false;
                    }

                    if (FiredBy != null && e.EntityId == FiredBy.EntityId && World.ElapsedMilliseconds - msLaunch < 500)
                    {
                        return false;
                    }

                    double dist = e.SelectionBox
                        .ToDouble()
                        .Translate(e.Pos.X, e.Pos.Y, e.Pos.Z)
                        .ShortestDistanceFrom(Pos.X, Pos.Y, Pos.Z);

                    return dist < 0.5f;
                });

                if (nearEntity != null)
                {
                    hasHitEntity = true;
                    HitEntity(nearEntity);
                }
            }

            // --------------------------------------------------------
            // Fuse & Motion
            // --------------------------------------------------------
            fuseTimer -= dt;

            if (fuseTimer <= 0f)
            {
                Explode();
                return;
            }

            beforeCollided = false;

            motionBeforeCollide.Set(
                pos.Motion.X,
                pos.Motion.Y,
                pos.Motion.Z
            );
        }

        // ============================================================
        // ENTITY HIT
        // ============================================================

        private void HitEntity(Entity entity)
        {
            if (hasExploded)
            {
                return;
            }

            if (!entity.Alive)
            {
                return;
            }

            // --------------------------------------------------------
            // Damage source
            // --------------------------------------------------------

            DamageSource damageSource =
                new DamageSource()
                {
                    Source =
                        FiredBy is EntityPlayer
                            ? EnumDamageSource.Player
                            : EnumDamageSource.Entity,


                    SourceEntity = this,
                    CauseEntity = FiredBy,

                    Type = DamageType,

                    DamageTier = DamageTier,

                    YDirKnockbackDiv = 3,

                    IgnoreInvFrames =
                        false
                };


            // --------------------------------------------------------
            // Impact sound
            // --------------------------------------------------------

            World.PlaySoundAt(
                new AssetLocation("sounds/thud"),
                this,
                null,
                false,
                32
            );



            // --------------------------------------------------------
            // Optional impact bounce.
            // --------------------------------------------------------

            if (motionBeforeCollide.Length() > 0.00001)
            {
                Vec3d velocity =
                    motionBeforeCollide.Clone();

                velocity.Normalize();

                double speed =
                    motionBeforeCollide.Length();

                Pos.Motion.X =
                    -velocity.X *
                    speed *
                    horizontalBounce;

                Pos.Motion.Y =
                    Math.Abs(
                        speed *
                        verticalBounce
                    );

                Pos.Motion.Z =
                    -velocity.Z *
                    speed *
                    horizontalBounce;
            }

            // Notify clients of the new velocity.
            WatchedAttributes.MarkAllDirty();
        }

        // ============================================================
        // BLOCK COLLISION
        // ============================================================

        public override void OnCollided()
        {
            EntityPos pos = Pos;

            if (
                !beforeCollided &&
                World is IServerWorldAccessor
            )
            {
                float strength =
                    GameMath.Clamp(
                        (float)
                        motionBeforeCollide.Length() * 4,
                        0,
                        1
                    );

                // ----------------------------------------------------
                // Horizontal collision
                // ----------------------------------------------------

                if (CollidedHorizontally)
                {
                    float xdir =
                        pos.Motion.X == 0
                            ? -1
                            : 1;

                    float zdir =
                        pos.Motion.Z == 0
                            ? -1
                            : 1;

                    pos.Motion.X =
                        xdir *
                        motionBeforeCollide.X *
                        horizontalBounce;

                    pos.Motion.Z =
                        zdir *
                        motionBeforeCollide.Z *
                        horizontalBounce;
                }

                // ----------------------------------------------------
                // Vertical collision
                // ----------------------------------------------------

                if (
                    CollidedVertically &&
                    motionBeforeCollide.Y <= 0
                )
                {
                    pos.Motion.Y =
                        GameMath.Clamp(
                            motionBeforeCollide.Y *
                            -verticalBounce,
                            -0.1f,
                            0.1f
                        );
                }

                // Resend position/velocity to clients.
                WatchedAttributes.MarkAllDirty();
            }

            beforeCollided = true;
        }

        // ============================================================
        // EXPLOSION
        // ============================================================
        private void Explode()
        {
            if (hasExploded || Api == null)
            {
                return;
            }

            hasExploded = true;

            BlockPos pos = Pos.AsBlockPos;
            Vec3d currentPos = Pos.XYZ;

            if (Api.World is IServerWorldAccessor serverWorld)
            {
                // 1. Handle block destruction and shockwave visuals via vanilla
                serverWorld.CreateExplosion(
                    pos,
                    EnumBlastType.EntityBlast,
                    explosionRadius,
                    injuryRadius
                );

                // 2. Handle guaranteed custom entity damage scaled via attributes
                var entities = serverWorld.GetEntitiesAround(currentPos, injuryRadius, injuryRadius, (e) => e.Alive && e.IsInteractable);

                foreach (var entity in entities)
                {
                    double distance = entity.Pos.XYZ.DistanceTo(currentPos);
                    if (distance > injuryRadius) continue;

                    // Linear falloff with a minimum damage floor of 25% so edge hits still sting
                    float damageFactor = Math.Max(0.25f, 1f - (float)(distance / injuryRadius));
                    float finalDamage = explosionDamage * damageFactor;

                    DamageSource damageSource = new DamageSource()
                    {
                        Source = EnumDamageSource.Entity,
                        SourceEntity = this,
                        CauseEntity = FiredBy,
                        Type = EnumDamageType.BluntAttack,
                        DamageTier = DamageTier,
                        IgnoreInvFrames = true
                    };

                    entity.ReceiveDamage(damageSource, finalDamage);
                }
            }

            if (Alive)
            {
                Die(EnumDespawnReason.Combusted);
            }
        }

        // ============================================================
        // NETWORKING
        // ============================================================

        public override void ToBytes(
            BinaryWriter writer,
            bool forClient
        )
        {
            base.ToBytes(
                writer,
                forClient
            );

            writer.Write(
                beforeCollided
            );

            ProjectileStack?.ToBytes(
                writer
            );
        }

        public override void FromBytes(
            BinaryReader reader,
            bool fromServer
        )
        {
            base.FromBytes(
                reader,
                fromServer
            );

            beforeCollided =
                reader.ReadBoolean();

            ProjectileStack =
                World == null
                    ? new ItemStack(reader)
                    : new ItemStack(
                        reader,
                        World
                    );
        }
    }
}