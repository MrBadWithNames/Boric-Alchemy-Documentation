﻿using System;
using Vintagestory.API.Client;
using Vintagestory.API.Common;
using Vintagestory.API.Common.Entities;
using Vintagestory.API.MathTools;
using Vintagestory.GameContent;

namespace BoricAlchemy.blocks
{
    public class EntityMolotov : EntityProjectile
    {
        private float explosionRadius = 3.0f;
        private int injuryRadius = 5;
        private bool hasExploded = false;

        public override void OnGameTick(float deltaTime)
        {
            if (Api?.Side != EnumAppSide.Server || hasExploded)
            {
                base.OnGameTick(deltaTime);
                return;
            }

            Vec3d currentPos = Pos.XYZ;

            // --- SPAWN FLYING FIRE & SMOKE TRAIL ---
            if (Api.World is Vintagestory.API.Server.IServerWorldAccessor serverWorld)
            {
                int trailColor = ColorUtil.ColorFromRgba(20, 140, 255, 255); // Fiery orange-red (BGRA)

                SimpleParticleProperties trailParticles = new SimpleParticleProperties(
                    2f, 4f,                                                 // Quantity per tick
                    trailColor,
                    currentPos.AddCopy(-0.1, -0.1, -0.1),
                    currentPos.AddCopy(0.1, 0.1, 0.1),
                    new Vec3f(-0.5f, -0.5f, -0.5f),
                    new Vec3f(0.5f, 0.5f, 0.5f),
                    0.4f,                                                   // Short lifespan
                    0.5f,                                                   // Slight gravity
                    0.6f, 1.0f,                                             // Size
                    EnumParticleModel.Quad
                )
                {
                    VertexFlags = 255 // Full self-illumination/glow
                };
                trailParticles.SizeEvolve = new EvolvingNatFloat(EnumTransformFunction.LINEAR, -0.02f);
                serverWorld.SpawnParticles(trailParticles);
            }

            Entity targetEntity = Api.World.GetNearestEntity(currentPos, 1.5f, 1.5f, (entity) =>
            {
                if (entity.EntityId == this.EntityId || !entity.Alive || entity == FiredBy || entity is EntityProjectile)
                    return false;

                Cuboidd entityBox = entity.SelectionBox.ToDouble().Translate(entity.Pos.XYZ);

                if (entityBox.Contains(currentPos.X, currentPos.Y, currentPos.Z)) return true;

                Vec3d midPos = currentPos.AddCopy(Pos.Motion.X * deltaTime * 10, Pos.Motion.Y * deltaTime * 10, Pos.Motion.Z * deltaTime * 10);
                if (entityBox.Contains(midPos.X, midPos.Y, midPos.Z)) return true;

                Vec3d futurePos = currentPos.AddCopy(Pos.Motion.X * deltaTime * 20, Pos.Motion.Y * deltaTime * 20, Pos.Motion.Z * deltaTime * 20);
                if (entityBox.Contains(futurePos.X, futurePos.Y, futurePos.Z)) return true;

                return false;
            });

            if (targetEntity != null)
            {
                Explode();
                return;
            }

            base.OnGameTick(deltaTime);

            double speed = Pos.Motion.Length();
            if (Collided || !Alive || speed < 0.01)
            {
                Explode();
            }
        }

        private void Explode()
        {
            if (hasExploded || Api == null) return;
            hasExploded = true;

            BlockPos pos = Pos.AsBlockPos;
            Vec3d currentPos = Pos.XYZ;

            if (Api.World is Vintagestory.API.Server.IServerWorldAccessor serverWorld)
            {
                int flameColorA = ColorUtil.ColorFromRgba(20, 140, 255, 255);
                int flameColorB = ColorUtil.ColorFromRgba(50, 210, 255, 255);
                int flameColorC = ColorUtil.ColorFromRgba(10, 80, 230, 255);
                int smokeColor = ColorUtil.ColorFromRgba(40, 40, 40, 200);

                // --- FLAME BATCH A ---
                SimpleParticleProperties flameParticlesA = new SimpleParticleProperties(
                    8f, 12f,
                    flameColorA,
                    currentPos.AddCopy(-0.5, 0, -0.5),
                    currentPos.AddCopy(0.5, 1.0, 0.5),
                    new Vec3f(-3f, 2f, -3f),
                    new Vec3f(3f, 6f, 3f),
                    1.3f,
                    2.2f,
                    0.5f, 1.3f,
                    EnumParticleModel.Quad
                )
                {
                    VertexFlags = 255 // Max glow
                };
                flameParticlesA.SizeEvolve = new EvolvingNatFloat(EnumTransformFunction.LINEAR, -0.013f);
                serverWorld.SpawnParticles(flameParticlesA);

                // --- FLAME BATCH B ---
                SimpleParticleProperties flameParticlesB = new SimpleParticleProperties(
                    6f, 10f,
                    flameColorB,
                    currentPos.AddCopy(-0.5, 0, -0.5),
                    currentPos.AddCopy(0.5, 1.0, 0.5),
                    new Vec3f(-3f, 2f, -3f),
                    new Vec3f(3f, 6f, 3f),
                    1.35f,
                    2.2f,
                    0.5f, 1.3f,
                    EnumParticleModel.Quad
                )
                {
                    VertexFlags = 255
                };
                flameParticlesB.SizeEvolve = new EvolvingNatFloat(EnumTransformFunction.LINEAR, -0.012f);
                serverWorld.SpawnParticles(flameParticlesB);

                // --- FLAME BATCH C ---
                SimpleParticleProperties flameParticlesC = new SimpleParticleProperties(
                    6f, 10f,
                    flameColorC,
                    currentPos.AddCopy(-0.5, 0, -0.5),
                    currentPos.AddCopy(0.5, 1.0, 0.5),
                    new Vec3f(-3f, 2f, -3f),
                    new Vec3f(3f, 6f, 3f),
                    1.25f,
                    2.2f,
                    0.5f, 1.2f,
                    EnumParticleModel.Quad
                )
                {
                    VertexFlags = 255
                };
                flameParticlesC.SizeEvolve = new EvolvingNatFloat(EnumTransformFunction.LINEAR, -0.01f);
                serverWorld.SpawnParticles(flameParticlesC);

                // --- THICK DARK SMOKE PARTICLES ---
                SimpleParticleProperties smokeParticles = new SimpleParticleProperties(
                    25f, 35f,
                    smokeColor,
                    currentPos.AddCopy(-0.7, -0.5, -0.7),
                    currentPos.AddCopy(0.7, 0.5, 0.7),
                    new Vec3f(-1.5f, 0.5f, -1.5f),
                    new Vec3f(1.5f, 1.5f, 1.5f),
                    2.5f,
                    -0.05f,
                    1.8f, 2.5f,
                    EnumParticleModel.Quad
                );
                smokeParticles.SizeEvolve = new EvolvingNatFloat(EnumTransformFunction.LINEAR, 1.5f);
                smokeParticles.OpacityEvolve = new EvolvingNatFloat(EnumTransformFunction.LINEAR, -0.25f);
                serverWorld.SpawnParticles(smokeParticles);

                Entity[] entitiesCloseBy = Api.World.GetEntitiesAround(
                    currentPos,
                    injuryRadius,
                    injuryRadius,
                    (entity) => entity.Alive && entity.EntityId != this.EntityId
                );

                foreach (var entity in entitiesCloseBy)
                {
                    float distance = (float)entity.Pos.XYZ.DistanceTo(currentPos);
                    float damageMultiplier = Math.Max(0, 1.0f - (distance / injuryRadius));

                    entity.Ignite();
                }
            }

            if (Alive)
            {
                Entity entity = this;
                IWorldAccessor world = entity.World;

                AssetLocation fireSound = new AssetLocation("boricalchemy", "sounds/bottlecrash");

                world.PlaySoundAt(
                    fireSound,
                    entity,
                    null,
                    true,
                    32,
                    1f + (float)world.Rand.NextDouble() * 0.1f
                );

                this.Die(EnumDespawnReason.Combusted);
            }
        }
    }
}