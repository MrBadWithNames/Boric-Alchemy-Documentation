﻿using Vintagestory.API.Client;
using Vintagestory.API.Common;
using Vintagestory.API.MathTools;
using Vintagestory.GameContent;

namespace BoricAlchemy
{
    public class MyCustomPotRenderer : IInFirepitRenderer
    {
        private ICoreClientAPI capi;
        private MeshRef meshRef;

        public MyCustomPotRenderer(ICoreClientAPI capi, ItemStack stack, BlockPos pos, bool forOutputSlot)
        {
            this.capi = capi;

            var shape = capi.TesselatorManager.GetCachedShape(new AssetLocation("game:block/clay/storagevessel"));

            if (shape != null)
            {
                MeshData meshData;
                // Pass the Collectible (from your stack) instead of the AssetLocation
                capi.Tesselator.TesselateShape(stack.Collectible, shape, out meshData);
                this.meshRef = capi.Render.UploadMesh(meshData);
            }
        }

        // Required IRenderer members
        public double RenderOrder => 0.5;
        public int RenderRange => 24;

        public void OnRenderFrame(float deltaTime, EnumRenderStage stage)
        {
            if (stage != EnumRenderStage.Opaque || meshRef == null) return;
            capi.Render.RenderMesh(meshRef);
        }

        // Required IInFirepitRenderer members
        public void OnUpdate(float dt) { }
        public void OnCookingComplete() { }

        // Required IDisposable member
        public void Dispose()
        {
            meshRef?.Dispose();
        }
    }
}