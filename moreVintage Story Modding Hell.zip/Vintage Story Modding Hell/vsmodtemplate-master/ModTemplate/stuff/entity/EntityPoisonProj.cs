﻿using System;
using Vintagestory.API.Client;
using Vintagestory.API.Common;
using Vintagestory.API.Common.Entities;
using Vintagestory.API.MathTools;
using Vintagestory.GameContent;

namespace BoricAlchemy.blocks
{
    public class EntityPoisonProj : EntityProjectile
    {
        private float explosionRadius = 3.0f;
        private float injuryRadius = 2.0f;
        private bool hasExploded = false;

        // --- Configurable Stats ---
        private float poisonDuration = 10f;
        private float poisonInterval = 2f;
        private float poisonDamage = 3f;
        private float speedModifier = 1.0f; // 1.0 = normal speed, < 1.0 = slowed (glue effect)
        private int effectId = 1;           // Unique ID to separate acid, glue, etc.

        float partRed = 245f;
        float partGreen = 245f;
        float partBlue = 245f;

        public override void Initialize(EntityProperties properties, ICoreAPI api, long InChunkIndex3d)
        {
            base.Initialize(properties, api, InChunkIndex3d);

            poisonDuration = properties.Attributes?["poisonDuration"].AsFloat(10f) ?? 10f;
            poisonInterval = properties.Attributes?["poisonInterval"].AsFloat(2f) ?? 2f;
            poisonDamage = properties.Attributes?["poisonDamage"].AsFloat(3f) ?? 3f;
            injuryRadius = properties.Attributes?["injuryRadius"].AsFloat(2f) ?? 2f;
            speedModifier = properties.Attributes?["speedModifier"].AsFloat(1.0f) ?? 1.0f;
            effectId = properties.Attributes?["effectId"].AsInt(1) ?? 1;

            partRed = properties.Attributes?["partRed"].AsFloat(245f) ?? 245f;
            partGreen = properties.Attributes?["partGreen"].AsFloat(245f) ?? 245f;
            partBlue = properties.Attributes?["partBlue"].AsFloat(245f) ?? 245f;
        }

        public override void OnGameTick(float deltaTime)
        {
            if (Api?.Side != EnumAppSide.Server || hasExploded)
            {
                base.OnGameTick(deltaTime);
                return;
            }

            base.OnGameTick(deltaTime);

            if (hasExploded || !Alive) return;

            Vec3d currentPos = Pos.XYZ;

            Entity targetEntity = Api.World.GetNearestEntity(currentPos, 1.5f, 1.5f, (entity) =>
            {
                if (entity.EntityId == this.EntityId || !entity.Alive || entity == FiredBy || entity is EntityProjectile)
                    return false;

                Cuboidd entityBox = entity.SelectionBox.ToDouble().Translate(entity.Pos.XYZ);
                if (entityBox.Contains(currentPos.X, currentPos.Y, currentPos.Z)) return true;

                return false;
            });

            if (targetEntity != null)
            {
                Explode();
                return;
            }

            double speed = Pos.Motion.Length();
            if (Collided || !Alive || speed < 0.01)
            {
                Explode();
            }
        }

        private void Explode()
        {
            if (hasExploded || Api == null) return;
            hasExploded = true;

            Vec3d currentPos = Pos.XYZ;

            if (Api.World is Vintagestory.API.Server.IServerWorldAccessor serverWorld)
            {
                int splashColor = ColorUtil.ColorFromRgba((int)partBlue, (int)partGreen, (int)partRed, 200);

                SimpleParticleProperties splashParticles = new SimpleParticleProperties(
                    20f, 35f,
                    splashColor,
                    currentPos.AddCopy(-0.4, 0.0, -0.4),
                    currentPos.AddCopy(0.4, 0.6, 0.4),
                    new Vec3f(-2f, 1f, -2f),
                    new Vec3f(2f, 4f, 2f),
                    0.5f,
                    1.2f,
                    0.15f, 0.35f,
                    EnumParticleModel.Quad
                );

                splashParticles.SizeEvolve = new EvolvingNatFloat(EnumTransformFunction.LINEAR, -0.3f);
                splashParticles.OpacityEvolve = new EvolvingNatFloat(EnumTransformFunction.LINEAR, -200f);

                serverWorld.SpawnParticles(splashParticles);

                Entity[] entitiesCloseBy = Api.World.GetEntitiesAround(
                    currentPos,
                    injuryRadius,
                    injuryRadius,
                    (entity) => entity.Alive && entity.EntityId != this.EntityId
                );

                foreach (var entity in entitiesCloseBy)
                {
                    float distance = (float)entity.Pos.XYZ.DistanceTo(currentPos);
                    float damageMultiplier = Math.Max(0, 1.0f - (distance / injuryRadius));

                    var poisonBehavior = entity.GetBehavior<EntityBehaviorPoison>();

                    // If the entity doesn't have the behavior container yet, add it
                    if (poisonBehavior == null)
                    {
                        poisonBehavior = new EntityBehaviorPoison(entity);
                        entity.AddBehavior(poisonBehavior);
                    }

                    // Register or refresh this specific effect ID inside the behavior
                    poisonBehavior.AddOrRefreshEffect(
                        effectId,
                        poisonDuration,
                        poisonInterval,
                        poisonDamage * damageMultiplier,
                        (int)partRed,
                        (int)partGreen,
                        (int)partBlue,
                        speedModifier
                    );
                }
            }

            if (Alive)
            {
                Entity entity = this;
                IWorldAccessor world = entity.World;

                AssetLocation fireSound = new AssetLocation("boricalchemy", "sounds/glasssmash");

                world.PlaySoundAt(
                    fireSound,
                    entity,
                    null,
                    true,
                    32,
                    1f + (float)world.Rand.NextDouble() * 0.1f
                );

                this.Die(EnumDespawnReason.Combusted);
            }
        }
    }
}