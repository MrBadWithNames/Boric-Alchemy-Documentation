﻿using System;
using Vintagestory.API.Common;
using Vintagestory.API.Common.Entities;
using Vintagestory.API.MathTools;
using Vintagestory.GameContent;

namespace BoricAlchemy.blocks
{
    public class EntityExplosiveProjectile : EntityProjectile
    {
        private float explosionRadius = 3.0f;
        private int injuryRadius = 4;
        private bool hasExploded = false;

        public override void OnGameTick(float deltaTime)
        {
            if (Api?.Side != EnumAppSide.Server || hasExploded)
            {
                base.OnGameTick(deltaTime);
                return;
            }

            Vec3d currentPos = Pos.XYZ;
            Entity targetEntity = Api.World.GetNearestEntity(currentPos, 1.5f, 1.5f, (entity) =>
            {
                if (entity.EntityId == this.EntityId || !entity.Alive || entity == FiredBy || entity is EntityProjectile)
                    return false;

                Cuboidd entityBox = entity.SelectionBox.ToDouble().Translate(entity.Pos.XYZ);

                if (entityBox.Contains(currentPos.X, currentPos.Y, currentPos.Z)) return true;

                Vec3d midPos = currentPos.AddCopy(Pos.Motion.X * deltaTime * 10, Pos.Motion.Y * deltaTime * 10, Pos.Motion.Z * deltaTime * 10);
                if (entityBox.Contains(midPos.X, midPos.Y, midPos.Z)) return true;

                Vec3d futurePos = currentPos.AddCopy(Pos.Motion.X * deltaTime * 20, Pos.Motion.Y * deltaTime * 20, Pos.Motion.Z * deltaTime * 20);
                if (entityBox.Contains(futurePos.X, futurePos.Y, futurePos.Z)) return true;

                return false;
            });

            if (targetEntity != null)
            {
                Explode();
                return;
            }

            base.OnGameTick(deltaTime);

            double speed = Pos.Motion.Length();
            if (Collided || !Alive || speed < 0.01)
            {
                Explode();
            }
        }

        private void Explode()
        {
            if (hasExploded || Api == null) return;
            hasExploded = true;

            BlockPos pos = Pos.AsBlockPos;
            Vec3d currentPos = Pos.XYZ;

            if (Api.World is Vintagestory.API.Server.IServerWorldAccessor serverWorld)
            {
                Entity[] entitiesCloseBy = Api.World.GetEntitiesAround(
                    currentPos,
                    injuryRadius,
                    injuryRadius,
                    (entity) => entity.Alive && entity.EntityId != this.EntityId
                );

                foreach (var entity in entitiesCloseBy)
                {
                    float distance = (float)entity.Pos.XYZ.DistanceTo(currentPos);
                    float damageMultiplier = Math.Max(0, 1.0f - (distance / injuryRadius));

                    float baseDamage = 35.0f;
                    float finalDamage = baseDamage * damageMultiplier;

                    entity.ReceiveDamage(new DamageSource()
                    {
                        Source = EnumDamageSource.Explosion,
                        SourceEntity = FiredBy,
                        Type = EnumDamageType.Injury
                    }, finalDamage);
                }

                serverWorld.CreateExplosion(
                    pos,
                    EnumBlastType.EntityBlast,
                    explosionRadius,
                    injuryRadius
                );
            }

            if (Alive)
            {
                this.Die(EnumDespawnReason.Combusted);
            }
        }
    }
}