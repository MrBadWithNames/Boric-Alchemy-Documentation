﻿using Vintagestory.API.Common;
using Vintagestory.API.Config;
using Vintagestory.API.Datastructures;

namespace BoricAlchemy.blocks
{
    public class BECustomTimedTransform : BlockEntity
    {
        int ticksLeft = -1; // Default to -1 to detect if it hasn't been loaded yet
        AssetLocation decayBlockCode;
        bool isInitializedFromAttributes = false;

        /* lifespanTicks    = how long block lives
         * decayBlock       = what block it turns into
         * updateNeighbours = update neighbours or not
         * probabilityHurdle = 0-1 odds to beat to become the next block lest it resets
         */
        public override void Initialize(ICoreAPI api)
        {
            base.Initialize(api);

            if (Block.Attributes != null)
            {
                // ONLY set ticksLeft to default if FromTreeAttributes didn't already load a saved value
                if (!isInitializedFromAttributes || ticksLeft == -1)
                {
                    ticksLeft = Block.Attributes["lifespanTicks"].AsInt(100);
                }

                string code = Block.Attributes["decayBlock"].AsString("game:air");
                decayBlockCode = new AssetLocation(code);
            }

            if (api.Side == EnumAppSide.Server)
            {
                // Runs every 50 milliseconds
                RegisterGameTickListener(OnTick, 50);
            }
        }

        private void OnTick(float dt)
        {
            ticksLeft--;
            MarkDirty();

            if (ticksLeft <= 0)
            {
                Block nextBlock = Api.World.GetBlock(decayBlockCode);
                if (nextBlock == null) nextBlock = Api.World.GetBlock(new AssetLocation("game:air"));

                bool updateNeighbours = Block.Attributes["updateNeighbours"].AsBool(true);
                float randomHurdle = Block.Attributes["probabilityHurdle"].AsFloat(1.0f);

                if (Api.World.Rand.NextDouble() > randomHurdle)
                {
                    Api.World.BlockAccessor.SetBlock(nextBlock.BlockId, Pos);
                    Api.World.BlockAccessor.MarkBlockDirty(Pos);
                    if (updateNeighbours)
                    {
                        Api.World.BlockAccessor.TriggerNeighbourBlockUpdate(Pos);
                    }
                }
                else
                {
                    // Reset timer if the probability hurdle failed
                    ticksLeft = Block.Attributes["lifespanTicks"].AsInt(100);
                    MarkDirty();
                }
            }
        }

        // Called when saving data to the world file
        public override void ToTreeAttributes(ITreeAttribute tree)
        {
            base.ToTreeAttributes(tree);
            tree.SetInt("ticksLeft", ticksLeft);
        }

        public override void FromTreeAttributes(ITreeAttribute tree, IWorldAccessor world)
        {
            base.FromTreeAttributes(tree, world);

            if (tree.HasAttribute("ticksLeft"))
            {
                ticksLeft = tree.GetInt("ticksLeft");
                isInitializedFromAttributes = true;
            }
        }
    }
}