﻿using System;
using Vintagestory.API.Common;
using Vintagestory.API.Common.Entities;
using Vintagestory.API.MathTools;

namespace BoricAlchemy.blocks
{
    public class BECustomAOEDamage : BlockEntity
    {
        // How often to damage (in milliseconds)
        private long tickListenerId;

        public override void Initialize(ICoreAPI api)
        {
            base.Initialize(api);

            // Register a tick that runs every 500ms (twice a second)
            // Only run damage logic on the server!
            if (api.Side == EnumAppSide.Server)
            {
                tickListenerId = RegisterGameTickListener(OnTick, 1000);
            }
        }

        private void OnTick(float dt)
        {
            float radius = Block.Attributes["AOERange"].AsFloat(1.0f);
            Entity[] entities = Api.World.GetEntitiesAround(Pos.ToVec3d(), radius, radius, (e) => true);

            foreach (var entity in entities)
            {
                // 2. Apply damage
                // DamageSource: 
                // Type.Internal = bypasses some armor
                // Type.Injury = standard physical hit
                float damage = Block.Attributes["areaDamage"].AsFloat(0.0f);
                entity.ReceiveDamage(new DamageSource()
                {
                    Source = EnumDamageSource.Block,
                    SourceBlock = Block,
                    SourcePos = Pos.ToVec3d(),
                    Type = EnumDamageType.Injury
                }, damage); // 0.5 HP = 1/4 of a heart
            }
        }

        public override void OnBlockRemoved()
        {
            base.OnBlockRemoved();
            UnregisterGameTickListener(tickListenerId);
        }
    }
}