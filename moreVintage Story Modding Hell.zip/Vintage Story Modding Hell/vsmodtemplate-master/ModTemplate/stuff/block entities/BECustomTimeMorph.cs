﻿using Vintagestory.API.Common;
using Vintagestory.API.Datastructures;

namespace BoricAlchemy.blocks
{
    public class BECustomTimeMorph : BlockEntity
    {
        // Tracks the exact in-game day number when this block should change
        double targetTotalDays = -1;
        AssetLocation decayBlockCode;

        public override void Initialize(ICoreAPI api)
        {
            base.Initialize(api);

            if (Block.Attributes != null)
            {
                string code = Block.Attributes["decayBlock"].AsString("game:air");
                decayBlockCode = new AssetLocation(code);

                // If targetTotalDays is still -1, it means this is a brand new block placed by a player
                if (targetTotalDays < 0)
                {
                    // Get lifespan in in-game days from attributes (e.g., 1.0 for a full day, 0.5 for half)
                    float lifespanInDays = Block.Attributes["lifespanDays"].AsFloat(1.0f);

                    // Current in-game day + lifespan = our deadline date
                    targetTotalDays = api.World.Calendar.TotalDays + lifespanInDays;
                }
            }

            if (api.Side == EnumAppSide.Server)
            {
                // Check only once every 5000ms (5 seconds). Way better for server performance!
                RegisterGameTickListener(CheckTime, 5000);
            }
        }

        private void CheckTime(float dt)
        {
            // Is the current calendar date greater than or equal to our target date?
            if (Api.World.Calendar.TotalDays >= targetTotalDays)
            {
                Block nextBlock = Api.World.GetBlock(decayBlockCode);
                if (nextBlock == null) nextBlock = Api.World.GetBlock(new AssetLocation("game:air"));

                Api.World.BlockAccessor.SetBlock(nextBlock.BlockId, Pos);
                Api.World.BlockAccessor.MarkBlockDirty(Pos);

                if (Block.Attributes["updateNeighbours"].AsBool(true))
                {
                    Api.World.BlockAccessor.TriggerNeighbourBlockUpdate(Pos);
                }
            }
        }

        public override void ToTreeAttributes(ITreeAttribute tree)
        {
            base.ToTreeAttributes(tree);
            // Doubles need to use SetDouble
            tree.SetDouble("targetTotalDays", targetTotalDays);
        }

        public override void FromTreeAttributes(ITreeAttribute tree, IWorldAccessor world)
        {
            base.FromTreeAttributes(tree, world);
            if (tree.HasAttribute("targetTotalDays"))
            {
                targetTotalDays = tree.GetDouble("targetTotalDays");
            }
        }
    }
}