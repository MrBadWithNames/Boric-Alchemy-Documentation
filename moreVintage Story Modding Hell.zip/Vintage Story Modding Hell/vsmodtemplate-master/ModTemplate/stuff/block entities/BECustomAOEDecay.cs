﻿using Vintagestory.API.Common;
using Vintagestory.API.Common.Entities;
using Vintagestory.API.Config;
using Vintagestory.API.Datastructures;
using Vintagestory.GameContent;

namespace BoricAlchemy.blocks
{
    public class BECustomAOEDecay : BlockEntity
    {
        //storing the default tick in case i fuck up
        int ticksLeft = 100;
        private long tickListenerId;
        AssetLocation decayBlockCode; // To store our result block

        public override void Initialize(ICoreAPI api)
        {
            base.Initialize(api);

            if (Block.Attributes != null) //making sure there are attributes 
            {
                // Get the lifespan, 100 if missing
                ticksLeft = Block.Attributes["lifespanTicks"].AsInt(100);

                // Get the block code string, "game:air" if missing~
                string code = Block.Attributes["decayBlock"].AsString("game:air");
                decayBlockCode = new AssetLocation(code);
            }

            if (api.Side == EnumAppSide.Server)
            {
                RegisterGameTickListener(OnTick, 150); //but whhhhyyyy 50? Is it a time interval or are we just doing 50 time?!
                tickListenerId = RegisterGameTickListener(OnTick, 2000);
            }

        }

        private void OnTick(float dt)
        {
            float radius = Block.Attributes["AOERange"].AsFloat(1.0f);
            Entity[] entities = Api.World.GetEntitiesAround(Pos.ToVec3d(), radius, radius, (e) => true);

            foreach (var entity in entities)
            {
                // 2. Apply damage
                // DamageSource: 
                // Type.Internal = bypasses some armor
                // Type.Injury = standard physical hit

                bool isPlayer = (entity.GetType() == typeof(EntityPlayer));
                float damage = Block.Attributes["areaDamage"].AsFloat(0.0f);
                if (entity is EntityPlayer entityPlayer)
                {
                    var itemEqupped = entityPlayer.Player.InventoryManager.GetOwnInventory(GlobalConstants.characterInvClassName);
                    var helmetSlot = itemEqupped[8];
                    if (helmetSlot.Empty || !helmetSlot.Itemstack.Collectible.Code.Path.Contains("gasmask"))//
                    {
                        entity.ReceiveDamage(new DamageSource()
                        {
                            Source = EnumDamageSource.Block,
                            SourceBlock = Block,
                            Type = EnumDamageType.Injury
                        }, damage); // 0.5 HP = 1/4 of a heart                             
                    }
                }
                else
                {
                    entity.ReceiveDamage(new DamageSource()
                    {
                        Source = EnumDamageSource.Block,
                        SourceBlock = Block,
                        Type = EnumDamageType.Injury
                    }, damage); // 0.5 HP = 1/4 of a heart            
                }
            }

            ticksLeft--;

            if (ticksLeft <= 0)
            {
                Block nextBlock = Api.World.GetBlock(decayBlockCode);
                //makes the next block air if it's not a block
                if (nextBlock == null) nextBlock = Api.World.GetBlock(new AssetLocation("game:air"));
                bool updateNeighbours = Block.Attributes["updateNeighbours"].AsBool(true);

                float randomHurdle = Block.Attributes["probabilityHurdle"].AsFloat(1.0f);
                if (Api.World.Rand.NextDouble() > randomHurdle)
                {
                    // PULL THE LEVER, KRONK
                    Api.World.BlockAccessor.SetBlock(nextBlock.BlockId, Pos);
                    Api.World.BlockAccessor.MarkBlockDirty(Pos);
                    if (updateNeighbours == true)
                    {
                        Api.World.BlockAccessor.TriggerNeighbourBlockUpdate(Pos);
                    }
                }
                else
                {
                    ticksLeft = Block.Attributes["lifespanTicks"].AsInt(100);
                }
            }
        }

        public override void OnBlockRemoved()
        {
            base.OnBlockRemoved();
            UnregisterGameTickListener(tickListenerId);
        }

        //Apparently this bit helps keep the time when you leand and join the world???
        public override void ToTreeAttributes(ITreeAttribute tree)
        {
            base.ToTreeAttributes(tree);
            tree.SetInt("ticksLeft", ticksLeft);
        }
        public override void FromTreeAttributes(ITreeAttribute tree, IWorldAccessor world)
        {
            base.FromTreeAttributes(tree, world);
            ticksLeft = tree.GetInt("ticksLeft");
        }
    }
}