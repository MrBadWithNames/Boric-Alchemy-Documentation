﻿using Vintagestory.API.Common;
using Vintagestory.API.Config;
using Vintagestory.API.Datastructures;

namespace BoricAlchemy.blocks
{
    public class BECustomDecayBi : BlockEntity
    {
        //storing the default tick in case i fuck up
        int ticksLeft = 100;
        AssetLocation decayBlockCode; // To store our result block

        public override void Initialize(ICoreAPI api)
        {
            base.Initialize(api);

            if (Block.Attributes != null) //making sure there are attributes 
            {
                // Get the lifespan, 100 if missing
                ticksLeft = Block.Attributes["lifespanTicks"].AsInt(100);
            }

            if (api.Side == EnumAppSide.Server)
            {
                RegisterGameTickListener(OnTick, 50); //but whhhhyyyy 50? Is it a time interval or are we just doing 50 time?!
            }
        }

        private void OnTick(float dt)
        {
            ticksLeft--;

            if (ticksLeft <= 0)
            {
                float randomBias = Block.Attributes["outcomeBias"].AsFloat(0.5f);

                if (Api.World.Rand.NextDouble() > randomBias)
                {
                    string code = Block.Attributes["decayBlockA"].AsString("game:air");
                    decayBlockCode = new AssetLocation(code);
                }
                else
                {
                    string code = Block.Attributes["decayBlockB"].AsString("game:air");
                    decayBlockCode = new AssetLocation(code);
                }

                Block nextBlock = Api.World.GetBlock(decayBlockCode);

                //makes the next block air if it's not a block
                if (nextBlock == null) nextBlock = Api.World.GetBlock(new AssetLocation("game:air"));
                bool updateNeighbours = Block.Attributes["updateNeighbours"].AsBool(true);

                float randomHurdle = Block.Attributes["probabilityHurdle"].AsFloat(1.0f);
                if (Api.World.Rand.NextDouble() > randomHurdle)
                {
                    // PULL THE LEVER, KRONK
                    Api.World.BlockAccessor.SetBlock(nextBlock.BlockId, Pos);
                    Api.World.BlockAccessor.MarkBlockDirty(Pos);
                    if (updateNeighbours == true)
                    {
                        Api.World.BlockAccessor.TriggerNeighbourBlockUpdate(Pos);
                    }
                }
                else
                {
                    ticksLeft = Block.Attributes["lifespanTicks"].AsInt(100);
                }
            }
        }

        //Apparently this bit helps keep the time when you leand and join the world???
        public override void ToTreeAttributes(ITreeAttribute tree)
        {
            base.ToTreeAttributes(tree);
            tree.SetInt("ticksLeft", ticksLeft);
        }
        public override void FromTreeAttributes(ITreeAttribute tree, IWorldAccessor world)
        {
            base.FromTreeAttributes(tree, world);
            ticksLeft = tree.GetInt("ticksLeft");
        }
    }
}