﻿using ModTemplate;
using System;
using Vintagestory.API.Client;
using Vintagestory.API.Common;
using Vintagestory.API.Common.Entities;
using Vintagestory.API.MathTools;
using Vintagestory.API.Server;
using Vintagestory.GameContent;

namespace boricalchemy
{
    public class ItemChemGun : Item
    {
        public static SimpleParticleProperties FlameParticlesA;
        public static SimpleParticleProperties FlameParticlesB;

        static ItemChemGun()
        {
            // idk - don't get zapped
        }

        public override void OnHeldUseStart(
            ItemSlot slot,
            EntityAgent byEntity,
            BlockSelection blockSel,
            EntitySelection entitySel,
            EnumHandInteract useType,
            bool firstEvent,
            ref EnumHandHandling handling)
        {
            if (useType != EnumHandInteract.HeldItemInteract)
            {
                handling = EnumHandHandling.NotHandled;
                return;
            }

            if (!firstEvent)
            {
                handling = EnumHandHandling.NotHandled;
                return;
            }

            IWorldAccessor world = byEntity.World;

            AssetLocation fireSound =
                new AssetLocation(
                    "boricalchemy",
                    "sounds/gunshot"
                );

            world.PlaySoundAt(
                fireSound,
                byEntity,
                null,
                true,
                16,
                1f + (float)world.Rand.NextDouble() * 0.1f
            );


            float range = GetFreeDistance(
                byEntity,
                15.0f
            );


            if (world.Side == EnumAppSide.Client)
            {
                SpawnFlameParticles(
                    byEntity,
                    range
                );
            }


            if (world.Side == EnumAppSide.Server)
            {
                slot.Itemstack.Item.DamageItem(
                    world,
                    byEntity,
                    slot,
                    1,
                    false
                );

                ProcessFlameDamage(
                    byEntity,
                    range
                );


                byEntity.ReceiveDamage(
                    new DamageSource()
                    {
                        Source = EnumDamageSource.Block,
                        Type = EnumDamageType.Injury
                    },
                    0.1f
                );


                int itemDurability =
                    slot.Itemstack.Item.GetRemainingDurability(
                        slot.Itemstack
                    );

                if (itemDurability <= 0)
                {
                    AssetLocation replacementCode =
                        new AssetLocation(
                            "boricalchemy:emptygun"
                        );

                    Item replacementItem =
                        world.GetItem(
                            replacementCode
                        );

                    if (replacementItem != null)
                    {
                        ItemStack replacementStack =
                            new ItemStack(
                                replacementItem,
                                1
                            );

                        slot.Itemstack =
                            replacementStack;
                    }
                    else
                    {
                        slot.Itemstack = null;
                    }

                    slot.MarkDirty();
                }
            }

            handling =
                EnumHandHandling.PreventDefault;
        }



        private void ProcessFlameDamage(
            EntityAgent byEntity,
            float range)
        {
            IWorldAccessor world =
                byEntity.World;

            Vec3d eyePos =
                byEntity.Pos.XYZ.Add(
                    0,
                    byEntity.LocalEyePos.Y,
                    0
                );

            Vec3d lookDir =
                new Vec3d(0, 0, 0)
                    .Ahead(
                        1.0f,
                        byEntity.Pos.Pitch,
                        byEntity.Pos.Yaw
                    )
                    .Normalize();

  
            double hitRadius = 0.75;

            Entity[] targets =
                world.GetEntitiesAround(
                    eyePos,
                    range,
                    range,
                    (e) =>
                        e.EntityId != byEntity.EntityId &&
                        e.Alive
                );

            foreach (Entity targetEntity in targets)
            {
                Cuboidf box =
                    targetEntity.CollisionBox;

                if (box == null)
                {
                    continue;
                }

                double minX =
                    targetEntity.Pos.X + box.X1;

                double maxX =
                    targetEntity.Pos.X + box.X2;

                double minY =
                    targetEntity.Pos.Y + box.Y1;

                double maxY =
                    targetEntity.Pos.Y + box.Y2;

                double minZ =
                    targetEntity.Pos.Z + box.Z1;

                double maxZ =
                    targetEntity.Pos.Z + box.Z2;


                minX -= hitRadius;
                minY -= hitRadius;
                minZ -= hitRadius;

                maxX += hitRadius;
                maxY += hitRadius;
                maxZ += hitRadius;

                if (!RayIntersectsAABB(
                    eyePos,
                    lookDir,
                    range,
                    minX,
                    minY,
                    minZ,
                    maxX,
                    maxY,
                    maxZ))
                {
                    continue;
                }


                targetEntity.ReceiveDamage(
                    new DamageSource()
                    {
                        Source =
                            EnumDamageSource.Entity,

                        SourceEntity =
                            byEntity,

                        Type =
                            EnumDamageType.PiercingAttack
                    },
                    20.0f
                );


                Vec3d targetDir =
                    (
                        targetEntity.Pos.XYZ -
                        eyePos
                    ).Normalize();

                targetEntity.Pos.Motion.Add(
                    targetDir.X * 0.25,
                    targetDir.Y * 0.25 + 0.1,
                    targetDir.Z * 0.25
                );

                targetEntity.Pos.Motion.Set(
                    targetEntity.Pos.Motion
                );
            }
        }



        private bool RayIntersectsAABB(
            Vec3d origin,
            Vec3d direction,
            double maxDistance,
            double minX,
            double minY,
            double minZ,
            double maxX,
            double maxY,
            double maxZ)
        {
            double tMin = 0.0;
            double tMax = maxDistance;


            if (Math.Abs(direction.X) < 0.000001)
            {
                if (
                    origin.X < minX ||
                    origin.X > maxX
                )
                {
                    return false;
                }
            }
            else
            {
                double tx1 =
                    (minX - origin.X) /
                    direction.X;

                double tx2 =
                    (maxX - origin.X) /
                    direction.X;

                if (tx1 > tx2)
                {
                    double temp = tx1;
                    tx1 = tx2;
                    tx2 = temp;
                }

                tMin =
                    Math.Max(
                        tMin,
                        tx1
                    );

                tMax =
                    Math.Min(
                        tMax,
                        tx2
                    );

                if (tMin > tMax)
                {
                    return false;
                }
            }

            if (Math.Abs(direction.Y) < 0.000001)
            {
                if (
                    origin.Y < minY ||
                    origin.Y > maxY
                )
                {
                    return false;
                }
            }
            else
            {
                double ty1 =
                    (minY - origin.Y) /
                    direction.Y;

                double ty2 =
                    (maxY - origin.Y) /
                    direction.Y;

                if (ty1 > ty2)
                {
                    double temp = ty1;
                    ty1 = ty2;
                    ty2 = temp;
                }

                tMin =
                    Math.Max(
                        tMin,
                        ty1
                    );

                tMax =
                    Math.Min(
                        tMax,
                        ty2
                    );

                if (tMin > tMax)
                {
                    return false;
                }
            }


            if (Math.Abs(direction.Z) < 0.000001)
            {
                if (
                    origin.Z < minZ ||
                    origin.Z > maxZ
                )
                {
                    return false;
                }
            }
            else
            {
                double tz1 =
                    (minZ - origin.Z) /
                    direction.Z;

                double tz2 =
                    (maxZ - origin.Z) /
                    direction.Z;

                if (tz1 > tz2)
                {
                    double temp = tz1;
                    tz1 = tz2;
                    tz2 = temp;
                }

                tMin =
                    Math.Max(
                        tMin,
                        tz1
                    );

                tMax =
                    Math.Min(
                        tMax,
                        tz2
                    );

                if (tMin > tMax)
                {
                    return false;
                }
            }

            return true;
        }


private float GetFreeDistance(EntityAgent byEntity, float maxRange)
        {
            IWorldAccessor world = byEntity.World;

            Vec3d eyePos = byEntity.Pos.XYZ.Add(
                0,
                byEntity.LocalEyePos.Y,
                0
            );

            Vec3d dir = new Vec3d()
                .Ahead(
                    1,
                    byEntity.Pos.Pitch,
                    byEntity.Pos.Yaw
                )
                .Normalize();


            IWorldIntersectionSupplier intersectionSupplier =
                world as IWorldIntersectionSupplier;

            const float step = 0.05f;

            for (
                float d = step;
                d <= maxRange;
                d += step)
            {
                Vec3d pos = eyePos + dir * d;

                BlockPos blockPos = pos.AsBlockPos;

                Block block =
                    world.BlockAccessor.GetBlock(blockPos);

                if (block == null)
                {
                    continue;
                }

                Cuboidf[] collisionBoxes = null;


                if (intersectionSupplier != null)
                {
                    collisionBoxes =
                        intersectionSupplier.GetBlockIntersectionBoxes(
                            blockPos
                        );
                }


                if (
                    collisionBoxes == null ||
                    collisionBoxes.Length == 0)
                {
                    collisionBoxes =
                        block.CollisionBoxes;
                }

                if (
                    collisionBoxes == null ||
                    collisionBoxes.Length == 0)
                {
                    continue;
                }

                bool hitBlock = false;

                foreach (Cuboidf box in collisionBoxes)
                {
                    if (box == null)
                    {
                        continue;
                    }


                    double minX =
                        blockPos.X + box.X1;

                    double maxX =
                        blockPos.X + box.X2;

                    double minY =
                        blockPos.Y + box.Y1;

                    double maxY =
                        blockPos.Y + box.Y2;

                    double minZ =
                        blockPos.Z + box.Z1;

                    double maxZ =
                        blockPos.Z + box.Z2;


                    if (RayIntersectsAABB(
                        eyePos,
                        dir,
                        maxRange,
                        minX,
                        minY,
                        minZ,
                        maxX,
                        maxY,
                        maxZ))
                    {
                        hitBlock = true;
                        break;
                    }
                }

                if (!hitBlock)
                {

                    continue;
                }

                if (world.Side == EnumAppSide.Client)
                {
                    world.SpawnCubeParticles(
                        blockPos,
                        pos,
                        1,
                        20
                    );
                }


                if (world.Side == EnumAppSide.Server)
                {
                    bool damageBlocks =
                        ModTemplateModSystem
                            .Config
                            .GunCrackRock;

                    if (damageBlocks)
                    {
                        TransformBlock(
                            world,
                            block,
                            blockPos,
                            "rock-granite",
                            "crackedrock-granite"
                        );

                        TransformBlock(
                            world,
                            block,
                            blockPos,
                            "rock-andesite",
                            "crackedrock-andesite"
                        );

                        TransformBlock(
                            world,
                            block,
                            blockPos,
                            "rock-shale",
                            "crackedrock-shale"
                        );

                        TransformBlock(
                            world,
                            block,
                            blockPos,
                            "rock-chalk",
                            "crackedrock-chalk"
                        );

                        TransformBlock(
                            world,
                            block,
                            blockPos,
                            "rock-chert",
                            "crackedrock-chert"
                        );

                        TransformBlock(
                            world,
                            block,
                            blockPos,
                            "rock-conglomerate",
                            "crackedrock-conglomerate"
                        );

                        TransformBlock(
                            world,
                            block,
                            blockPos,
                            "rock-limestone",
                            "crackedrock-limestone"
                        );

                        TransformBlock(
                            world,
                            block,
                            blockPos,
                            "rock-claystone",
                            "crackedrock-claystone"
                        );

                        TransformBlock(
                            world,
                            block,
                            blockPos,
                            "rock-sandstone",
                            "crackedrock-sandstone"
                        );

                        TransformBlock(
                            world,
                            block,
                            blockPos,
                            "rock-basalt",
                            "crackedrock-basalt"
                        );

                        TransformBlock(
                            world,
                            block,
                            blockPos,
                            "rock-peridotite",
                            "crackedrock-peridotite"
                        );

                        TransformBlock(
                            world,
                            block,
                            blockPos,
                            "rock-phyllite",
                            "crackedrock-phyllite"
                        );

                        TransformBlock(
                            world,
                            block,
                            blockPos,
                            "rock-slate",
                            "crackedrock-slate"
                        );

                        TransformBlock(
                            world,
                            block,
                            blockPos,
                            "rock-kimberlite",
                            "crackedrock-kimberlite"
                        );

                        TransformBlock(
                            world,
                            block,
                            blockPos,
                            "rock-bauxite",
                            "crackedrock-bauxite"
                        );

                        TransformBlock(
                            world,
                            block,
                            blockPos,
                            "rock-halite",
                            "crackedrock-halite"
                        );

                        TransformBlock(
                            world,
                            block,
                            blockPos,
                            "rock-suevite",
                            "crackedrock-suevite"
                        );

                        TransformBlock(
                            world,
                            block,
                            blockPos,
                            "rock-obsidian",
                            "crackedrock-obsidian"
                        );

                        TransformBlock(
                            world,
                            block,
                            blockPos,
                            "rock-tuff",
                            "crackedrock-tuff"
                        );

                        TransformBlock(
                            world,
                            block,
                            blockPos,
                            "rock-scoria",
                            "crackedrock-scoria"
                        );

                        TransformBlock(
                            world,
                            block,
                            blockPos,
                            "rock-travertine",
                            "crackedrock-travertine"
                        );

                        TransformBlock(
                            world,
                            block,
                            blockPos,
                            "rock-redmarble",
                            "crackedrock-redmarble"
                        );

                        TransformBlock(
                            world,
                            block,
                            blockPos,
                            "rock-greenmarble",
                            "crackedrock-greenmarble"
                        );

                        TransformBlock(
                            world,
                            block,
                            blockPos,
                            "rock-whitemarble",
                            "crackedrock-whitemarble"
                        );

                        ShootBomb(
                            world,
                            block,
                            blockPos,
                            "bomb-ore",
                            EnumBlastType.OreBlast,
                            4.0f
                        );

                        ShootBomb(
                            world,
                            block,
                            blockPos,
                            "bomb-scrap",
                            EnumBlastType.EntityBlast,
                            4.0f
                        );

                        ShootBomb(
                            world,
                            block,
                            blockPos,
                            "bomb-stone",
                            EnumBlastType.RockBlast,
                            4.0f
                        );

                        ShootBomb(
                            world,
                            block,
                            blockPos,
                            "piricbomb-ore",
                            EnumBlastType.OreBlast,
                            5.0f
                        );

                        ShootBomb(
                            world,
                            block,
                            blockPos,
                            "piricbomb-scrap",
                            EnumBlastType.EntityBlast,
                            5.0f
                        );

                        ShootBomb(
                            world,
                            block,
                            blockPos,
                            "piricbomb-stone",
                            EnumBlastType.RockBlast,
                            5.0f
                        );

                        ShootBomb(
                            world,
                            block,
                            blockPos,
                            "mine",
                            EnumBlastType.EntityBlast,
                            4.0f
                        );

                        bool damage2Blocks =
                            ModTemplateModSystem
                                .Config
                                .DamageBlocks;

                        EnumBlastType expType =
                            EnumBlastType.RockBlast;

                        if (!damage2Blocks)
                        {
                            expType =
                                EnumBlastType.EntityBlast;
                        }

                        ShootBomb(
                            world,
                            block,
                            blockPos,
                            "tatpmine",
                            expType,
                            4.0f
                        );
                    }
                }

                return d;
            }

            return maxRange;
        }

        // ============================================================
        // BLOCK TRANSFORMATION
        // ============================================================

        private void TransformBlock(
            IWorldAccessor world,
            Block block,
            BlockPos pos,
            string fromCode,
            string toCode)
        {
            if (block.Code.Path.Contains(fromCode))
            {
                Block replacement =
                    world.GetBlock(
                        new AssetLocation(
                            "game:" + toCode
                        )
                    );

                if (replacement != null)
                {
                    world.BlockAccessor.SetBlock(
                        replacement.Id,
                        pos
                    );
                }
            }
        }


        // ============================================================
        // BOMB / EXPLOSION BLOCKS
        // ============================================================

        private void ShootBomb(
            IWorldAccessor world,
            Block block,
            BlockPos pos,
            string fromCode,
            EnumBlastType boomType,
            float range)
        {
            if (!block.Code.Path.Contains(fromCode))
            {
                return;
            }

            ICoreServerAPI sapi =
                world.Api as ICoreServerAPI;

            if (sapi == null)
            {
                return;
            }

            sapi.World.CreateExplosion(
                pos,
                boomType,
                range,
                8.0
            );

            world.BlockAccessor.SetBlock(
                0,
                pos
            );
        }


        // ============================================================
        // FLAME PARTICLES
        // ============================================================

        private void SpawnFlameParticles(
            EntityAgent byEntity,
            float range)
        {
            IWorldAccessor world =
                byEntity.World;

            Vec3d startPos =
                byEntity.Pos.XYZ.Add(
                    0,
                    byEntity.LocalEyePos.Y,
                    0
                );

            Vec3d direction =
                new Vec3d()
                    .Ahead(
                        1,
                        byEntity.Pos.Pitch,
                        byEntity.Pos.Yaw
                    )
                    .Normalize();

            for (
                float distance = 0;
                distance <= range;
                distance += 0.25f)
            {
                /*
                 * Random spread increases with distance.
                 */
                float spreadAmount =
                    distance * 0.05f;

                double randomX =
                    (
                        world.Rand.NextDouble()
                        - 0.5
                    ) * spreadAmount;

                double randomY =
                    (
                        world.Rand.NextDouble()
                        - 0.5
                    ) * spreadAmount;

                double randomZ =
                    (
                        world.Rand.NextDouble()
                        - 0.5
                    ) * spreadAmount;

                Vec3d particlePos =
                    startPos
                    + direction * distance
                    + new Vec3d(
                        randomX,
                        randomY,
                        randomZ
                    );

                float minVelocity = 1.5f;
                float maxVelocity = 2.5f;

                SimpleParticleProperties particles =
                    new SimpleParticleProperties(
                        2,
                        3,

                        ColorUtil.ToRgba(
                            200,
                            64,
                            4,
                            100
                        ),

                        particlePos,
                        particlePos,

                        /*
                         * Minimum velocity.
                         */
                        new Vec3f(
                            (float)direction.X
                                * minVelocity,

                            (float)direction.Y
                                * minVelocity,

                            (float)direction.Z
                                * minVelocity
                        ),

                        /*
                         * Maximum velocity.
                         */
                        new Vec3f(
                            (float)direction.X
                                * maxVelocity,

                            (float)direction.Y
                                * maxVelocity,

                            (float)direction.Z
                                * maxVelocity
                        ),

                        1.0f,
                        0,
                        0.1f,
                        0.1f
                    );

                particles.GravityEffect =
                    1.0f
                    + (float)
                        world.Rand.NextDouble();

                particles.MinPos =
                    particlePos;

                particles.AddPos =
                    new Vec3d(
                        0.25,
                        0.25,
                        0.25
                    );

                particles.LifeLength =
                    1.25f
                    + (float)
                        world.Rand.NextDouble();

                particles.MinSize =
                    0.15f;

                particles.MaxSize =
                    2.5f;

                particles.WindAffectednes =
                    0.05f;

                particles.SizeEvolve =
                    new EvolvingNatFloat(
                        EnumTransformFunction.LINEAR,
                        2.5f
                    );

                particles.OpacityEvolve =
                    new EvolvingNatFloat(
                        EnumTransformFunction.LINEAR,
                        -15.5f
                    );

                particles.RedEvolve =
                    new EvolvingNatFloat(
                        EnumTransformFunction.LINEAR,
                        25f
                    );

                particles.GreenEvolve =
                    new EvolvingNatFloat(
                        EnumTransformFunction.LINEAR,
                        95f
                    );

                particles.BlueEvolve =
                    new EvolvingNatFloat(
                        EnumTransformFunction.LINEAR,
                        125f
                    );

                world.SpawnParticles(
                    particles
                );
            }
        }
    }
}
