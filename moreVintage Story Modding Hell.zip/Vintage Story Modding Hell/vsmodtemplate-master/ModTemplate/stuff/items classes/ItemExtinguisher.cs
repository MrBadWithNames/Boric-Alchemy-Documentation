﻿using System;
using Vintagestory.API.Client;
using Vintagestory.API.Common;
using Vintagestory.API.Common.Entities;
using Vintagestory.API.Config;
using Vintagestory.API.Datastructures;
using Vintagestory.API.MathTools;

namespace BoricAlchemy.blocks
{
    public class ItemExtinguisher : Item
    {
        public static SimpleParticleProperties FogParticlesA;
        public static SimpleParticleProperties FogParticlesB;

        // ============================================================
        // EXTINGUISHER SETTINGS
        // ============================================================

        private const float ExtinguishRange = 5.0f;

        // ============================================================
        // PARTICLES (CO2 WHITE FOG WITH FADE OUT)
        // ============================================================

        static ItemExtinguisher()
        {
            // ========================================================
            // FOG PARTICLE A (Dense Core)
            // ========================================================

            FogParticlesA = new SimpleParticleProperties(
                2,
                4,
                ColorUtil.ColorFromRgba(240, 240, 250, 180),
                new Vec3d(),
                new Vec3d(),
                new Vec3f(-0.2f, 0.1f, -0.2f),
                new Vec3f(0.2f, 0.4f, 0.2f),
                0.3f,
                -0.05f,
                0.4f,
                0.4f,
                EnumParticleModel.Quad
            );

            FogParticlesA.LightEmission = 0;
            FogParticlesA.VertexFlags = 0;

            // ========================================================
            // FOG PARTICLE B (Outer Plume)
            // ========================================================

            FogParticlesB = new SimpleParticleProperties(
                2,
                3,
                ColorUtil.ColorFromRgba(200, 205, 215, 120),
                new Vec3d(),
                new Vec3d(),
                new Vec3f(-0.3f, 0.2f, -0.3f),
                new Vec3f(0.3f, 0.6f, 0.3f),
                0.3f,
                -0.02f,
                0.5f,
                0.5f,
                EnumParticleModel.Quad
            );

            FogParticlesB.LightEmission = 0;
            FogParticlesB.VertexFlags = 0;

            // ========================================================
            // SIZE EVOLUTION (Expanding Gas Effect)
            // ========================================================

            FogParticlesA.SizeEvolve = new EvolvingNatFloat(
                EnumTransformFunction.LINEAR,
                3f
            );

            FogParticlesB.SizeEvolve = new EvolvingNatFloat(
                EnumTransformFunction.LINEAR,
                3f
            );

            // ========================================================
            // OPACITY EVOLUTION (Smooth Fade Out)
            // ========================================================

            // Negative change value subtracts opacity over lifetime until fully transparent (0)
            FogParticlesA.OpacityEvolve = new EvolvingNatFloat(
                EnumTransformFunction.LINEAR,
                -220f
            );

            FogParticlesB.OpacityEvolve = new EvolvingNatFloat(
                EnumTransformFunction.LINEAR,
                -220f
            );
        }

        // ============================================================
        // START USING EXTINGUISHER
        // ============================================================

        public override void OnHeldInteractStart(
            ItemSlot slot,
            EntityAgent byEntity,
            BlockSelection blockSel,
            EntitySelection entitySel,
            bool firstEvent,
            ref EnumHandHandling handling)
        {
            handling = EnumHandHandling.PreventDefault;
        }

        // ============================================================
        // EXTINGUISHER ACTIVE
        // ============================================================

        public override bool OnHeldInteractStep(
            float secondsUsed,
            ItemSlot slot,
            EntityAgent byEntity,
            BlockSelection blockSel,
            EntitySelection entitySel)
        {
            IWorldAccessor world = byEntity.World;

            // Stop when right mouse is released
            if (byEntity is EntityPlayer player && !player.Controls.RightMouseDown)
            {
                return false;
            }


            // CO2 Hiss Sound
            AssetLocation extSound = new AssetLocation("boricalchemy", "sounds/extinguisher");
            world.PlaySoundAt(
                extSound,
                byEntity,
                null,
                true,
                16,
                1f + (float)world.Rand.NextDouble() * 0.1f
            );

            // Client Particles
            if (world.Side == EnumAppSide.Client)
            {
                SpawnFogEffects(byEntity);
            }

            // Server Logic
            if (world.Side == EnumAppSide.Server)
            {
                // Damage item durability
                if (slot.Itemstack != null)
                {
                    slot.Itemstack.Item.DamageItem(world, byEntity, slot, 1, false);
                }

                // Extinguish entities and block fires (0 damage)
                ProcessExtinguisherLogic(byEntity, ExtinguishRange);

                // Check Durability
                if (slot.Itemstack != null)
                {
                    int itemDurability = slot.Itemstack.Item.GetRemainingDurability(slot.Itemstack);

                    if (itemDurability <= 0)
                    {
                        ReplaceWithEmptyExtinguisher(world, slot);
                        return false;
                    }
                }
            }

            return true;
        }

        // ============================================================
        // REPLACE EMPTY EXTINGUISHER
        // ============================================================

        private void ReplaceWithEmptyExtinguisher(IWorldAccessor world, ItemSlot slot)
        {
            AssetLocation replacementCode = new AssetLocation("boricalchemy:extinguisherempty");
            Item replacementItem = world.GetItem(replacementCode);

            if (replacementItem != null)
            {
                slot.Itemstack = new ItemStack(replacementItem, 1);
            }
            else
            {
                slot.Itemstack = null;
            }

            slot.MarkDirty();
        }

        // ============================================================
        // CLONE PARTICLE PROPERTIES
        // ============================================================

        private SimpleParticleProperties CloneParticles(SimpleParticleProperties source)
        {
            return new SimpleParticleProperties()
            {
                MinQuantity = source.MinQuantity,
                AddQuantity = source.AddQuantity,
                Color = source.Color,
                LightEmission = source.LightEmission,
                VertexFlags = source.VertexFlags,
                MinPos = source.MinPos.Clone(),
                AddPos = source.AddPos.Clone(),
                MinVelocity = source.MinVelocity.Clone(),
                AddVelocity = source.AddVelocity.Clone(),
                LifeLength = source.LifeLength,
                GravityEffect = source.GravityEffect,
                MinSize = source.MinSize,
                MaxSize = source.MaxSize,
                ParticleModel = source.ParticleModel,
                SizeEvolve = source.SizeEvolve,
                OpacityEvolve = source.OpacityEvolve // Preserved fade out evolution
            };
        }

        // ============================================================
        // SPAWN FOG PARTICLES
        // ============================================================

        private void SpawnFogEffects(EntityAgent byEntity)
        {
            IWorldAccessor world = byEntity.World;
            ICoreClientAPI capi = world.Api as ICoreClientAPI;

            Vec3d handPos = byEntity.Pos.XYZ.AddCopy(
                0,
                byEntity.LocalEyePos.Y,
                0
            );

            double forwardOffset = 0.8;
            double rightOffset = 0.35;
            double downOffset = -0.35;

            if (capi != null && capi.World.Player.CameraMode == EnumCameraMode.FirstPerson)
            {
                forwardOffset = 0.8;
                rightOffset = 0.15;
                downOffset = -0.25;
            }

            Vec3d forwardVec = new Vec3d(0, 0, 0).Ahead(
                forwardOffset,
                byEntity.Pos.Pitch,
                byEntity.Pos.Yaw
            );

            Vec3d rightVec = new Vec3d(0, 0, 0).Ahead(
                rightOffset,
                0,
                byEntity.Pos.Yaw + GameMath.PIHALF
            );

            Vec3d downVec = new Vec3d(0, downOffset, 0);

            Vec3d finalSpawnPos = handPos.Add(forwardVec).Add(rightVec).Add(downVec);

            Vec3f pushVelocity = new Vec3d(0, 0, 0)
                .Ahead(9.0f, byEntity.Pos.Pitch, byEntity.Pos.Yaw)
                .ToVec3f();

            // Spawn Fog A
            SimpleParticleProperties spawnParticlesA = CloneParticles(FogParticlesA);
            spawnParticlesA.MinPos = finalSpawnPos.AddCopy(-0.15, -0.15, -0.15);
            spawnParticlesA.MinVelocity = pushVelocity;
            world.SpawnParticles(spawnParticlesA);

            // Spawn Fog B
            SimpleParticleProperties spawnParticlesB = CloneParticles(FogParticlesB);
            spawnParticlesB.MinPos = finalSpawnPos.AddCopy(-0.15, -0.15, -0.15);
            spawnParticlesB.MinVelocity = pushVelocity;
            world.SpawnParticles(spawnParticlesB);
        }

        // ============================================================
        // LINE OF SIGHT
        // ============================================================

        private bool HasLineOfSight(IWorldAccessor world, Vec3d start, Vec3d end)
        {
            Vec3d dir = end - start;
            double distance = dir.Length();
            dir.Normalize();

            BlockPos pos = new BlockPos();

            for (double d = 0; d < distance; d += 0.1)
            {
                Vec3d checkPos = start + dir * d;
                pos.Set(
                    (int)Math.Floor(checkPos.X),
                    (int)Math.Floor(checkPos.Y),
                    (int)Math.Floor(checkPos.Z)
                );

                Block block = world.BlockAccessor.GetBlock(pos);
                if (block.BlockMaterial != EnumBlockMaterial.Air)
                {
                    return false;
                }
            }

            return true;
        }

        // ============================================================
        // PROCESS EXTINGUISHER LOGIC (ENTITIES & BLOCK FIRES)
        // ============================================================

        private void ProcessExtinguisherLogic(EntityAgent byEntity, float range)
        {
            IWorldAccessor world = byEntity.World;

            Vec3d eyePos = byEntity.Pos.XYZ.Add(
                0,
                byEntity.LocalEyePos.Y,
                0
            );

            Vec3d lookDir = new Vec3d(0, 0, 0)
                .Ahead(1.0f, byEntity.Pos.Pitch, byEntity.Pos.Yaw)
                .Normalize();

            // 1. Extinguish Nearby Entities
            Entity[] targets = world.GetEntitiesAround(
                eyePos,
                range,
                range,
                (e) => e.EntityId != byEntity.EntityId && e.Alive
            );

            foreach (Entity targetEntity in targets)
            {
                Vec3d targetPos = targetEntity.Pos.XYZ.Add(
                    0,
                    targetEntity.LocalEyePos.Y,
                    0
                );

                Vec3d targetDir = (targetPos - eyePos).Normalize();
                double dotProduct = lookDir.Dot(targetDir);

                if (dotProduct > 0.82)
                {
                    if (!HasLineOfSight(world, eyePos, targetPos))
                    {
                        continue;
                    }

                    if (targetEntity.WatchedAttributes.HasAttribute("onFire"))
                    {
                        targetEntity.WatchedAttributes.RemoveAttribute("onFire");
                    }

                    ITreeAttribute bodyTempAttr = targetEntity.WatchedAttributes.GetTreeAttribute("bodyTemperature");
                    if (bodyTempAttr != null)
                    {
                        // Lower their internal temperature value (adjust float key/value depending on exact setup)
                        float currentTemp = bodyTempAttr.GetFloat("temperature");
                        bodyTempAttr.SetFloat("temperature", Math.Max(-10f, currentTemp - 5.0f));
                        targetEntity.WatchedAttributes.MarkPathDirty("bodyTemperature");
                    }
                }
            }

            // 2. Extinguish Fire Blocks in a Cone / Ray
            BlockPos currentPos = new BlockPos();
            for (double d = 0.5; d < range; d += 0.5)
            {
                Vec3d checkVec = eyePos + (lookDir * d);
                currentPos.Set(
                    (int)Math.Floor(checkVec.X),
                    (int)Math.Floor(checkVec.Y),
                    (int)Math.Floor(checkVec.Z)
                );

                Block block = world.BlockAccessor.GetBlock(currentPos);
                if (block != null && block.Code != null && block.Code.Path.Contains("fire"))
                {
                    world.BlockAccessor.SetBlock(0, currentPos);
                    world.BlockAccessor.MarkBlockDirty(currentPos);
                }
            }
        }
    }
}