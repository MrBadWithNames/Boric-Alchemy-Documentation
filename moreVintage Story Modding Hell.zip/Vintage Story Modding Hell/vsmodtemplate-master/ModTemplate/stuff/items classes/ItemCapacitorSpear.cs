﻿using ModTemplate;
using System;
using Vintagestory.API.Client;
using Vintagestory.API.Common;
using Vintagestory.API.Common.Entities;
using Vintagestory.API.MathTools;
using Vintagestory.API.Server;
using Vintagestory.GameContent;

namespace boricalchemy
{
    public class ItemCapacitorSpear : Item
    {
        // Capacitor cooldown in milliseconds
        private const long KnockbackCooldown = 400;

        bool replace = false;
        // Last time the capacitor fired
        private long lastAttackTime = 0;

        public override void OnHeldAttackStart(
            ItemSlot slot,
            EntityAgent byEntity,
            BlockSelection blockSel,
            EntitySelection entitySel,
            ref EnumHandHandling handling)
        {

            IWorldAccessor world = byEntity.World;


            int itemDurability =
                slot.Itemstack.Item.GetRemainingDurability(
                    slot.Itemstack
                );

            if (itemDurability <= 1)
            {
                replace = true;
            }
            base.OnHeldAttackStart(
                slot,
                byEntity,
                blockSel,
                entitySel,
                ref handling
            );

            //rest

        }



        public override void OnAttackingWith(
            IWorldAccessor world,
            Entity byEntity,
            Entity attackedEntity,
            ItemSlot itemslot)
        {
            base.OnAttackingWith(
                world,
                byEntity,
                attackedEntity,
                itemslot
            );

            if (api is not ICoreServerAPI sapi)
                return;

            // Check cooldown
            long currentTime = world.ElapsedMilliseconds;

            if (currentTime - lastAttackTime < KnockbackCooldown)
                return;

            // Start capacitor cooldown
            lastAttackTime = currentTime;

            if (byEntity is not EntityAgent attacker)
                return;

            Entity target = attackedEntity;


            Vec3d direction = target.Pos.XYZ - attacker.Pos.XYZ;
            direction.Y = 0;

            if (direction.Length() > 0)
            {
                direction.Normalize();

                target.Pos.Motion.X += direction.X * 0.25;
                target.Pos.Motion.Z += direction.Z * 0.25;
                target.Pos.Motion.Y += 0.1;
            }


            // ========================================================
            // SPARKS
            // ========================================================

            SpawnSparks(target.Pos.XYZ);

            if (replace)
            {
                replace = true;
                AssetLocation replacementCode =
                    new AssetLocation(
                        "boricalchemy:capacitorspear_dry"
                    );

                Item replacementItem =
                    world.GetItem(
                        replacementCode
                    );

                if (replacementItem != null)
                {
                    ItemStack replacementStack =
                        new ItemStack(
                            replacementItem,
                            1
                        );

                    itemslot.Itemstack =
                        replacementStack;
                }
                else
                {
                    itemslot.Itemstack = null;
                }
                replace = false;
                itemslot.MarkDirty();
            }
            // ========================================================
            // AOE DAMAGE + KNOCKBACK
            // ========================================================

            DealAOEDamage(target, attacker);


            // ========================================================
            // CAPACITOR SOUND
            // ========================================================

            AssetLocation fireSound =
                new AssetLocation(
                    "boricalchemy",
                    "sounds/buzz"
                );

            world.PlaySoundAt(
                fireSound,
                attacker,
                null,
                true,
                16,
                1f + (float)world.Rand.NextDouble() * 0.1f
            );


            

        }


        // ============================================================
        // AOE
        // ============================================================

        private void DealAOEDamage(
            Entity target,
            EntityAgent attacker)
        {
            if (api is not ICoreServerAPI sapi)
                return;

            float radius = 2.5f;

            Entity[] entities = sapi.World.GetEntitiesAround(
                target.Pos.XYZ,
                radius,
                radius
            );

            foreach (Entity entity in entities)
            {
                if (entity == attacker)
                    if (entity.FeetInLiquid == false)
                        continue;

                if (entity is not EntityAgent entityAgent)
                    continue;


                // ====================================================
                // ELECTRIC DAMAGE
                // ====================================================

                DamageSource damageSource = new DamageSource()
                {
                    Source = EnumDamageSource.Player,
                    SourceEntity = attacker,
                    CauseEntity = attacker,
                    Type = EnumDamageType.Electricity
                };

                entityAgent.ReceiveDamage(
                    damageSource,
                    8f
                );


                // ====================================================
                // AOE KNOCKBACK
                // ====================================================

                Vec3d direction =
                    entity.Pos.XYZ - attacker.Pos.XYZ;

                direction.Y = 0;

                if (direction.Length() > 0)
                {
                    direction.Normalize();

                    entity.Pos.Motion.X += direction.X * 0.2;
                    entity.Pos.Motion.Z += direction.Z * 0.2;
                    entity.Pos.Motion.Y += 0.08;
                }
            }
        }


        // ============================================================
        // SPARK PARTICLES
        // ============================================================

        private void SpawnSparks(Vec3d position)
        {
            if (api is ICoreServerAPI sapi)
            {
                // ========================================================
                // SPARKS
                // ========================================================

                SimpleParticleProperties sparks =
                    new SimpleParticleProperties(
                        12,
                        20,
                        ColorUtil.ToRgba(
                            255,
                            255,
                            255,
                            255
                        ),
                        position.AddCopy(
                            -0.1,
                            1.25,
                            -0.1
                        ),
                        position.AddCopy(
                            0.1,
                            0.5,
                            0.1
                        ),
                        new Vec3f(
                            -4f,
                            -4f,
                            -4f
                        ),
                        new Vec3f(
                            4f,
                            4f,
                            4f
                        ),
                        0.2f,
                        0.1f,
                        0.1f,
                        0.2f
                    );

                // Make sparks emit light
                sparks.LightEmission =
                    ColorUtil.ToRgba(
                        255,
                        255,
                        250,
                        255
                    );

                sapi.World.SpawnParticles(sparks);


                // ========================================================
                // SMOKE
                // ========================================================

                SimpleParticleProperties smoke =
                    new SimpleParticleProperties(
                        5,                  // Minimum quantity
                        8,                  // Maximum quantity
                        ColorUtil.ToRgba(
                            40,
                            40,
                            40,
                            160
                        ),
                        position.AddCopy(
                            -0.25,
                            0.8,
                            -0.25
                        ),
                        position.AddCopy(
                            0.25,
                            1.2,
                            0.25
                        ),
                        new Vec3f(
                            -0.35f,
                            0.1f,
                            -0.35f
                        ),
                        new Vec3f(
                            0.35f,
                            0.2f,
                            0.35f
                        ),
                        0.6f,       // life
                        -0.2f,      // gravity
                        1f,         // min size
                        2f          // max size
                    );

                sapi.World.SpawnParticles(smoke);
            }
        }
    }
}