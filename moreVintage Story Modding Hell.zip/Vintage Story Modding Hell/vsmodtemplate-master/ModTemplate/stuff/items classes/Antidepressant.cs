﻿using Vintagestory.API.Common;
using Vintagestory.API.Server;

namespace BoricAlchemy.blocks
{
    public class ItemStabilizingFood : Item
    {
        public override void OnHeldInteractStop(float secondsUsed, ItemSlot slot, EntityAgent byEntity, BlockSelection blockSel, EntitySelection entitySel)
        {
            int countBefore = slot.Itemstack?.StackSize ?? 0;

            base.OnHeldInteractStop(secondsUsed, slot, byEntity, blockSel, entitySel);

            if (byEntity.World.Side == EnumAppSide.Server && byEntity is EntityPlayer entityPlayer)
            {
                int countAfter = slot.Itemstack?.StackSize ?? 0;

                if (countAfter < countBefore || (countBefore > 0 && slot.Itemstack == null))
                {
                    IServerPlayer player = entityPlayer.Player as IServerPlayer;
                    if (player != null)
                    {
                        double currentStability = entityPlayer.WatchedAttributes.GetDouble("temporalStability", 1.0);

                        double sanityAmount = 0.0;
                        if (slot.Itemstack?.Attributes != null && slot.Itemstack.Attributes.HasAttribute("temporalStabilityGain"))
                        {
                            sanityAmount = slot.Itemstack.Attributes.GetDouble("temporalStabilityGain", 0.0);
                        }
                        else if (Attributes != null && Attributes["temporalStabilityGain"].Exists)
                        {
                            sanityAmount = Attributes["temporalStabilityGain"].AsDouble(0.0);
                        }

                        double newStability = System.Math.Min(1.5, currentStability + sanityAmount);

                        entityPlayer.WatchedAttributes.SetDouble("temporalStability", newStability);
                        entityPlayer.WatchedAttributes.MarkPathDirty("temporalStability");
                    }
                }
            }
        }
    }
}
