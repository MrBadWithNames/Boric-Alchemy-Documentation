﻿using ModTemplate;
using Vintagestory.API.Common;
using Vintagestory.API.Common.Entities;
using Vintagestory.API.Datastructures;
using Vintagestory.API.Server;

namespace BoricAlchemy.blocks
{
    public class SpeedItem : Item
    {
        private const string SpeedActiveKey = "boricAlchemy_speedActive";

        public override void OnHeldInteractStop(float secondsUsed, ItemSlot slot, EntityAgent byEntity, BlockSelection blockSel, EntitySelection entitySel)
        {
            int countBefore = slot.Itemstack?.StackSize ?? 0;

            base.OnHeldInteractStop(secondsUsed, slot, byEntity, blockSel, entitySel);

            if (byEntity.World.Side == EnumAppSide.Server && byEntity is EntityPlayer entityPlayer)
            {
                int countAfter = slot.Itemstack?.StackSize ?? 0;

                // Check if the item was actually consumed/decremented (finished eating/using)
                if (countAfter < countBefore || (countBefore > 0 && slot.Itemstack == null))
                {
                    bool speedActive = entityPlayer.WatchedAttributes.GetBool(
                        SpeedActiveKey,
                        false
                    );

                    if (speedActive)
                    {
                        return;
                    }

                    float speedMultiplier = ModTemplateModSystem.Config.speedBuffMultiplier;

                    entityPlayer.Stats.Set(
                        "walkspeed",
                        "mySpeedBoost",
                        speedMultiplier,
                        false
                    );

                    entityPlayer.WatchedAttributes.SetBool(
                        SpeedActiveKey,
                        true
                    );

                    IServerPlayer player = entityPlayer.Player as IServerPlayer;
                    if (player != null)
                    {
                        double currentStability = entityPlayer.WatchedAttributes.GetDouble("temporalStability", 1.0);

                        // Fixed the typo from your snippet ("currentStability0.10" -> adding 0.10 or pulling from attributes/config if preferred)
                        double newStability = System.Math.Max(0.0, currentStability - 0.10);

                        entityPlayer.WatchedAttributes.SetDouble("temporalStability", newStability);
                        entityPlayer.WatchedAttributes.MarkPathDirty("temporalStability");

                        ITreeAttribute tirednessTree = entityPlayer.WatchedAttributes.GetTreeAttribute("tiredness");

                        if (tirednessTree != null)
                        {
                            tirednessTree.SetFloat("tiredness", 0f);
                            entityPlayer.WatchedAttributes.MarkPathDirty("tiredness");
                        }
                    }

                    CheckAndExpire(entityPlayer);
                }
            }
        }

        private void CheckAndExpire(EntityPlayer entityPlayer)
        {
            entityPlayer.World.RegisterCallback((dt) =>
            {
                if (entityPlayer.Player == null)
                {
                    return;
                }

                entityPlayer.Stats.Remove(
                    "walkspeed",
                    "mySpeedBoost"
                );

                entityPlayer.WatchedAttributes.SetBool(
                    SpeedActiveKey,
                    false
                );

            }, (int)ModTemplateModSystem.Config.SpeedDuration);
        }
    }
}