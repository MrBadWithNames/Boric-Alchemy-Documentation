﻿using System;
using Vintagestory.API.Client;
using Vintagestory.API.Common;
using Vintagestory.API.Common.Entities;
using Vintagestory.API.Config;
using Vintagestory.API.Datastructures;
using Vintagestory.API.MathTools;

namespace BoricAlchemy.blocks
{
    public class ItemFlamethrower : Item
    {
        public static SimpleParticleProperties FlameParticlesA;
        public static SimpleParticleProperties FlameParticlesB;


        // ============================================================
        // FLAMETHROWER SETTINGS
        // ============================================================

        private const float DefaultDamage = 4.0f;
        private const float FlameRange = 5.0f;


        // ============================================================
        // PARTICLES
        // ============================================================

        static ItemFlamethrower()
        {
            // ========================================================
            // BLUE FLAME A
            // ========================================================

            FlameParticlesA = new SimpleParticleProperties(
                1,
                2,

                ColorUtil.ColorFromRgba(
                    2,
                    183,
                    255,
                    200
                ),

                new Vec3d(),
                new Vec3d(),

                new Vec3f(
                    -0.4f,
                    0.4f,
                    -0.4f
                ),

                new Vec3f(
                    0.4f,
                    1.2f,
                    0.4f
                ),

                0.4f,
                -0.1f,

                0.2f,
                0.2f,

                EnumParticleModel.Quad
            );

            // --------------------------------------------------------
            // EMISSION / GLOW
            // --------------------------------------------------------

            FlameParticlesA.LightEmission =
                ColorUtil.ColorFromRgba(
                    100,
                    220,
                    255,
                    255
                );

            // Glow level.
            // Lower 8 bits are the particle glow value.
            FlameParticlesA.VertexFlags =
                0xFF;


            // ========================================================
            // BLUE FLAME B
            // ========================================================

            FlameParticlesB = new SimpleParticleProperties(
                1,
                1,

                ColorUtil.ColorFromRgba(
                    0,
                    67,
                    255,
                    200
                ),

                new Vec3d(),
                new Vec3d(),

                new Vec3f(
                    -0.4f,
                    0.4f,
                    -0.4f
                ),

                new Vec3f(
                    0.4f,
                    1.2f,
                    0.4f
                ),

                0.3f,
                -0.1f,

                0.2f,
                0.2f,

                EnumParticleModel.Quad
            );

            // --------------------------------------------------------
            // EMISSION / GLOW
            // --------------------------------------------------------

            FlameParticlesB.LightEmission =
                ColorUtil.ColorFromRgba(
                    50,
                    100,
                    255,
                    255
                );

            FlameParticlesB.VertexFlags =
                0xFF;


            // ========================================================
            // SIZE EVOLUTION
            // ========================================================

            FlameParticlesA.SizeEvolve =
                new EvolvingNatFloat(
                    EnumTransformFunction.LINEAR,
                    1.75f
                );

            FlameParticlesB.SizeEvolve =
                new EvolvingNatFloat(
                    EnumTransformFunction.LINEAR,
                    1.8f
                );
        }


        // ============================================================
        // START USING FLAMETHROWER
        // ============================================================

        public override void OnHeldInteractStart(
            ItemSlot slot,
            EntityAgent byEntity,
            BlockSelection blockSel,
            EntitySelection entitySel,
            bool firstEvent,
            ref EnumHandHandling handling)
        {
            handling = EnumHandHandling.PreventDefault;
        }


        // ============================================================
        // FLAMETHROWER ACTIVE
        // ============================================================

        public override bool OnHeldInteractStep(
            float secondsUsed,
            ItemSlot slot,
            EntityAgent byEntity,
            BlockSelection blockSel,
            EntitySelection entitySel)
        {
            IWorldAccessor world = byEntity.World;


            // --------------------------------------------------------
            // STOP WHEN RIGHT MOUSE IS RELEASED
            // --------------------------------------------------------

            if (byEntity is EntityPlayer player &&
                !player.Controls.RightMouseDown)
            {
                return false;
            }


            // --------------------------------------------------------
            // STOP IF PLAYER IS IN WATER
            // --------------------------------------------------------

            if (byEntity.FeetInLiquid)
            {
                return false;
            }


            // --------------------------------------------------------
            // FIRE SOUND
            // --------------------------------------------------------

            AssetLocation fireSound =
                new AssetLocation(
                    "boricalchemy",
                    "sounds/firethrow"
                );

            world.PlaySoundAt(
                fireSound,
                byEntity,
                null,
                true,
                16,
                1f +
                (float)world.Rand.NextDouble() * 0.1f
            );


            // --------------------------------------------------------
            // CLIENT PARTICLES
            // --------------------------------------------------------

            if (world.Side == EnumAppSide.Client)
            {
                SpawnFlameEffects(byEntity);
            }


            // --------------------------------------------------------
            // SERVER
            // --------------------------------------------------------

            if (world.Side == EnumAppSide.Server)
            {
                // ----------------------------------------------------
                // DAMAGE DURABILITY
                // ----------------------------------------------------

                if (slot.Itemstack != null)
                {
                    slot.Itemstack.Item.DamageItem(
                        world,
                        byEntity,
                        slot,
                        1,
                        false
                    );
                }


                // ====================================================
                // READ DAMAGE FROM ITEM JSON
                // ====================================================

                float damageToDeal = DefaultDamage;

                if (slot.Itemstack != null)
                {
                    JsonObject attr =
                        slot.Itemstack.Collectible.Attributes;

                    if (attr != null &&
                        attr["weaponDamage"].Exists)
                    {
                        damageToDeal =
                            attr["weaponDamage"].AsFloat();
                    }
                }


                // ----------------------------------------------------
                // DEAL FLAME DAMAGE
                // ----------------------------------------------------

                ProcessFlameDamage(
                    byEntity,
                    FlameRange,
                    damageToDeal
                );


                // ----------------------------------------------------
                // CHECK DURABILITY
                // ----------------------------------------------------

                if (slot.Itemstack != null)
                {
                    int itemDurability =
                        slot.Itemstack.Item
                            .GetRemainingDurability(
                                slot.Itemstack
                            );

                    if (itemDurability <= 0)
                    {
                        ReplaceWithEmptyFlamethrower(
                            world,
                            slot
                        );

                        return false;
                    }
                }
            }


            return true;
        }


        // ============================================================
        // REPLACE EMPTY FLAMETHROWER
        // ============================================================

        private void ReplaceWithEmptyFlamethrower(
            IWorldAccessor world,
            ItemSlot slot)
        {
            AssetLocation replacementCode =
                new AssetLocation(
                    "boricalchemy:flamethrowerempty"
                );

            Item replacementItem =
                world.GetItem(replacementCode);

            if (replacementItem != null)
            {
                ItemStack replacementStack =
                    new ItemStack(
                        replacementItem,
                        1
                    );

                slot.Itemstack =
                    replacementStack;
            }
            else
            {
                slot.Itemstack = null;
            }

            slot.MarkDirty();
        }


        // ============================================================
        // COPY PARTICLE PROPERTIES
        // ============================================================

        private SimpleParticleProperties CloneParticles(
            SimpleParticleProperties source)
        {
            return new SimpleParticleProperties()
            {
                MinQuantity =
                    source.MinQuantity,

                AddQuantity =
                    source.AddQuantity,

                Color =
                    source.Color,

                // IMPORTANT:
                // Preserve particle emission.
                LightEmission =
                    source.LightEmission,

                // IMPORTANT:
                // Preserve particle glow.
                VertexFlags =
                    source.VertexFlags,

                MinPos =
                    source.MinPos.Clone(),

                AddPos =
                    source.AddPos.Clone(),

                MinVelocity =
                    source.MinVelocity.Clone(),

                AddVelocity =
                    source.AddVelocity.Clone(),

                LifeLength =
                    source.LifeLength,

                GravityEffect =
                    source.GravityEffect,

                MinSize =
                    source.MinSize,

                MaxSize =
                    source.MaxSize,

                ParticleModel =
                    source.ParticleModel,

                SizeEvolve =
                    source.SizeEvolve
            };
        }


        // ============================================================
        // SPAWN FLAME PARTICLES
        // ============================================================

        private void SpawnFlameEffects(
            EntityAgent byEntity)
        {
            IWorldAccessor world =
                byEntity.World;

            ICoreClientAPI capi =
                world.Api as ICoreClientAPI;

            Vec3d handPos =
                byEntity.Pos.XYZ.AddCopy(
                    0,
                    byEntity.LocalEyePos.Y,
                    0
                );

            double forwardOffset = 0.8;
            double rightOffset = 0.35;
            double downOffset = -0.35;


            // --------------------------------------------------------
            // FIRST PERSON OFFSETS
            // --------------------------------------------------------

            if (capi != null &&
                capi.World.Player.CameraMode ==
                EnumCameraMode.FirstPerson)
            {
                forwardOffset = 0.8;
                rightOffset = 0.15;
                downOffset = -0.25;
            }


            // --------------------------------------------------------
            // FORWARD
            // --------------------------------------------------------

            Vec3d forwardVec =
                new Vec3d(0, 0, 0).Ahead(
                    forwardOffset,
                    byEntity.Pos.Pitch,
                    byEntity.Pos.Yaw
                );


            // --------------------------------------------------------
            // RIGHT
            // --------------------------------------------------------

            Vec3d rightVec =
                new Vec3d(0, 0, 0).Ahead(
                    rightOffset,
                    0,
                    byEntity.Pos.Yaw +
                    GameMath.PIHALF
                );


            // --------------------------------------------------------
            // DOWN
            // --------------------------------------------------------

            Vec3d downVec =
                new Vec3d(
                    0,
                    downOffset,
                    0
                );


            // --------------------------------------------------------
            // FINAL POSITION
            // --------------------------------------------------------

            Vec3d finalSpawnPos =
                handPos
                    .Add(forwardVec)
                    .Add(rightVec)
                    .Add(downVec);


            // --------------------------------------------------------
            // FLAME VELOCITY
            // --------------------------------------------------------

            Vec3f pushVelocity =
                new Vec3d(0, 0, 0)
                    .Ahead(
                        7.0f,
                        byEntity.Pos.Pitch,
                        byEntity.Pos.Yaw
                    )
                    .ToVec3f();


            // ========================================================
            // BLUE FLAME A
            // ========================================================

            SimpleParticleProperties spawnParticlesA =
                CloneParticles(
                    FlameParticlesA
                );

            spawnParticlesA.MinPos =
                finalSpawnPos.AddCopy(
                    -0.1,
                    -0.1,
                    -0.1
                );

            spawnParticlesA.MinVelocity =
                pushVelocity;

            world.SpawnParticles(
                spawnParticlesA
            );


            // ========================================================
            // BLUE FLAME B
            // ========================================================

            SimpleParticleProperties spawnParticlesB =
                CloneParticles(
                    FlameParticlesB
                );

            spawnParticlesB.MinPos =
                finalSpawnPos.AddCopy(
                    -0.1,
                    -0.1,
                    -0.1
                );

            spawnParticlesB.MinVelocity =
                pushVelocity;

            world.SpawnParticles(
                spawnParticlesB
            );
        }


        // ============================================================
        // LINE OF SIGHT
        // ============================================================

        private bool HasLineOfSight(
            IWorldAccessor world,
            Vec3d start,
            Vec3d end)
        {
            Vec3d dir =
                end - start;

            double distance =
                dir.Length();

            dir.Normalize();

            BlockPos pos =
                new BlockPos();

            for (
                double d = 0;
                d < distance;
                d += 0.1
            )
            {
                Vec3d checkPos =
                    start + dir * d;

                pos.Set(
                    (int)Math.Floor(checkPos.X),
                    (int)Math.Floor(checkPos.Y),
                    (int)Math.Floor(checkPos.Z)
                );

                Block block =
                    world.BlockAccessor.GetBlock(
                        pos
                    );

                if (block.BlockMaterial !=
                    EnumBlockMaterial.Air)
                {
                    return false;
                }
            }

            return true;
        }


        // ============================================================
        // PROCESS FLAME DAMAGE
        // ============================================================

        private void ProcessFlameDamage(
            EntityAgent byEntity,
            float range,
            float damage)
        {
            IWorldAccessor world =
                byEntity.World;

            Vec3d eyePos =
                byEntity.Pos.XYZ.Add(
                    0,
                    byEntity.LocalEyePos.Y,
                    0
                );

            Entity[] targets =
                world.GetEntitiesAround(
                    eyePos,
                    range,
                    range,
                    (e) =>
                        e.EntityId !=
                            byEntity.EntityId
                        &&
                        e.Alive
                );

            Vec3d lookDir =
                new Vec3d(0, 0, 0)
                    .Ahead(
                        1.0f,
                        byEntity.Pos.Pitch,
                        byEntity.Pos.Yaw
                    )
                    .Normalize();

            foreach (
                Entity targetEntity
                in targets)
            {
                Vec3d targetPos =
                    targetEntity.Pos.XYZ.Add(
                        0,
                        targetEntity.LocalEyePos.Y,
                        0
                    );

                Vec3d targetDir =
                    (targetPos - eyePos)
                    .Normalize();

                double dotProduct =
                    lookDir.Dot(
                        targetDir
                    );

                if (dotProduct > 0.88)
                {
                    if (!HasLineOfSight(
                        world,
                        eyePos,
                        targetPos))
                    {
                        continue;
                    }

                    targetEntity.ReceiveDamage(
                        new DamageSource()
                        {
                            Source =
                                EnumDamageSource.Entity,

                            SourceEntity =
                                byEntity,

                            Type =
                                EnumDamageType.Fire
                        },

                        damage
                    );

                    targetEntity.Ignite();
                }
            }
        }
    }
}