﻿using Vintagestory.API.Client;
using Vintagestory.API.Common;
using Vintagestory.API.MathTools;
using Vintagestory.API.Util;
using Vintagestory.GameContent;

namespace Boricalchemy
{
    public class ItemSawdust : Item
    {
        public override void OnHeldInteractStart(ItemSlot itemslot, EntityAgent byEntity, BlockSelection blockSel, EntitySelection entitySel, bool firstEvent, ref EnumHandHandling handHandling)
        {
            // Requires a valid block target and Shift + Right-Click
            if (blockSel == null || byEntity?.World == null || !byEntity.Controls.ShiftKey)
            {
                base.OnHeldInteractStart(itemslot, byEntity, blockSel, entitySel, firstEvent, ref handHandling);
                return;
            }

            IWorldAccessor world = byEntity.World;
            BlockPos onPos = blockSel.DidOffset ? blockSel.Position : blockSel.Position.AddCopy(blockSel.Face);
            IPlayer byPlayer = world.PlayerByUid((byEntity as EntityPlayer)?.PlayerUID);

            // Check claim permissions before placing
            if (!world.Claims.TryAccess(byPlayer, onPos, EnumBlockAccessFlags.BuildOrBreak))
            {
                return;
            }

            Block aimedBlock = world.BlockAccessor.GetBlock(blockSel.Position);

            // ----------------------------------------------------
            // PIT KILN CREATION TRIGGER (Targeting Ground Storage)
            // ----------------------------------------------------
            if (aimedBlock is BlockGroundStorage && !(aimedBlock is BlockPitkiln))
            {
                BlockPitkiln blockpk = world.GetBlock(new AssetLocation("game:pitkiln")) as BlockPitkiln;
                if (blockpk != null)
                {
                    // Call TryCreateKiln, which will be intercepted and handled by our Harmony patch!
                    if (blockpk.TryCreateKiln(world, byPlayer, blockSel.Position))
                    {
                        handHandling = EnumHandHandling.PreventDefault;
                        return;
                    }
                }
            }

            // Fallback to standard item interaction if not targeting ground storage
            base.OnHeldInteractStart(itemslot, byEntity, blockSel, entitySel, firstEvent, ref handHandling);
        }

        public override WorldInteraction[] GetHeldInteractionHelp(ItemSlot inSlot)
        {
            return new WorldInteraction[]
            {
                new WorldInteraction()
                {
                    HotKeyCode = "shift",
                    ActionLangCode = "heldhelp-createfirepit", // Or custom help text if preferred
                    MouseButton = EnumMouseButton.Right,
                }
            }.Append(base.GetHeldInteractionHelp(inSlot));
        }
    }
}