﻿using System;
using Vintagestory.API.Client;
using Vintagestory.API.Common;
using Vintagestory.API.Common.Entities;
using Vintagestory.API.MathTools;
using Vintagestory.GameContent;

namespace BoricAlchemy.blocks
{
    public class ItemFlamethrowerEmpty : Item
    {
        public override void OnHeldInteractStart(
            ItemSlot slot,
            EntityAgent byEntity,
            BlockSelection blockSel,
            EntitySelection entitySel,
            bool firstEvent,
            ref EnumHandHandling handling)
        {
            bool filled = TryFillItemFromLiquid(slot, byEntity, blockSel, "boricalchemy:diesel", 1000, "boricalchemy:flamethrower-diesel", ref handling);
            if (filled) { return; }
            filled = TryFillItemFromLiquid(slot, byEntity, blockSel, "boricalchemy:gasoline", 1000, "boricalchemy:flamethrower", ref handling);
            if (filled){return;}
            filled = TryFillItemFromLiquid(slot, byEntity, blockSel, "boricalchemy:naphtha", 1000, "boricalchemy:flamethrower-naphtha", ref handling);
            if (filled) { return; }
            filled = TryFillItemFromLiquid(slot, byEntity, blockSel, "boricalchemy:isopropanol", 1000, "boricalchemy:flamethrower-isopropanol", ref handling);
            if (filled) { return; }
            filled = TryFillItemFromLiquid(slot, byEntity, blockSel, "game:alcoholportion", 1000, "boricalchemy:flamethrower-ethanol", ref handling);
            if (filled) { return; }
            filled = TryFillItemFromLiquid(slot, byEntity, blockSel, "boricalchemy:methanol", 1000, "boricalchemy:flamethrower-methanol", ref handling);
            if (filled) { return; }
            filled = TryFillItemFromLiquid(slot, byEntity, blockSel, "boricalchemy:flammol", 1000, "boricalchemy:flamethrower-flammol", ref handling);
            if (filled) { return; }


            base.OnHeldInteractStart(
                slot,
                byEntity,
                blockSel,
                entitySel,
                firstEvent,
                ref handling
            );
        }


        private bool TryFillItemFromLiquid(
            ItemSlot heldSlot,
            EntityAgent byEntity,
            BlockSelection blockSel,
            string liquidCode,
            int requiredAmount,
            string resultItemCode,
            ref EnumHandHandling handling)
        {
            if (blockSel == null || blockSel.Position == null)
            {
                return false;
            }

            IWorldAccessor world = byEntity.World;

            BlockEntity blockEntity =
                world.BlockAccessor.GetBlockEntity(blockSel.Position);

            if (blockEntity is not BlockEntityLiquidContainer container)
            {
                return false;
            }

            // Barrels have 2 slots, with the liquid in the last slot.
            // Buckets have 1 slot, so this is index 0.
            int liquidSlotIndex = container.Inventory.Count - 1;

            if (liquidSlotIndex < 0)
            {
                return false;
            }

            ItemSlot liquidSlot =
                container.Inventory[liquidSlotIndex];

            ItemStack contents =
                liquidSlot.Itemstack;

            if (contents?.Collectible == null)
            {
                return false;
            }

            AssetLocation requiredLiquid =
                new AssetLocation(liquidCode);

            bool correctLiquid =
                contents.Collectible.Code.Equals(requiredLiquid);

            bool hasEnoughLiquid =
                contents.StackSize >= requiredAmount;

            if (!correctLiquid || !hasEnoughLiquid)
            {
                return false;
            }

            // Prevent the normal item interaction.
            handling = EnumHandHandling.PreventDefault;

            // Inventory changes should only happen on the server.
            if (world.Side == EnumAppSide.Server)
            {
                // Remove the requested amount of liquid.
                contents.StackSize -= requiredAmount;

                if (contents.StackSize <= 0)
                {
                    liquidSlot.Itemstack = null;
                }
                else
                {
                    liquidSlot.Itemstack = contents;
                }

                liquidSlot.MarkDirty();
                container.MarkDirty(true);


                // Create the resulting filled item.
                AssetLocation resultCode =
                    new AssetLocation(resultItemCode);

                Item resultItem =
                    world.GetItem(resultCode);

                if (resultItem != null)
                {
                    heldSlot.Itemstack =
                        new ItemStack(resultItem, 1);

                    heldSlot.MarkDirty();
                }
            }

            return true;
        }
    }
}