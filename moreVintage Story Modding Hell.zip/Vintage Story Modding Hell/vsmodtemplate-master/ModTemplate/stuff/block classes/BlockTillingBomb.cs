﻿using System.Collections.Generic;
using Vintagestory.API.Common;
using Vintagestory.API.MathTools;

namespace Vintagestory.GameContent
{
    public class BlockTillingBomb : BlockBomb
    {
        // Define the radius of the circle to till around the bomb
        private readonly int tillRadius = 4;

        public override void OnBlockExploded(IWorldAccessor world, BlockPos pos, BlockPos explosionCenter, EnumBlastType blastType, string ignitedByPlayerUid)
        {
            // Prevent execution on client side to keep world changes synced
            if (world.Side == EnumAppSide.Client) return;

            IBlockAccessor blockAccessor = world.BlockAccessor;

            // Optional: Play a sound and spawn cosmetic smoke/particles at the impact site
            world.PlaySoundAt(new AssetLocation("game:sounds/effect/shatter"), pos.X + 0.5, pos.Y + 0.5, pos.Z + 0.5, null, true, 16);

            // Scan the area within a bounding box defined by the radius
            for (int x = -tillRadius; x <= tillRadius; x++)
            {
                for (int z = -tillRadius; z <= tillRadius; z++)
                {
                    // Strict circular filtering: only till blocks inside the circular radius
                    if (x * x + z * z > tillRadius * tillRadius) continue;

                    // Check positions from 2 blocks below up to 2 blocks above the bomb height
                    for (int y = -2; y <= 2; y++)
                    {
                        BlockPos targetPos = pos.AddCopy(x, y, z);
                        Block targetBlock = blockAccessor.GetBlock(targetPos);

                        // Look for standard soil/dirt blocks
                        if (targetBlock.Code.Path.StartsWith("soil-"))
                        {
                            BlockPos abovePos = targetPos.UpCopy();
                            Block aboveBlock = blockAccessor.GetBlock(abovePos);

                            // Condition: Tills only if there is a gas/air block directly above it
                            if (aboveBlock.BlockMaterial == EnumBlockMaterial.Air)
                            {
                                // Look up the tilled soil equivalent matching the original soil's fertility
                                string fertility = targetBlock.LastCodePart(); // e.g., "low", "medium", "high"
                                Block tilledBlock = world.GetBlock(new AssetLocation($"game:tilledsoil-{fertility}-raw"));

                                if (tilledBlock != null)
                                {
                                    // Change the block to tilled soil and notify neighboring blocks
                                    blockAccessor.SetBlock(tilledBlock.BlockId, targetPos);
                                    blockAccessor.TriggerNeighbourBlockUpdate(targetPos);
                                }
                            }
                        }
                    }
                }
            }

            // Remove the bomb itself safely without causing an actual structural blast
            blockAccessor.SetBlock(0, pos);
            blockAccessor.TriggerNeighbourBlockUpdate(pos);
        }
    }
}
