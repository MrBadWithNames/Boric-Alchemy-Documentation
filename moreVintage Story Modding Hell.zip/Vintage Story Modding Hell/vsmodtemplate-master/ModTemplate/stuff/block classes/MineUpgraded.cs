﻿using ModTemplate;
using System;
using Vintagestory.API.Common;
using Vintagestory.API.Common.Entities;
using Vintagestory.API.Config;
using Vintagestory.API.MathTools;
using Vintagestory.API.Server;

namespace BoricAlchemy.blocks
{
    public class MineUpgraded : Block
    {
        public override void OnEntityCollide(IWorldAccessor world, Entity entity, BlockPos pos, BlockFacing facing, Vec3d collideSpeed, bool isImpact)
        {
            if (world.Side == EnumAppSide.Server)
            {
                ICoreServerAPI sapi = world.Api as ICoreServerAPI;

                bool damageBlocks = ModTemplateModSystem.Config.DamageBlocks;

                if (damageBlocks == true)
                {
                    if (sapi != null)
                    {
                        sapi.World.BlockAccessor.SetBlock(0, pos);
                        sapi.World.CreateExplosion(pos, EnumBlastType.RockBlast, 4.0, 8.0);
                    }

                }
                else {
                    if (sapi != null)
                    {
                        sapi.World.BlockAccessor.SetBlock(0, pos);
                        sapi.World.CreateExplosion(pos, EnumBlastType.EntityBlast, 4.0, 8.0);
                    }
                }

            }
            base.OnEntityCollide(world, entity, pos, facing, collideSpeed, isImpact);
        }
    }
}