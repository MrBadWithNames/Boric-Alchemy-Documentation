﻿using Vintagestory.API.Common;
using Vintagestory.GameContent;

namespace BoricAlchemy.blocks
{
    public class MyCustomCookingContainer : BlockCookingContainer
    {
        public new int MaxServingSize = 40;
        
        public override void OnLoaded(ICoreAPI api)
        {
            base.OnLoaded(api);
            MaxServingSize = 40;
        }




    }
}