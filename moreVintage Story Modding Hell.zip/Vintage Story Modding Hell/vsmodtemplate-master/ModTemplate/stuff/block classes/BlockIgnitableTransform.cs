﻿using Vintagestory.API.Common;
using Vintagestory.API.MathTools;

public class BlockIgnitableTransform : Block
{
    public string TransformToBlockCode = "boricalchemy:litbonfire";

    private const float IgniteTime = 2f; // seconds

    public override bool OnBlockInteractStart(
        IWorldAccessor world,
        IPlayer byPlayer,
        BlockSelection blockSel)
    {
        ItemStack heldItem = byPlayer.InventoryManager.ActiveHotbarSlot?.Itemstack;

        if (heldItem != null && heldItem.Collectible.Code != null)
        {
            string itemPath = heldItem.Collectible.Code.Path;

            // Checks if the item is a torch (covers vanilla and common modded torches)
            if (itemPath.Contains("torch"))
            {
                // Return true to claim the interaction (works for both normal and shift-clicks)
                return true;
            }
        }

        return base.OnBlockInteractStart(world, byPlayer, blockSel);
    }

    public override bool OnBlockInteractStep(
       float secondsUsed,
       IWorldAccessor world,
       IPlayer byPlayer,
       BlockSelection blockSel)
    {
        if (secondsUsed >= IgniteTime)
        {
            // Only mutate the world on the server side to avoid ghost blocks / desyncs
            if (world.Side == EnumAppSide.Server)
            {
                Block targetBlock = world.GetBlock(
                    new AssetLocation(TransformToBlockCode)
                );

                if (targetBlock != null)
                {
                    world.BlockAccessor.SetBlock(
                        targetBlock.BlockId,
                        blockSel.Position
                    );
                }
            }

            return false; // Stop interacting, ignition complete
        }

        return true; // Keep holding
    }

    public override void OnBlockInteractStop(
        float secondsUsed,
        IWorldAccessor world,
        IPlayer byPlayer,
        BlockSelection blockSel)
    {
        // Player let go before ignition completed
    }
}