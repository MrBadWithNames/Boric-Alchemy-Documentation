﻿using System;
using Vintagestory.API.Common;
using Vintagestory.API.MathTools;

namespace BoricAlchemy.blocks
{
    public class BCustomHarvest : Block
    {
        public override bool OnBlockInteractStart(IWorldAccessor world, IPlayer byPlayer, BlockSelection blockSel)
        {
            if (world.Side == EnumAppSide.Client) return true;

            string targetBlockCode = Attributes?["convertsTo"]?.AsString();
            string givenItem = Attributes?["givenItem"]?.AsString();
            int neededItemAmount = Attributes != null ? Attributes["givenAmount"].AsInt(1) : 1;
            int neededItemVar = Attributes != null ? Attributes["givenAmountVar"].AsInt(1) : 1;

            Random random = new Random();
            int tempN = (int)Math.Round(random.NextDouble() * neededItemVar);
            int neededItemAmountX = neededItemAmount + tempN;

            if (targetBlockCode == null || givenItem == null)
                return base.OnBlockInteractStart(world, byPlayer, blockSel);


            AssetLocation itemAsset = new AssetLocation(givenItem);
            ItemStack itemStack = null;

            Item item = world.GetItem(itemAsset);
            if (item != null)
            {
                itemStack = new ItemStack(item, neededItemAmountX);
            }
            else
            {
                Block blockItem = world.GetBlock(itemAsset);
                if (blockItem != null)
                {
                    itemStack = new ItemStack(blockItem, neededItemAmount);
                }
            }

            if (itemStack != null)
            {
                Vec3d dropPosition = blockSel.Position.ToVec3d().Add(0.5, 0.5, 0.5);
                world.SpawnItemEntity(itemStack, dropPosition);
            }

            Block nextBlock = world.GetBlock(new AssetLocation(targetBlockCode));
            if (nextBlock != null)
            {
                world.BlockAccessor.SetBlock(nextBlock.Id, blockSel.Position);
                world.BlockAccessor.TriggerNeighbourBlockUpdate(blockSel.Position);
            }

            return true; 
        }
    }
}