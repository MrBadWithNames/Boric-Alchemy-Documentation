﻿using System;
using Vintagestory.API.Common;
using Vintagestory.API.Common.Entities;
using Vintagestory.API.Config;
using Vintagestory.API.MathTools;
using Vintagestory.API.Server;
using Vintagestory.API.Datastructures;

namespace BoricAlchemy.blocks
{
    public class Beartrap : Block
    {

        public override void OnEntityCollide(IWorldAccessor world, Entity entity, BlockPos pos, BlockFacing facing, Vec3d collideSpeed, bool isImpact)
        {

            if (world.Side == EnumAppSide.Server)
            {
                ICoreServerAPI sapi = world.Api as ICoreServerAPI;


                if (sapi != null)
                {
                    string blockCodeToSet = Attributes?["blockUsed"].AsString("");
                    float dmg = (float)(Attributes?["blockDamage"].AsInt(0));
                    int nextBlockId = 0;

                    if (!string.IsNullOrEmpty(blockCodeToSet))
                    {
                        // 2. Parse the string into an AssetLocation
                        AssetLocation loc = new AssetLocation(blockCodeToSet);

                        // 3. Find the block in the game registry
                        Block targetBlock = sapi.World.GetBlock(loc);

                        if (targetBlock != null)
                        {
                            nextBlockId = targetBlock.BlockId;
                        }
                    }

                    // 4. Swap the block and deal damage
                    sapi.World.BlockAccessor.SetBlock(nextBlockId, pos);
                    entity.ReceiveDamage(new DamageSource(), dmg);
                    sapi.World.BlockAccessor.MarkBlockModified(pos);
                }
            }
            base.OnEntityCollide(world, entity, pos, facing, collideSpeed, isImpact);
        }
    }
}