﻿using System.Collections.Generic;
using Vintagestory.API.Common;
using Vintagestory.API.MathTools;
using Vintagestory.GameContent;

namespace BoricAlchemy
{
    public class BCFakePlantVentNoReplace : BlockWaterPlant
    {
        public override ItemStack[] GetDrops(IWorldAccessor world, BlockPos pos, IPlayer byPlayer, float dropQuantityMultiplier = 1f)
        {

            if (this.Drops != null && this.Drops.Length > 0)
            {
                List<ItemStack> stacks = new List<ItemStack>();
                foreach (var drop in this.Drops)
                {
                    stacks.Add(drop.GetNextItemStack(dropQuantityMultiplier));
                }
                return stacks.ToArray();
            }

            return new ItemStack[0];
        }

        public override void OnNeighbourBlockChange(IWorldAccessor world, BlockPos pos, BlockPos neibPos)
        {
        }

        public override bool TryPlaceBlock(IWorldAccessor world, IPlayer byPlayer, ItemStack itemstack, BlockSelection blockSel, ref string failureCode)
        {
            return true;
        }
        public override void OnBlockBroken(IWorldAccessor world, BlockPos pos, IPlayer byPlayer, float dropQuantityMultiplier = 1f)
        {
            ItemStack[] drops = GetDrops(world, pos, byPlayer, dropQuantityMultiplier);

            if (drops != null)
            {
                foreach (var stack in drops)
                {
                    world.SpawnItemEntity(stack, pos.ToVec3d().Add(0.5, 0.5, 0.5));
                }
            }
            Block targetBlock = world.BlockAccessor.GetBlock(new AssetLocation("game:air"));
            if (targetBlock != null)
            {
                world.BlockAccessor.SetBlock(targetBlock.Id, pos);
            }
        }
    }
}