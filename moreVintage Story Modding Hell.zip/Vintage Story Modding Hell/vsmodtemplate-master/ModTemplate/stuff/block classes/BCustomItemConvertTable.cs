﻿using System;
using Vintagestory.API.Common;
using Vintagestory.API.MathTools;

namespace BoricAlchemy.blocks
{
    public class BCustomItemConvertTable : Block
    {
        public override bool OnBlockInteractStart(IWorldAccessor world, IPlayer byPlayer, BlockSelection blockSel)
        {
            ItemSlot slot = byPlayer.InventoryManager.ActiveHotbarSlot;

            // Run through each recipe. If a recipe matches and succeeds, we return true immediately.
            if (TryConvertBlock(world, slot, blockSel, "InA", "OutA", "NumA")) return true;
            if (TryConvertBlock(world, slot, blockSel, "InB", "OutB", "NumB")) return true;
            if (TryConvertBlock(world, slot, blockSel, "InC", "OutC", "NumC")) return true;
            if (TryConvertBlock(world, slot, blockSel, "InD", "OutD", "NumD")) return true;
            if (TryConvertBlock(world, slot, blockSel, "InE", "OutE", "NumE")) return true;

            return base.OnBlockInteractStart(world, byPlayer, blockSel);
        }

        /// <summary>
        /// Reusable helper function to handle checking a specific recipe pair and converting the block.
        /// </summary>
        private bool TryConvertBlock(IWorldAccessor world, ItemSlot slot, BlockSelection blockSel, string inAttr, string outAttr, string numAttr)
        {
            // 1. Gather values from JSON attributes
            string inputCode = Attributes?[inAttr]?.AsString();
            string outputCode = Attributes?[outAttr]?.AsString();
            int requiredAmount = Attributes != null ? Attributes[numAttr].AsInt(1) : 1;

            // If this recipe isn't configured in the JSON, skip it and let the next one try
            if (inputCode == null || outputCode == null) return false;

            // 2. Check if the player is holding the correct item and has enough of it
            if (slot.Empty || slot.Itemstack.Collectible.Code.ToString() != inputCode) return false;
            if (slot.Itemstack.StackSize < requiredAmount) return false;

            // 3. Perform the actual conversion (Only on Server side)
            if (world.Side == EnumAppSide.Server)
            {
                Block nextBlock = world.GetBlock(new AssetLocation(outputCode));
                if (nextBlock != null)
                {
                    world.BlockAccessor.SetBlock(nextBlock.Id, blockSel.Position);
                    slot.TakeOut(requiredAmount);
                    slot.MarkDirty();
                    world.BlockAccessor.TriggerNeighbourBlockUpdate(blockSel.Position);
                }
            }

            return true; // Conversion condition met and handled
        }
    }
}