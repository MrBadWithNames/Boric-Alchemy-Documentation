﻿using System;
using Vintagestory.API.Common;
using Vintagestory.API.Common.Entities;
using Vintagestory.API.Config;
using Vintagestory.API.MathTools;
using Vintagestory.API.Server;

namespace BoricAlchemy.blocks
{
    public class BCustomItemConvert : Block
    {
        public override bool OnBlockInteractStart(IWorldAccessor world, IPlayer byPlayer, BlockSelection blockSel)
        {
            ItemSlot slot = byPlayer.InventoryManager.ActiveHotbarSlot;

            // 1. Get the strings from the JSON attributes
            // If the attribute doesn't exist, it defaults to null
            string targetBlockCode = Attributes?["convertsTo"]?.AsString();
            string neededItemCode = Attributes?["requiredItem"]?.AsString();
            int neededItemAmount = Attributes != null ? Attributes["requiredItemCount"].AsInt(1) : 1;

            if (targetBlockCode == null || neededItemCode == null) return base.OnBlockInteractStart(world, byPlayer, blockSel);

            // Check if player is holding the required item (e.g., "gear-rusty")
            if (!slot.Empty && slot.Itemstack.Collectible.Code.ToString() == neededItemCode)
            {
                // Only perform the swap on the server side to prevent desync
                if (world.Side == EnumAppSide.Server)
                {
                    // Get the new block type from the API
                    Block nextBlock = world.GetBlock(new AssetLocation(targetBlockCode));

                    if (nextBlock != null)
                    {
                        if (slot.Itemstack.StackSize >= neededItemAmount)
                        {
                            world.BlockAccessor.SetBlock(nextBlock.Id, blockSel.Position);
                            slot.TakeOut(neededItemAmount);
                            slot.MarkDirty();
                        }
                    }
                }
                return true; // done!
            }

            return base.OnBlockInteractStart(world, byPlayer, blockSel);
        }
    }
}