﻿using System;
using Vintagestory.API.Common;
using Vintagestory.API.MathTools;
using Vintagestory.GameContent;

namespace BoricAlchemy.blocks
{
    public class BCustomEmptyableBlock : Block
    {
        public override void OnHeldInteractStart(ItemSlot slot, EntityAgent byEntity, BlockSelection blockSel, EntitySelection entitySel, bool firstEvent, ref EnumHandHandling handHandling)
        {
            if (blockSel == null) return;

            IWorldAccessor world = byEntity.World;
            BlockEntity targetEntity = world.BlockAccessor.GetBlockEntity(blockSel.Position);

            if (targetEntity is BlockEntityBarrel barrel)
            {
                handHandling = EnumHandHandling.Handled;

                if (world.Side == EnumAppSide.Server)
                {
                    ItemSlot liquidSlot = barrel.Inventory[1];
                    string liquidToPutInside = Attributes?["liquidCode"]?.AsString();
                    string returnItemCode = Attributes?["returnItemCode"]?.AsString();

                    AssetLocation fluidAsset = new AssetLocation(liquidToPutInside);
                    Item fluidItem = world.GetItem(fluidAsset);

                    if (fluidItem == null)
                    {
                        world.Logger.Error("Could not find liquid item registered with code: " + liquidToPutInside);
                        return;
                    }
                    if (returnItemCode == null)
                    {
                        world.Logger.Error("Could not find liquid item registered with code: " + returnItemCode);
                        return;
                    }

                    int portionsPerLitre = 100; 
                    if (fluidItem.Attributes != null && fluidItem.Attributes["portionsPerLitre"].Exists)
                    {
                        portionsPerLitre = fluidItem.Attributes["portionsPerLitre"].AsInt(100);
                    }


                    int barrelCapacityLitres = 50; 
                    if (barrel.Block?.Attributes != null && barrel.Block.Attributes["maxLiquidCapacity"].Exists)
                    {
                        barrelCapacityLitres = barrel.Block.Attributes["maxLiquidCapacity"].AsInt(50);
                    }

                    int maxBarrelStackSize = barrelCapacityLitres * portionsPerLitre;


                    // 1. This reads your JSON configuration (defaulting to 10 if missing)
                    int ammountOfLiquid = Attributes != null ? Attributes["fillAmountLitres"].AsInt(10) : 10;

                    // 2. FIX: Multiply by the variable, NOT the hardcoded number 10!
                    int amountToAdd = ammountOfLiquid * portionsPerLitre;

                    int liquidAmount = 0;
                    bool tryToFill = false;

                    if (liquidSlot.Itemstack != null)
                    {
                        liquidAmount = liquidSlot.Itemstack.StackSize;
                        int freeLiquidSlots = maxBarrelStackSize - liquidAmount;
                        string itemCode = liquidSlot.Itemstack.Collectible.Code.ToString();


                        if (itemCode == liquidToPutInside && freeLiquidSlots >= amountToAdd)
                        {
                            tryToFill = true;
                        }
                    }
                    else
                    {
                        tryToFill = true;
                    }

                    if (tryToFill)
                    {
                        if (liquidSlot.Itemstack == null)
                        {
                            liquidSlot.Itemstack = new ItemStack(fluidItem, amountToAdd);
                        }
                        else
                        {
                            liquidSlot.Itemstack.StackSize += amountToAdd;
                        }
                        barrel.Inventory.MarkSlotDirty(1);
                        barrel.MarkDirty(true);

                        IPlayer byPlayer = (byEntity as EntityPlayer)?.Player;
                        world.PlaySoundAt(new AssetLocation("game:sounds/effect/water-pour"), blockSel.Position.X, blockSel.Position.Y, blockSel.Position.Z, byPlayer);

                        if (byPlayer != null)
                        {
                            AssetLocation emptyJugCode = new AssetLocation(returnItemCode);


                            Block emptyJugBlock = world.GetBlock(emptyJugCode);

                            if (emptyJugBlock != null)
                            {
                                ItemStack emptyStack = new ItemStack(emptyJugBlock, 1);

                                byPlayer.InventoryManager.TryGiveItemstack(emptyStack, true);
                            }
                            else
                            {
                                world.Logger.Error("Could not find block registered with code: " + emptyJugCode);
                            }
                        }


                        slot.TakeOut(1);
                        slot.MarkDirty();
                    }
                }
            }
            else
            {
                base.OnHeldInteractStart(slot, byEntity, blockSel, entitySel, firstEvent, ref handHandling);
            }
        }
    }
}