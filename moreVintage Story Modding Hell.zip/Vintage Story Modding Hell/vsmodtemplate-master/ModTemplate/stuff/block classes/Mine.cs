﻿using System;
using Vintagestory.API.Common;
using Vintagestory.API.Common.Entities;
using Vintagestory.API.Config;
using Vintagestory.API.MathTools;
using Vintagestory.API.Server;

namespace BoricAlchemy.blocks
{
    public class Mine : Block
    {
        public override void OnEntityCollide(IWorldAccessor world, Entity entity, BlockPos pos, BlockFacing facing, Vec3d collideSpeed, bool isImpact)
        {
            if (world.Side == EnumAppSide.Server)
            {
                ICoreServerAPI sapi = world.Api as ICoreServerAPI;

                if (sapi != null)
                {
                    sapi.World.BlockAccessor.SetBlock(0, pos);
                    sapi.World.CreateExplosion(pos, EnumBlastType.EntityBlast, 4.0, 6.0);
                }
            }
            base.OnEntityCollide(world, entity, pos, facing, collideSpeed, isImpact);
        }
    }
}