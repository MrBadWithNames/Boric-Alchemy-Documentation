﻿using Vintagestory.API.Common;
using Vintagestory.API.Common.Entities;
using Vintagestory.API.Config;
using Vintagestory.GameContent;

namespace ModTemplate
{
    public class EntityBehaviorHelmetCheck : EntityBehavior
    {
        private float tickCounter = 0f;

        public EntityBehaviorHelmetCheck(Entity entity) : base(entity) { }

        public override string PropertyName() => "helmetcheck";


        public override void OnGameTick(float deltaTime)
        {
            if (entity.Api.Side != EnumAppSide.Server) return;
            if (!(entity is EntityPlayer player)) return;

            tickCounter += deltaTime;
            if (tickCounter < 1.0f) return;
            tickCounter = 0f;

            IInventory gearInv = player.Player.InventoryManager.GetOwnInventory(GlobalConstants.characterInvClassName);
            if (gearInv == null) return;

            ItemSlot headSlot = gearInv[(int)EnumCharacterDressType.Head];
            ItemSlot chestSlot = gearInv[(int)EnumCharacterDressType.ArmorBody];

            if (headSlot?.Itemstack?.Item?.Code?.Path == "divinghelm" &&
                chestSlot?.Itemstack?.Item?.Code?.Path == "divingtank")
            {
                if (chestSlot.Itemstack.Collectible.GetRemainingDurability(chestSlot.Itemstack) > 0)
                {
                    chestSlot.Itemstack.Collectible.DamageItem(player.Api.World, player, chestSlot, 1);
                }
                else
                {
                    Item emptyTank = player.Api.World.GetItem(new AssetLocation("boricalchemy:divingtankempty"));
                    if (emptyTank != null)
                    {
                        chestSlot.Itemstack = new ItemStack(emptyTank);
                        chestSlot.MarkDirty();
                    }
                }

                var oxygenBehavior = player.GetBehavior<EntityBehaviorBreathe>();
                if (oxygenBehavior != null) oxygenBehavior.Oxygen = oxygenBehavior.MaxOxygen;
            }
        }
    }
}