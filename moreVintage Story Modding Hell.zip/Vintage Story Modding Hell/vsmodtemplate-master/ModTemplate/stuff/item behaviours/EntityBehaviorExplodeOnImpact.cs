﻿using Vintagestory.API.Common;
using Vintagestory.API.Common.Entities;
using Vintagestory.API.MathTools;
using Vintagestory.API.Server;

namespace BoricAlchemy.blocks
{
    public class EntityBehaviorExplodeOnImpact : EntityBehavior
    {
        public EntityBehaviorExplodeOnImpact(Entity entity) : base(entity) { }
        public override void OnGameTick(float deltaTime)
        {
            base.OnGameTick(deltaTime);

            if (entity.Api.Side != EnumAppSide.Server) return;

            if (entity.CollidedVertically && entity.Collided)
            {
                var sapi = entity.Api as ICoreServerAPI;
                if (sapi == null) return;

                BlockPos pos = entity.Pos.AsBlockPos;
                float explosionRadius = 2f;

                sapi.World.CreateExplosion(
                    pos,
                    EnumBlastType.EntityBlast,
                    explosionRadius,
                    explosionRadius
                );
                entity.Die();
            }
        }

        public override string PropertyName() => "explodeonimpact";
    }
}