﻿using System;
using Vintagestory.API.Common;
using Vintagestory.API.Common.Entities;
using Vintagestory.API.MathTools;
using Vintagestory.API.Server;

namespace BoricAlchemy.blocks
{
    public class FogInWater : EntityBehavior
    {
        private Random random = new Random();

        public FogInWater(Entity entity) : base(entity)
        {
        }

        public override void OnGameTick(float dt)
        {
            base.OnGameTick(dt);

            if (entity.Api.Side != EnumAppSide.Server) return;

            // Only emit fog/smoke when sitting in liquid (water)
            if (entity.FeetInLiquid)
            {
                SpawnSmokeParticles();

                // Optional: Occasional dry ice fizzle/sizzle sound effect
                ICoreServerAPI sapi = entity.Api as ICoreServerAPI;
                if (sapi != null && random.NextDouble() > 0.95)
                {
                    sapi.World.PlaySoundAt(
                        new AssetLocation("game", "sounds/moltenmetal"),
                        entity.ServerPos.X,
                        entity.ServerPos.Y,
                        entity.ServerPos.Z,
                        null,
                        true,
                        16f
                    );
                }
            }
        }

        private void SpawnSmokeParticles()
        {
            ICoreServerAPI sapi = entity.Api as ICoreServerAPI;
            if (sapi == null) return;

            SimpleParticleProperties smoke = new SimpleParticleProperties()
            {
                MinQuantity = 2,
                AddQuantity = 4,
                Color = ColorUtil.ToRgba(90, 220, 220, 230), // Semi-transparent dense fog look
                MinPos = entity.ServerPos.XYZ.AddCopy(-0.2, 0.0, -0.2),
                AddPos = new Vec3d(0.2, 0.2, 0.2),
                MinVelocity = new Vec3f(-0.25f, 0.01f, -0.25f),
                AddVelocity = new Vec3f(0.5f, 0.03f, 0.5f),
                LifeLength = 1.2f,
                MinSize = 0.5f,
                MaxSize = 1.7f,
                ParticleModel = EnumParticleModel.Quad,
                GravityEffect = -0.04f, // Gentle upward drift for gas/steam
                SizeEvolve = EvolvingNatFloat.create(EnumTransformFunction.LINEAR, 2f), // Grows as it expands
                OpacityEvolve = EvolvingNatFloat.create(EnumTransformFunction.LINEAR, -70) // Fades out smoothly
            };
            sapi.World.SpawnParticles(smoke);
        }

        public override string PropertyName()
        {
            return "foginwater";
        }
    }
}