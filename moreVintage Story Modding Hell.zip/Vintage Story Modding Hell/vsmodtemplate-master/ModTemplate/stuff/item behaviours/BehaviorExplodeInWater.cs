﻿using System;
using Vintagestory.API.Common;
using Vintagestory.API.Common.Entities;
using Vintagestory.API.MathTools;
using Vintagestory.API.Server;

namespace BoricAlchemy.blocks
{

    public class EntityBehaviorExplodeInWater : EntityBehavior
    {
        private float explosionRadius = 2f;
        private int ticksInWater = 0;


        private const int fuseTicks = 45;
        private Random random = new Random();

        public EntityBehaviorExplodeInWater(Entity entity) : base(entity)
        {
        }

        public override void OnGameTick(float dt)
        {
            base.OnGameTick(dt);

            if (entity.Api.Side != EnumAppSide.Server) return;

            if (entity.FeetInLiquid)
            {
                ticksInWater++;
                if (ticksInWater >= fuseTicks && random.NextDouble() >= 0.75f)
                {
                    TriggerExplosion();
                }
                else
                {
                    SpawnSmokeParticles();
                    float pushStrength = 0.025f;
                    double pushX = (random.NextDouble() * 2.0 - 1.0) * pushStrength;
                    double pushZ = (random.NextDouble() * 2.0 - 1.0) * pushStrength;

                    entity.ServerPos.Motion.X += pushX;
                    entity.ServerPos.Motion.Z += pushZ;

                    if (random.NextDouble() <= 0.3)
                    {
                        entity.ServerPos.Motion.Y += 0.03f;
                    }

                    entity.WatchedAttributes.MarkPathDirty("serverpos");

                    // Sound
                    ICoreServerAPI sapi = entity.Api as ICoreServerAPI;
                    if (random.NextDouble() > 0.9)
                    {
                        sapi?.World.PlaySoundAt(
                            new AssetLocation("game", "sounds/sizzle"),
                            entity.ServerPos.X,
                            entity.ServerPos.Y,
                            entity.ServerPos.Z,
                            null,
                            true,
                            32f
                        );
                    }
                }
            }
        }

        private void TriggerExplosion()
        {
            ICoreServerAPI sapi = entity.Api as ICoreServerAPI;
            if (sapi == null) return;

            BlockPos pos = entity.ServerPos.AsBlockPos;
            sapi.World.CreateExplosion(
                pos,
                EnumBlastType.EntityBlast,
                explosionRadius,
                explosionRadius
            );
            entity.Die();
        }

        private void SpawnSmokeParticles()
        {
            ICoreServerAPI sapi = entity.Api as ICoreServerAPI;
            if (sapi == null) return;

            SimpleParticleProperties smoke = new SimpleParticleProperties()
            {
                MinQuantity = 3,
                AddQuantity = 5,
                Color = ColorUtil.ToRgba(65, 220, 220, 220),
                MinPos = entity.ServerPos.XYZ.AddCopy(-0.05, 0.0, -0.05),
                AddPos = new Vec3d(0.1, 0.2, 0.1),
                MinVelocity = new Vec3f(-0.5f, 0.05f, -0.5f),
                AddVelocity = new Vec3f(1.0f, 0.1f, 1.0f),
                LifeLength = 0.8f,
                MinSize = 0.4f,
                MaxSize = 1.1f,
                ParticleModel = EnumParticleModel.Quad,
                GravityEffect = -0.0f,
                OpacityEvolve = EvolvingNatFloat.create(EnumTransformFunction.LINEAR, -40)
            };
            sapi.World.SpawnParticles(smoke);
        }

        public override string PropertyName()
        {
            return "explodeinwater";
        }
    }
}