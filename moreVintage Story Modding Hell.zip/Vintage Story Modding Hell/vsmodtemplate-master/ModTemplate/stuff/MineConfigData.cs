﻿using ModTemplate;

namespace BoricAlchemy
{
    public class MineConfigData
    {
        public bool DamageBlocks = true;
        public bool GunCrackRock = true;
        public float BonfireRadius = 1.5f;
        public float BonfireDamage = 1f;
        public bool BonfireIgniteEntities = true;
        public int BonfireDuration = 4000;
        public long SpeedDuration = 20000;
        public float speedBuffMultiplier = 1.15f;
        public bool eternalBonfire = false;

        public bool RestrictLiquidStorage = true;

        public int BonfireEffectHorizontalRange = 3;
        public int BonfireEffectVerticalRange = 3;
    }
}
