﻿using HarmonyLib;
using System.Collections.Generic;
using Vintagestory.API.Client;
using Vintagestory.API.Common;
using Vintagestory.GameContent;

[HarmonyPatch(typeof(BlockLiquidContainerBase), "OnHandbookRecipeRender")]
public static class FixBucketHandbookCachePatch
{
    [HarmonyPrefix]
    public static void Prefix(BlockLiquidContainerBase __instance)
    {
        // 1. Reflect into the exact dictionary name from the class source code
        var cacheField = AccessTools.Field(typeof(BlockLiquidContainerBase), "recipeLiquidContents");

        if (cacheField != null)
        {
            // 2. Fetch the instance dictionary object
            var cache = cacheField.GetValue(__instance) as Dictionary<string, ItemStack[]>;
            if (cache != null)
            {
                // 3. Vaporize the cached string keys right before rendering
                cache.Clear();
            }
        }
    }
}
