﻿using System.Collections.Generic;
using HarmonyLib;
using Vintagestory.API.Common;
using Vintagestory.API.MathTools;
using Vintagestory.API.Server;

namespace BoricAlchemy.HarmonyPatches
{
    [HarmonyPatch(typeof(GridRecipe), nameof(GridRecipe.ConsumeInput))]
    public static class Patch_GridRecipe_ConsumeInput
    {
        private static readonly Dictionary<string, string> Replacements = new()
        {
            { "boricalchemy:combustiongenerator", "boricalchemy:combustiongeneratordry" },
            { "boricalchemy:bowlamp-oxyacetylene", "boricalchemy:bowlamp-empty" },
            { "boricalchemy:battery", "boricalchemy:batteryempty" },
            { "boricalchemy:temporalbattery", "boricalchemy:temporalbattery_dry" },
            { "boricalchemy:advancedbattery-silverchloride_zinc_ammoniumchloride-charged", "boricalchemy:advancedbattery-silverchloride_zinc_ammoniumchloride-dead" },
            { "boricalchemy:advancedbattery-copper_zinc_sulfuricacid-charged", "boricalchemy:advancedbattery-copper_zinc_sulfuricacid-dead" },
            { "boricalchemy:advancedbattery-leaddioxide_lead_sulfuricacid-charged", "boricalchemy:advancedbattery-leaddioxide_lead_sulfuricacid-dead" },
            { "boricalchemy:batterylead", "boricalchemy:batteryempty" }
        };

        public class ConsumedItemState
        {
            public ItemSlot Slot;
            public string ReplacementCode;
            public bool AlreadySpawned; // Prevents double-spawning if ConsumeInput is called multiple times
        }

        [HarmonyPrefix]
        public static void Prefix(IPlayer byPlayer, ItemSlot[] inputSlots, ref List<ConsumedItemState> __state)
        {
            if (byPlayer?.Entity?.Api?.Side != EnumAppSide.Server || inputSlots == null) return;

            __state = new List<ConsumedItemState>();

            foreach (var slot in inputSlots)
            {
                if (slot?.Itemstack == null) continue;

                string code = slot.Itemstack.Item?.Code?.ToShortString()
                              ?? slot.Itemstack.Block?.Code?.ToShortString();

                if (code != null && Replacements.TryGetValue(code, out string replacementCode))
                {
                    __state.Add(new ConsumedItemState
                    {
                        Slot = slot,
                        ReplacementCode = replacementCode,
                        AlreadySpawned = false
                    });
                }
            }
        }

        [HarmonyPostfix]
        public static void Postfix(IPlayer byPlayer, List<ConsumedItemState> __state)
        {
            if (byPlayer?.Entity == null || __state == null || __state.Count == 0) return;

            ICoreServerAPI sapi = byPlayer.Entity.Api as ICoreServerAPI;
            if (sapi == null) return;

            Vec3d spawnPos = byPlayer.Entity.Pos.XYZ.Add(0, 0.5, 0);

            foreach (var tracked in __state)
            {
                // Skip if we already spawned a replacement for this slot reference in this batch
                if (tracked.AlreadySpawned) continue;

                // If the item stack is destroyed or null, drop the broken variant at the player's feet
                bool isBrokenOrRemoved = tracked.Slot.Itemstack == null || tracked.Slot.StackSize == 0;

                if (isBrokenOrRemoved)
                {
                    tracked.AlreadySpawned = true; // Lock it so it won't duplicate

                    AssetLocation replacementLoc = new AssetLocation(tracked.ReplacementCode);
                    ItemStack replacementStack = null;

                    Item item = sapi.World.GetItem(replacementLoc);
                    if (item != null)
                    {
                        replacementStack = new ItemStack(item);
                    }
                    else
                    {
                        Block block = sapi.World.GetBlock(replacementLoc);
                        if (block != null)
                        {
                            replacementStack = new ItemStack(block);
                        }
                    }

                    if (replacementStack != null)
                    {
                        sapi.World.SpawnItemEntity(replacementStack, spawnPos);
                    }
                }
            }
        }
    }
}