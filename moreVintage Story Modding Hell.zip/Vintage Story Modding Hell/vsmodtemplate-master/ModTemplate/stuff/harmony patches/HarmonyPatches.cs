﻿using BoricAlchemy;
using BoricAlchemy.blocks;
using HarmonyLib;
using System.Collections.Generic;
using Vintagestory.API.Client;
using Vintagestory.API.Common;
using Vintagestory.GameContent;


namespace BoricAlchemy.Patches
{
    [HarmonyPatch(typeof(BlockCookingContainer), "GetRendererWhenInFirepit")]
    public class Patch_CookingContainer_Renderer
    {
        static bool Prefix(
            BlockCookingContainer __instance,
            ItemStack stack,
            BlockEntityFirepit firepit,
            ref IInFirepitRenderer __result)
        {
            if (stack.Collectible.Code.Path == "mycustomcookingcontainer")
            {
                var capi = firepit.Api as ICoreClientAPI;
                __result = new MyCustomPotRenderer(
                    capi,
                    stack,
                    firepit.Pos,
                    false
                );

                return false;
            }

            return true;
        }
    }



    //Gas in firepit
    [HarmonyPatch(typeof(BlockEntityFirepit), nameof(BlockEntityFirepit.igniteFuel))]
    public static class FirepitPatch
    {
        static void Prefix(BlockEntityFirepit __instance, ref ItemStack __state)
        {
            __state = __instance.fuelStack?.Clone();
        }

        [HarmonyPostfix]
        public static void Postfix(
            BlockEntityFirepit __instance,
            ItemStack __state
        )
        {
            if (__state?.Collectible?.Code == null)
            {
                return;
            }

            string path = __state.Collectible.Code.Path;

            // Only handle gas containers
            if (!path.StartsWith("gascontainer-"))
            {
                return;
            }

            Item emptyTank = __instance.Api.World.GetItem(
                new AssetLocation(
                    "boricalchemy",
                    "gascontainer-air"
                )
            );

            if (emptyTank == null)
            {

                return;
            }

            __instance.fuelStack = new ItemStack(emptyTank);
        }

    }




    //No gas in forge
    [HarmonyPatch(typeof(BlockEntityForge), nameof(BlockEntityForge.OnPlayerInteract))]
    public static class ForgeFuelPatch
    {
        [HarmonyPrefix]
        public static bool Prefix(
            BlockEntityForge __instance,
            IWorldAccessor world,
            IPlayer byPlayer,
            BlockSelection blockSel
        )
        {
            ItemSlot slot = byPlayer.InventoryManager.ActiveHotbarSlot;

            if (slot?.Itemstack?.Collectible?.Code == null)
            {
                return true;
            }

            AssetLocation code = slot.Itemstack.Collectible.Code;

            if (
                code.Domain != "boricalchemy" ||
                !code.Path.StartsWith("gascontainer-")
            )
            {
                return true;
            }


            if (slot.Itemstack.Collectible.GetCombustibleProperties(
                    world,
                    slot.Itemstack,
                    null
                ) is { BurnTemperature: > 1000 })
            {

                return false;
            }

            return true;
        }
    }


}