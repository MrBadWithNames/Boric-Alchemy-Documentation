﻿using HarmonyLib;
using System;
using Vintagestory.API.Client;
using Vintagestory.API.Common;
using Vintagestory.API.Config;
using Vintagestory.API.MathTools;
using Vintagestory.API.Util;
using Vintagestory.GameContent;

namespace Boricalchemy.Patches
{
    [HarmonyPatch(typeof(BlockPitkiln), "TryCreateKiln")]
    public class BlockPitkiln_TryCreateKiln_Patch
    {
        public static bool Prefix(BlockPitkiln __instance, IWorldAccessor world, IPlayer byPlayer, BlockPos pos, ref bool __result)
        {
            ItemSlot hotbarSlot = byPlayer.InventoryManager.ActiveHotbarSlot;
            if (hotbarSlot.Empty)
            {
                __result = false;
                return false;
            }

            BlockEntity be = world.BlockAccessor.GetBlockEntity(pos);
            if (be is BlockEntityGroundStorage beg)
            {
                if (!beg.OnTryCreateKiln())
                {
                    __result = false;
                    return false;
                }

                ICoreClientAPI capi = world.Api as ICoreClientAPI;
                bool ok = true;
                Block liquidblock = world.BlockAccessor.GetBlock(pos, BlockLayersAccess.Fluid);
                if (liquidblock.BlockId != 0)
                {
                    ok = false;
                    capi?.TriggerIngameError(__instance, "submerged", Lang.Get("pitkilnerror-submerged"));
                }
                if (!ok) { __result = false; return false; }

                foreach (var face in BlockFacing.HORIZONTALS.Append(BlockFacing.DOWN))
                {
                    BlockPos npos = pos.AddCopy(face);
                    Block block = world.BlockAccessor.GetBlock(npos);
                    if (!block.CanAttachBlockAt(world.BlockAccessor, __instance, npos, face.Opposite))
                    {
                        capi?.TriggerIngameError(__instance, "notsolid", Lang.Get("Pit kilns need to be surrounded by solid, non-flammable blocks"));
                        ok = false;
                        break;
                    }
                    var combustibleProps = block.GetCombustibleProperties(world, null, npos);
                    if (combustibleProps != null)
                    {
                        capi?.TriggerIngameError(__instance, "notsolid", Lang.Get("Pit kilns need to be surrounded by solid, non-flammable blocks"));
                        ok = false;
                        break;
                    }
                }
                if (!ok) { __result = false; return false; }

                Block upblock = world.BlockAccessor.GetBlock(pos.UpCopy());
                if (upblock.Replaceable < 6000)
                {
                    ok = false;
                    capi?.TriggerIngameError(__instance, "notairspace", Lang.Get("Pit kilns need one block of air space above them"));
                }
                if (!ok) { __result = false; return false; }

                // FIXED: Scan all inventory slots to find the content item (e.g., bowls) 
                // instead of hardcoding Inventory[0], which breaks when placing items in quadrants.
                ItemStack contentStack = null;
                foreach (var slot in beg.Inventory)
                {
                    if (!slot.Empty)
                    {
                        contentStack = slot.Itemstack;
                        break;
                    }
                }

                BuildStage[] buildStages = null;
                bool found = false;
                if (contentStack != null)
                {
                    foreach (var val in __instance.BuildStagesByBlock)
                    {
                        if (WildcardUtil.Match(new AssetLocation(val.Key), contentStack.Collectible.Code))
                        {
                            buildStages = val.Value;
                            found = true;
                            break;
                        }
                    }
                }

                if (!found)
                {
                    __instance.BuildStagesByBlock.TryGetValue("*", out buildStages);
                }

                if (buildStages == null) { __result = false; return false; }

                BuildStageMaterial matchedMaterial = null;
                foreach (var mat in buildStages[0].Materials)
                {
                    if (mat != null && mat.ItemStack != null &&
                        hotbarSlot.Itemstack.Equals(world, mat.ItemStack, GlobalConstants.IgnoredStackAttributes) &&
                        hotbarSlot.StackSize >= mat.ItemStack.StackSize)
                    {
                        matchedMaterial = mat;
                        break;
                    }
                }

                if (matchedMaterial == null)
                {
                    __result = false;
                    return false;
                }

                var prevInv = beg.Inventory;
                world.BlockAccessor.SetBlock(__instance.Id, pos);

                var begs = world.BlockAccessor.GetBlockEntity(pos) as BlockEntityPitKiln;
                if (begs != null)
                {
                    int count = Math.Min(prevInv.Count, begs.Inventory.Count);
                    for (int i = 0; i < count; i++)
                    {
                        begs.Inventory[i] = prevInv[i];
                    }

                }
                begs.MeshAngle = beg.MeshAngle;
                begs.OnCreated(byPlayer);
                begs.MarkMeshesDirty();
                begs.MarkDirty(true);

                hotbarSlot.MarkDirty();

                __result = true;
                return false;
            }

            __result = false;
            return false;
        }
    }
}