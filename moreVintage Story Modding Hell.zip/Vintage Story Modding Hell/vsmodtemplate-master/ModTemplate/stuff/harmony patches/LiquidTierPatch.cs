﻿using BoricAlchemy;
using HarmonyLib;
using ModTemplate;
using Vintagestory.API.Common;
using Vintagestory.API.MathTools;
using Vintagestory.GameContent;

namespace boricalchemy.patches
{
    public static class TierHelper
    {
        // Safe helper for ItemStacks and Collectibles
        public static int GetContainerTier(ItemStack stack)
        {
            if (stack == null || stack.Collectible == null) return 0;
            return stack.Collectible.Attributes?["containerTier"]?.AsInt(0) ?? 0;
        }

        public static int GetLiquidTier(ItemStack stack)
        {
            if (stack == null || stack.Collectible == null) return 0;
            return stack.Collectible.Attributes?["liquidTier"]?.AsInt(0) ?? 0;
        }
    }

    // 1. Hand-to-Hand transfers (Bucket -> Bucket in inventory/hand)
    [HarmonyPatch(typeof(BlockLiquidContainerBase), nameof(BlockLiquidContainerBase.TryPutLiquid), new[] { typeof(ItemStack), typeof(ItemStack), typeof(float) })]
    public class BlockLiquidContainerBase_TryPutLiquid_ItemStack_Patch
    {
        public static bool Prefix(ItemStack containerStack, ItemStack liquidStack, ref int __result)
        {
            if (ModTemplateModSystem.Config == null || !ModTemplateModSystem.Config.RestrictLiquidStorage)
            {
                return true; // Let the original game method run normally
            }

            // Guard against null stacks or unresolved collectibles (common during multiplayer modded item splits)
            if (liquidStack?.Collectible == null || containerStack?.Collectible == null)
            {
                return true;
            }

            int targetTier = TierHelper.GetContainerTier(containerStack);
            int liquidTier = TierHelper.GetLiquidTier(liquidStack);

            if (targetTier < liquidTier)
            {
                __result = 0;
                return false;
            }

            return true;
        }
    }

    // 2. World container transfers (In-world liquid container block)
    [HarmonyPatch(typeof(BlockLiquidContainerBase), nameof(BlockLiquidContainerBase.TryPutLiquid), new[] { typeof(BlockPos), typeof(ItemStack), typeof(float) })]
    public class BlockLiquidContainerBase_TryPutLiquid_BlockPos_Patch
    {
        public static bool Prefix(BlockLiquidContainerBase __instance, BlockPos pos, ItemStack liquidStack, ref int __result)
        {
            if (ModTemplateModSystem.Config == null || !ModTemplateModSystem.Config.RestrictLiquidStorage)
            {
                return true; // Let the original game method run normally
            }

            if (__instance == null || liquidStack?.Collectible == null)
            {
                return true;
            }

            // Block attributes are accessed directly via __instance.Attributes
            int targetTier = __instance.Attributes?["containerTier"]?.AsInt(0) ?? 0;
            int liquidTier = TierHelper.GetLiquidTier(liquidStack);

            if (targetTier < liquidTier)
            {
                __result = 0;
                return false;
            }

            return true;
        }
    }

    // 3. Barrel Block in-world interaction
    [HarmonyPatch(typeof(BlockBarrel), nameof(BlockBarrel.TryPutLiquid), new[] { typeof(BlockPos), typeof(ItemStack), typeof(float) })]
    public class BlockBarrel_TryPutLiquid_Patch
    {
        public static bool Prefix(BlockBarrel __instance, BlockPos pos, ItemStack liquidStack, ref int __result)
        {
            // Safe guard against null config or disabled setting
            if (ModTemplateModSystem.Config == null || !ModTemplateModSystem.Config.RestrictLiquidStorage)
            {
                return true;
            }

            // If no barrel instance or no liquid stack being put in (e.g. empty hand click), skip patch
            if (__instance == null || liquidStack == null || liquidStack.Collectible == null)
            {
                return true;
            }

            // Check attributes safely across block definition
            int barrelTier = __instance.Attributes?["containerTier"]?.AsInt(0) ?? 0;
            int liquidTier = TierHelper.GetLiquidTier(liquidStack);

            if (barrelTier < liquidTier)
            {
                __result = 0;
                return false;
            }

            return true;
        }
    }
}