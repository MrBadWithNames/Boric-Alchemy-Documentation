﻿using System.Collections.Generic;
using Vintagestory.API.Common;
using Vintagestory.API.Common.Entities;
using Vintagestory.API.Datastructures;
using Vintagestory.API.MathTools;
using Vintagestory.API.Server;

namespace BoricAlchemy
{
    public class EntityBehaviorPoison : EntityBehavior
    {
        private float dripAccumulator = 0f;

        public EntityBehaviorPoison(Entity entity) : base(entity) { }

        public override string PropertyName() => "poisoned";

        // Add or refresh a specific effect ID independently
        public void AddOrRefreshEffect(int effectId, float duration, float interval, float damage, int red, int green, int blue, float speedModifier)
        {
            ITreeAttribute rootTree = entity.WatchedAttributes.GetOrAddTreeAttribute("boricalchemy:active_effects");
            string key = "effect_" + effectId;

            ITreeAttribute effectTree = rootTree.GetTreeAttribute(key);
            if (effectTree == null)
            {
                effectTree = new TreeAttribute();
                rootTree[key] = effectTree; // Fixed sub-tree assignment
            }

            effectTree.SetFloat("durationRemaining", duration);
            effectTree.SetFloat("damageInterval", interval);
            effectTree.SetFloat("damagePerTick", damage);
            effectTree.SetFloat("tickAccumulator", 0f);
            effectTree.SetFloat("speedModifier", speedModifier);
            effectTree.SetInt("partRed", red);
            effectTree.SetInt("partGreen", green);
            effectTree.SetInt("partBlue", blue);

            entity.WatchedAttributes.MarkPathDirty("boricalchemy:active_effects");
            ApplySpeedModifiers();
        }

        private void ApplySpeedModifiers()
        {
            ITreeAttribute rootTree = entity.WatchedAttributes.GetTreeAttribute("boricalchemy:active_effects");
            if (rootTree == null) return;

            float lowestSpeedModifier = 1.0f;
            bool hasSlowEffect = false;

            foreach (var pair in rootTree)
            {
                if (pair.Value is ITreeAttribute effectTree)
                {
                    float spd = effectTree.GetFloat("speedModifier", 1.0f);
                    if (spd < 1.0f)
                    {
                        hasSlowEffect = true;
                        if (spd < lowestSpeedModifier) lowestSpeedModifier = spd;
                    }
                }
            }

            if (entity is EntityPlayer player && player.Stats != null)
            {
                if (hasSlowEffect)
                {
                    float statOffset = lowestSpeedModifier - 1.0f;
                    player.Stats.Set("walkspeed", "boricalchemy:poison", statOffset, false);
                }
                else
                {
                    player.Stats.Remove("walkspeed", "boricalchemy:poison");
                }
            }
        }

        private void RemoveAllSpeedModifiers()
        {
            if (entity is EntityPlayer player && player.Stats != null)
            {
                player.Stats.Remove("walkspeed", "boricalchemy:poison");
            }
        }

        public override void OnGameTick(float dt)
        {
            base.OnGameTick(dt);

            if (entity.World.Side != EnumAppSide.Server) return;

            // --- WATER WASH-OFF CHECK ---
            Block blockAtFeet = entity.World.BlockAccessor.GetBlock(entity.Pos.AsBlockPos);
            BlockPos headPos = entity.Pos.AsBlockPos.UpCopy(1);
            Block blockAtHead = entity.World.BlockAccessor.GetBlock(headPos);

            if (blockAtFeet.IsLiquid() || blockAtHead.IsLiquid() || entity.FeetInLiquid)
            {
                if (entity.World is IServerWorldAccessor serverWorld)
                {
                    SimpleParticleProperties washParticles = new SimpleParticleProperties(
                        15f, 25f,
                        ColorUtil.ColorFromRgba(255, 255, 255, 180),
                        entity.Pos.XYZ.AddCopy(-0.3, 0.2, -0.3),
                        entity.Pos.XYZ.AddCopy(0.3, 1.2, 0.3),
                        new Vec3f(-1f, 1f, -1f),
                        new Vec3f(2f, 2f, 2f),
                        0.3f,
                        0.5f,
                        0.1f, 0.2f,
                        EnumParticleModel.Quad
                    );
                    serverWorld.SpawnParticles(washParticles);
                }

                RemoveAllSpeedModifiers();
                entity.WatchedAttributes.RemoveAttribute("boricalchemy:active_effects");
                entity.WatchedAttributes.MarkPathDirty("boricalchemy:active_effects");
                entity.RemoveBehavior(this);
                return;
            }
            // ----------------------------

            ITreeAttribute rootTree = entity.WatchedAttributes.GetTreeAttribute("boricalchemy:active_effects");
            if (rootTree == null || rootTree.Count == 0)
            {
                RemoveAllSpeedModifiers();
                entity.RemoveBehavior(this);
                return;
            }

            List<string> expiredKeys = new List<string>();
            float lowestSpeedModifier = 1.0f;
            bool hasSlowEffect = false;

            foreach (var pair in rootTree)
            {
                string effectKey = pair.Key;
                if (!(pair.Value is ITreeAttribute effectTree)) continue;

                float durationRemaining = effectTree.GetFloat("durationRemaining", 0f);
                float damageInterval = effectTree.GetFloat("damageInterval", 2f);
                float damagePerTick = effectTree.GetFloat("damagePerTick", 3f);
                float tickAccumulator = effectTree.GetFloat("tickAccumulator", 0f);
                float speedModifier = effectTree.GetFloat("speedModifier", 1.0f);

                if (speedModifier < 1.0f)
                {
                    hasSlowEffect = true;
                    if (speedModifier < lowestSpeedModifier) lowestSpeedModifier = speedModifier;
                }

                // 1. Tick down duration
                durationRemaining -= dt;
                if (durationRemaining <= 0)
                {
                    expiredKeys.Add(effectKey);
                    continue;
                }

                // 2. Damage interval tick
                if (damagePerTick > 0f && damageInterval > 0f)
                {
                    tickAccumulator += dt;
                    if (tickAccumulator >= damageInterval)
                    {
                        tickAccumulator = 0f;

                        entity.ReceiveDamage(
                            new DamageSource()
                            {
                                Source = EnumDamageSource.Internal,
                                Type = EnumDamageType.Poison,
                                KnockbackStrength = 0f
                            },
                            damagePerTick
                        );
                    }
                }

                effectTree.SetFloat("durationRemaining", durationRemaining);
                effectTree.SetFloat("tickAccumulator", tickAccumulator);
            }

            // Remove expired effects
            foreach (var key in expiredKeys)
            {
                rootTree.RemoveAttribute(key);
            }

            if (rootTree.Count == 0)
            {
                RemoveAllSpeedModifiers();
                entity.WatchedAttributes.RemoveAttribute("boricalchemy:active_effects");
                entity.WatchedAttributes.MarkPathDirty("boricalchemy:active_effects");
                entity.RemoveBehavior(this);
                return;
            }

            // Apply mob motion dampening if active
            if (hasSlowEffect)
            {
                if (entity is EntityPlayer)
                {
                    ApplySpeedModifiers();
                }
                else
                {
                    entity.Pos.Motion.X *= lowestSpeedModifier;
                    entity.Pos.Motion.Z *= lowestSpeedModifier;
                }
            }

            // 3. Dripping particle effect
            dripAccumulator += dt;
            if (dripAccumulator >= 0.4f && entity.World is IServerWorldAccessor serverWorldAcc)
            {
                dripAccumulator = 0f;

                foreach (var pair in rootTree)
                {
                    if (pair.Value is ITreeAttribute effTree)
                    {
                        int r = effTree.GetInt("partRed", 245);
                        int g = effTree.GetInt("partGreen", 245);
                        int b = effTree.GetInt("partBlue", 245);

                        int dropColor = ColorUtil.ColorFromRgba(b, g, r, 200);
                        Vec3d dropPos = entity.Pos.XYZ.AddCopy(0, entity.SelectionBox.Y2 * 0.5, 0);

                        SimpleParticleProperties dripParticles = new SimpleParticleProperties(
                            1f, 2f,
                            dropColor,
                            dropPos.AddCopy(-0.5, 0, -0.5),
                            dropPos.AddCopy(0.5, 0.5, 0.5),
                            new Vec3f(-0.05f, -0.1f, -0.05f),
                            new Vec3f(0.1f, 0.05f, 0.1f),
                            0.35f,
                            1.8f,
                            0.08f, 0.15f,
                            EnumParticleModel.Quad
                        );

                        dripParticles.SizeEvolve = new EvolvingNatFloat(EnumTransformFunction.LINEAR, -0.2f);
                        dripParticles.OpacityEvolve = new EvolvingNatFloat(EnumTransformFunction.LINEAR, -200f);

                        serverWorldAcc.SpawnParticles(dripParticles);
                        break;
                    }
                }
            }

            entity.WatchedAttributes.MarkPathDirty("boricalchemy:active_effects");
        }
    }
}